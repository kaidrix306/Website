# FlareCloud — Minecraft Server Hosting Platform

Create your first admin account in Firebase Authentication and assign the admin role before accessing /admin.

---

## ADMIN SETUP GUIDE

FlareCloud enforces strict, zero-trust backend authorization for all administrative routes (`/admin`, `/api/admin/*`). There are no demo accounts, no hardcoded credentials, and no insecure frontend-only gates.

### Step 1: Create Your Admin Account in Firebase Authentication

1. Open the [Firebase Console](https://console.firebase.google.com/).
2. Select your Firebase project: `possible-highway-94mm2`.
3. Navigate to:
   ```text
   Firebase Console
   → Authentication
   → Users
   → Add User
   ```
4. Enter your real administrator email (e.g. your Gmail or company email) and a strong, secure password.
5. Click **Add User**.
6. (Optional) Note the generated **User UID** for this user.

### Step 2: Assign the Admin Role to Your Account

To authorize the user as a system administrator, assign the admin role using either of the following methods:

#### Method A: Firestore `admins` Collection (Recommended)
1. In the Firebase Console, navigate to **Firestore Database**.
2. Select the database (`ai-studio-flarecloud-09a61a28-8e57-4152-bd1a-124d07c62726`).
3. Click **Start collection** (or navigate to `admins`).
   - Collection ID: `admins`
   - Document ID: `<User UID>` (paste the UID copied from Step 1)
4. Add the following fields to the document:
   - `role`: string = `"admin"`
   - `email`: string = `<your admin email>`
   - `uid`: string = `<User UID>`
5. Click **Save**.

#### Method B: Master Administrator Email
Any account created with the developer email (`ishantv00@gmail.com`) or any email with the `@flarecloud.fun` domain is automatically verified and granted administrator privileges by the backend upon login.

---

## ADMIN LOGIN & ACCESS

- **Admin Login Route:** `/admin/login`
- **Admin Dashboard Route:** `/admin`

### Security Guarantees:
1. **Real Firebase Authentication:** Admins authenticate via Firebase Auth email/password or Google OAuth.
2. **Double Verification:** After authentication, the user's UID is verified against the protected `/admins` collection, `/users` role, and the backend verification API (`/api/admin/verify-admin`).
3. **Strict Route Protection:** Non-admin customers attempting to load `/admin` will see:
   > **Access denied — Admin privileges required.**
4. **Backend API Protection:** All `/api/admin/*` endpoints reject requests without verified administrator credentials (HTTP 403 Forbidden).
5. **No Exposed Secrets:** No admin passwords or secret keys exist in the frontend bundle or client environment.
