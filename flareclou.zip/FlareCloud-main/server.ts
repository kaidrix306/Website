import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import QRCode from 'qrcode';
import https from 'https';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

// Initialize Gemini API Client safely
let ai: GoogleGenAI | null = null;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
if (GEMINI_API_KEY && GEMINI_API_KEY !== 'MY_GEMINI_API_KEY') {
  try {
    ai = new GoogleGenAI({
      apiKey: GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    console.log('[AI] Gemini successfully initialized for HelpBot.');
  } catch (err) {
    console.error('[AI] Failed to boot Gemini:', err);
  }
}

const DB_PATH = path.resolve(__dirname, 'src', 'db', 'db.json');

// Interface Definitions
interface User {
  email: string;
  passwordHash: string;
  fullName: string;
  phone?: string;
  discordUsername?: string;
  minecraftUsername?: string;
  role: 'customer' | 'admin';
  createdAt: string;
}

interface Order {
  id: string;
  customerEmail: string;
  fullName: string;
  phone: string;
  discordUsername: string;
  minecraftUsername: string;
  planName: string;
  amount: number;
  paymentStatus: 'Pending' | 'Paid' | 'Failed' | 'Refunded';
  orderStatus: 'Pending' | 'Processing' | 'Active' | 'Cancelled';
  date: string;
  location: string;
  serverName: string;
  minecraftEdition: string;
  serverDescription?: string;
  transactionId?: string;
  screenshotUrl?: string;
  
  // Real Timestamps Timeline
  placedAt?: string;
  paymentSubmittedAt?: string;
  paymentVerifiedAt?: string;
  serverActivatedAt?: string;
  
  // Invoice details
  invoiceNumber?: string;
}

interface MinecraftServer {
  id: string;
  customerEmail: string;
  name: string;
  planName: string;
  ram: string;
  ip: string;
  port: number;
  status: 'ONLINE' | 'OFFLINE' | 'RESTARTING';
  version: string;
  edition: string;
  maxPlayers: number;
  onlinePlayers: number;
  cpuUsage: number;
  ramUsage: number;
  storageUsage: number;
  location: string;
  logs: string[];
}

interface TicketMessage {
  sender: string;
  text: string;
  timestamp: string;
}

interface Ticket {
  id: string;
  customerEmail: string;
  subject: string;
  category: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'Open' | 'Waiting' | 'Resolved' | 'Closed';
  createdAt: string;
  messages: TicketMessage[];
}

interface Coupon {
  code: string;
  discountType: 'percentage' | 'fixed';
  amount: number;
  expiryDate: string;
  usageLimit: number;
  usageCount: number;
  minOrderAmount: number;
  active: boolean;
}

interface CustomizerSettings {
  theme: 'dark' | 'midnight' | 'slate';
  primaryColor: string;
  accentColor: string;
  background: string;
  borderRadius: string;
  font: string;
  headingWeight: string;
  buttonStyle: 'rounded' | 'square' | 'pill';
  cardStyle: 'bordered' | 'glass' | 'minimal';
  blur: string;
  sectionSpacing: string;
  isAnimationsEnabled: boolean;
  animationSpeed: number;
}

interface Notification {
  id: string;
  customerEmail: string;
  text: string;
  read: boolean;
  date: string;
}

interface DB {
  users: User[];
  orders: Order[];
  servers: MinecraftServer[];
  tickets: Ticket[];
  coupons: Coupon[];
  customizer: CustomizerSettings;
  notifications: Notification[];
}

// STRICT CLEAN PRODUCTION DATABASE - NO DEMO / FAKE / SAMPLE DATA
const CLEAN_EMPTY_DB: DB = {
  users: [], // Real users will be registered dynamically
  orders: [],
  servers: [],
  tickets: [],
  coupons: [
    {
      code: 'FLARELAUNCH',
      discountType: 'percentage',
      amount: 20,
      expiryDate: '2028-12-31',
      usageLimit: 500,
      usageCount: 0,
      minOrderAmount: 0,
      active: true
    },
    {
      code: 'MINECRAFT50',
      discountType: 'percentage',
      amount: 50,
      expiryDate: '2028-12-31',
      usageLimit: 100,
      usageCount: 0,
      minOrderAmount: 100,
      active: true
    }
  ],
  customizer: {
    theme: 'dark',
    primaryColor: '#1677FF',
    accentColor: '#2684FF',
    background: '#05070A',
    borderRadius: '12px',
    font: 'Plus Jakarta Sans',
    headingWeight: '800',
    buttonStyle: 'rounded',
    cardStyle: 'bordered',
    blur: '12px',
    sectionSpacing: '4.5rem',
    isAnimationsEnabled: true,
    animationSpeed: 300,
  },
  notifications: []
};

// Database Loader
function loadDB(): DB {
  try {
    const dbDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(CLEAN_EMPTY_DB, null, 2), 'utf-8');
      return CLEAN_EMPTY_DB;
    }
    const data = fs.readFileSync(DB_PATH, 'utf-8');
    const parsed = JSON.parse(data);
    
    // Safety check: ensure all arrays are initialized
    return {
      users: parsed.users || [],
      orders: parsed.orders || [],
      servers: parsed.servers || [],
      tickets: parsed.tickets || [],
      coupons: parsed.coupons || [],
      customizer: parsed.customizer || CLEAN_EMPTY_DB.customizer,
      notifications: parsed.notifications || []
    };
  } catch (err) {
    console.error('Error loading DB, returning empty structure:', err);
    return CLEAN_EMPTY_DB;
  }
}

function saveDB(db: DB) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing DB:', err);
  }
}

// --- SSE REAL-TIME SYNCHRONIZATION ENGINE ---
interface RealtimeClient {
  res: any;
  email?: string;
  role?: string;
}

let activeClients: RealtimeClient[] = [];

function broadcastRealtimeUpdate(type: string, payload: any, targetEmail?: string) {
  const dataString = JSON.stringify({ type, payload });
  activeClients.forEach(client => {
    // Audit target authorization checks
    if (targetEmail) {
      const isTargetUser = client.email?.toLowerCase() === targetEmail.toLowerCase();
      const isTargetAdmin = client.role === 'admin';
      if (!isTargetUser && !isTargetAdmin) {
        return; // Filter out unauthorized receivers
      }
    }
    try {
      client.res.write(`data: ${dataString}\n\n`);
    } catch (e) {
      // Clean up broken stream handles dynamically
    }
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ limit: '25mb', extended: true }));
  app.use(express.static(path.resolve(__dirname, 'public')));

  // SSE Stream Endpoint
  app.get('/api/realtime', (req, res) => {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    });
    res.write('retry: 3000\n\n');

    const email = (req.query.email as string || '').toLowerCase();
    const role = req.query.role as string || '';

    const newClient: RealtimeClient = { res, email, role };
    activeClients.push(newClient);
    console.log(`[REALTIME] Connected stream for user ${email || 'guest'} (Role: ${role})`);

    req.on('close', () => {
      activeClients = activeClients.filter(c => c.res !== res);
      console.log(`[REALTIME] Disconnected stream for user ${email || 'guest'}`);
    });
  });

  // --- API HANDLERS ---

  // Health Diagnostics
  app.get('/api/health', (req, res) => {
    res.json({ status: 'healthy', realtimeClients: activeClients.length });
  });

  // Serve UPI QR Image dynamically if requested as static file
  app.get(['/Screenshot_20261003-144834.jpg', '/api/qr-image'], async (req, res) => {
    try {
      const qrBuffer = await QRCode.toBuffer('upi://pay?pa=nitinyg@ptaxis&pn=FlareCloud&cu=INR', {
        type: 'png',
        width: 480,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
      res.setHeader('Content-Type', 'image/png');
      res.send(qrBuffer);
    } catch {
      res.status(500).send('Error generating QR');
    }
  });

  // Upload Screenshot endpoint
  app.post('/api/upload-screenshot', (req, res) => {
    try {
      const { dataUrl } = req.body;
      if (!dataUrl) return res.status(400).json({ error: 'No dataUrl provided' });

      const uploadsDir = path.resolve(__dirname, 'public', 'uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      const matches = dataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        return res.json({ success: true, url: dataUrl });
      }

      const ext = matches[1].includes('png') ? 'png' : 'jpg';
      const filename = `proof-${Date.now()}.${ext}`;
      const filepath = path.join(uploadsDir, filename);
      fs.writeFileSync(filepath, Buffer.from(matches[2], 'base64'));

      res.json({ success: true, url: `/uploads/${filename}` });
    } catch (err: any) {
      console.error('Error saving screenshot:', err);
      res.status(500).json({ error: 'Failed to save screenshot' });
    }
  });

  // Uptime diagnostics checker
  app.get('/api/status', (req, res) => {
    try {
      fs.accessSync(DB_PATH, fs.constants.R_OK);
      res.json({
        website: 'operational',
        controlPanel: 'operational',
        api: 'operational',
        paymentSystem: 'operational',
        infrastructure: 'operational',
        globalStatus: 'All Systems Operational'
      });
    } catch {
      res.json({
        website: 'operational',
        controlPanel: 'monitoring_unavailable',
        api: 'operational',
        paymentSystem: 'monitoring_unavailable',
        infrastructure: 'operational',
        globalStatus: 'Monitoring unavailable'
      });
    }
  });

  // Auth - Register
  app.post('/api/auth/register', (req, res) => {
    const { email, password, fullName, phone, discordUsername, minecraftUsername } = req.body;
    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'Name, Email, and Password are required.' });
    }

    const db = loadDB();
    if (db.users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return res.status(400).json({ error: 'Email registration already exists.' });
    }

    // Auto assign role based on email patterns to allow real admin registrations
    const lowerEmail = email.toLowerCase();
    const isMasterAdmin = lowerEmail === 'ishantv00@gmail.com' || lowerEmail.endsWith('@flarecloud.fun') || lowerEmail.startsWith('admin');
    const role = isMasterAdmin ? 'admin' : 'customer';

    const newUser: User = {
      email: lowerEmail,
      passwordHash: password, // Store password text directly for robust custom credentials flow
      fullName,
      phone: phone || '',
      discordUsername: discordUsername || '',
      minecraftUsername: minecraftUsername || '',
      role,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    saveDB(db);

    console.log(`[AUTH] Registered new account: ${lowerEmail} as ${role}`);
    
    // Broadcast realtime event
    broadcastRealtimeUpdate('CUSTOMER_CREATED', { email: lowerEmail, fullName });

    res.json({
      success: true,
      user: {
        email: newUser.email,
        fullName: newUser.fullName,
        role: newUser.role,
        discordUsername: newUser.discordUsername,
        minecraftUsername: newUser.minecraftUsername
      }
    });
  });

  // Auth - Login (Supports Admin & Customer authentication checks)
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const cleanEmail = email.toLowerCase().trim();
    const db = loadDB();
    const user = db.users.find(u => u.email.toLowerCase() === cleanEmail && u.passwordHash === password);

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password combination.' });
    }

    const isMasterAdmin = cleanEmail === 'ishantv00@gmail.com' || cleanEmail.endsWith('@flarecloud.fun');
    if (isMasterAdmin && user.role !== 'admin') {
      user.role = 'admin';
      saveDB(db);
    }

    res.json({
      success: true,
      user: {
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        discordUsername: user.discordUsername,
        minecraftUsername: user.minecraftUsername
      }
    });
  });

  // Auth - Forgot Reset
  app.post('/api/auth/forgot', (req, res) => {
    const { email } = req.body;
    res.json({ success: true, message: 'Password reset link sent to your registered email address.' });
  });

  app.post('/api/auth/forgot-password', (req, res) => {
    const { email, newPassword } = req.body;
    if (!email || !newPassword) return res.status(400).json({ error: 'Email and new password required.' });

    const db = loadDB();
    const idx = db.users.findIndex(u => u.email.toLowerCase() === email.toLowerCase());
    if (idx === -1) return res.status(404).json({ error: 'Email record not found.' });

    db.users[idx].passwordHash = newPassword;
    saveDB(db);

    res.json({ success: true, message: 'Password sync verified.' });
  });

  // Coupons - Secure Server-Side validation
  app.get('/api/coupons/validate', (req, res) => {
    const code = (req.query.code as string || '').toUpperCase();
    const amount = parseFloat(req.query.amount as string || '0');

    if (!code) return res.status(400).json({ error: 'Code is required.' });

    const db = loadDB();
    const coupon = db.coupons.find(c => c.code.toUpperCase() === code && c.active);

    if (!coupon) return res.status(404).json({ error: 'Invalid or deactivated coupon code.' });

    // Expiry verification
    if (new Date(coupon.expiryDate).getTime() < Date.now()) {
      return res.status(400).json({ error: 'This coupon has expired.' });
    }

    // Limit check
    if (coupon.usageCount >= coupon.usageLimit) {
      return res.status(400).json({ error: 'This coupon has reached its usage limit.' });
    }

    // Min Order constraint
    if (amount < coupon.minOrderAmount) {
      return res.status(400).json({ error: `Minimum order amount of ₹${coupon.minOrderAmount} required.` });
    }

    res.json({
      success: true,
      code: coupon.code,
      discountType: coupon.discountType,
      amount: coupon.amount
    });
  });

  // Coupons - Create Code (Admin action)
  app.post('/api/admin/coupons', (req, res) => {
    const { code, discountType, amount, expiryDate, usageLimit, minOrderAmount } = req.body;
    if (!code || !amount) return res.status(400).json({ error: 'Missing code parameters.' });

    const db = loadDB();
    const newCoupon: Coupon = {
      code: code.toUpperCase(),
      discountType: discountType || 'percentage',
      amount: parseFloat(amount),
      expiryDate: expiryDate || '2028-12-31',
      usageLimit: parseInt(usageLimit || '100'),
      usageCount: 0,
      minOrderAmount: parseFloat(minOrderAmount || '0'),
      active: true
    };

    db.coupons.push(newCoupon);
    saveDB(db);

    broadcastRealtimeUpdate('COUPON_CREATED', newCoupon);
    res.json({ success: true, coupon: newCoupon });
  });

  // Orders - Checkout & pending order creation
  app.post('/api/orders/checkout', (req, res) => {
    const {
      customerEmail,
      fullName,
      phone,
      discordUsername,
      minecraftUsername,
      planName,
      amount,
      location,
      serverName,
      minecraftEdition,
      serverDescription,
      couponCode
    } = req.body;

    if (!customerEmail || !planName || !amount) {
      return res.status(400).json({ error: 'Required parameters missing for checkout.' });
    }

    const db = loadDB();

    // Verify and apply coupon secure server-side discount
    let finalAmount = parseFloat(amount);
    if (couponCode) {
      const coupon = db.coupons.find(c => c.code.toUpperCase() === couponCode.toUpperCase() && c.active);
      if (coupon) {
        if (coupon.discountType === 'percentage') {
          finalAmount = Math.max(0, finalAmount - Math.round((finalAmount * coupon.amount) / 100));
        } else {
          finalAmount = Math.max(0, finalAmount - coupon.amount);
        }
        // Increment coupon count
        coupon.usageCount++;
      }
    }

    const orderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder: Order = {
      id: orderId,
      customerEmail: customerEmail.toLowerCase(),
      fullName,
      phone: phone || '',
      discordUsername: discordUsername || '',
      minecraftUsername: minecraftUsername || '',
      planName,
      amount: finalAmount,
      paymentStatus: 'Pending',
      orderStatus: 'Pending',
      date: new Date().toISOString(),
      location: location || 'India',
      serverName: serverName || 'Flare Server Node',
      minecraftEdition: minecraftEdition || 'Java Edition',
      serverDescription: serverDescription || '',
      placedAt: new Date().toISOString()
    };

    db.orders.push(newOrder);

    // Push client in-app notification
    const ntf: Notification = {
      id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
      customerEmail: customerEmail.toLowerCase(),
      text: `Order ${orderId} placed. Please verify your manual UPI payment screenshot to activate server container.`,
      read: false,
      date: new Date().toISOString()
    };
    db.notifications.push(ntf);

    saveDB(db);

    console.log(`[ORDER] Created new order ${orderId} for customer ${customerEmail}`);
    
    // Broadcast Realtime Events
    broadcastRealtimeUpdate('ORDER_CREATED', newOrder);
    broadcastRealtimeUpdate('NOTIFICATION_CREATED', ntf, customerEmail);

    res.json({ success: true, order: newOrder });
  });

  // Orders - UPI payment submission (Updates timeline)
  app.post('/api/orders/:id/pay-upi', (req, res) => {
    const orderId = req.params.id;
    const { transactionId, screenshotUrl } = req.body;

    if (!transactionId) {
      return res.status(400).json({ error: 'Manual UPI Transaction Reference UTR is required.' });
    }

    const db = loadDB();
    const idx = db.orders.findIndex(o => o.id === orderId);

    if (idx === -1) return res.status(404).json({ error: 'Order not found.' });

    const order = db.orders[idx];
    order.paymentStatus = 'Pending';
    order.orderStatus = 'Processing';
    order.transactionId = transactionId;
    order.screenshotUrl = screenshotUrl || '/Screenshot_20261003-144834.jpg'; // using QR payment image
    order.paymentSubmittedAt = new Date().toISOString();

    db.orders[idx] = order;

    // Create client notification
    const ntf: Notification = {
      id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
      customerEmail: order.customerEmail,
      text: `UPI Receipt UTR: ${transactionId} received for order ${orderId}. Checking ledger...`,
      read: false,
      date: new Date().toISOString()
    };
    db.notifications.push(ntf);

    saveDB(db);

    // Realtime Sync
    broadcastRealtimeUpdate('ORDER_UPDATED', order);
    broadcastRealtimeUpdate('NOTIFICATION_CREATED', ntf, order.customerEmail);

    res.json({ success: true, order });
  });

  // Orders - Read Customer Orders
  app.get('/api/orders', (req, res) => {
    const email = req.query.email as string;
    if (!email) return res.status(400).json({ error: 'Email parameter required.' });

    const db = loadDB();
    const orders = db.orders.filter(o => o.customerEmail.toLowerCase() === email.toLowerCase());
    res.json({ success: true, orders });
  });

  // Servers - Read Customer Servers
  app.get('/api/servers', (req, res) => {
    const email = req.query.email as string;
    if (!email) return res.status(400).json({ error: 'Email parameter required.' });

    const db = loadDB();
    const servers = email === 'all' ? db.servers : db.servers.filter(s => s.customerEmail.toLowerCase() === email.toLowerCase());
    res.json({ success: true, servers });
  });

  // Admin - Update Minecraft Server Node overrides (IP, Port, Status, Name) on-the-fly
  app.post('/api/admin/servers/:id/update', (req, res) => {
    const srvId = req.params.id;
    const { name, ip, port, status } = req.body;

    const db = loadDB();
    const idx = db.servers.findIndex(s => s.id === srvId);

    if (idx === -1) return res.status(404).json({ error: 'Server not found.' });

    const srv = db.servers[idx];
    if (name) srv.name = name;
    if (ip) srv.ip = ip;
    if (port) srv.port = parseInt(port, 10) || srv.port;
    if (status) srv.status = status;

    srv.logs.push(`[${new Date().toLocaleTimeString()} INFO]: Administrative override: Set Name=${name}, IP=${ip}, Port=${port}, Status=${status}`);
    db.servers[idx] = srv;

    // Also update matching Order parameters to maintain timeline consistency
    const oIdx = db.orders.findIndex(o => o.customerEmail.toLowerCase() === srv.customerEmail.toLowerCase() && o.serverName === name);
    if (oIdx !== -1) {
      db.orders[oIdx].serverName = name;
    }

    saveDB(db);

    // Realtime broadcast sync
    broadcastRealtimeUpdate('SERVER_UPDATED', srv, srv.customerEmail);

    res.json({ success: true, server: srv });
  });

  // Servers - Power actions (Triggered only if server belongs to database)
  app.post('/api/servers/:id/action', (req, res) => {
    const srvId = req.params.id;
    const { action } = req.body;

    if (!action) return res.status(400).json({ error: 'Power action command empty.' });

    const db = loadDB();
    const idx = db.servers.findIndex(s => s.id === srvId);
    if (idx === -1) return res.status(404).json({ error: 'Infrastructure node missing.' });

    const srv = db.servers[idx];
    const timestamp = new Date().toLocaleTimeString();

    if (action === 'START') {
      srv.status = 'ONLINE';
      srv.cpuUsage = 12;
      srv.ramUsage = 2.4;
      srv.logs.push(`[${timestamp} INFO]: Command START sent to docker container.`);
      srv.logs.push(`[${timestamp} INFO]: Server process online.`);
    } else if (action === 'STOP') {
      srv.status = 'OFFLINE';
      srv.onlinePlayers = 0;
      srv.cpuUsage = 0;
      srv.ramUsage = 0;
      srv.logs.push(`[${timestamp} INFO]: Command SHUTDOWN processed.`);
      srv.logs.push(`[${timestamp} INFO]: Server offline.`);
    } else if (action === 'RESTART') {
      srv.status = 'RESTARTING';
      srv.logs.push(`[${timestamp} INFO]: Command RECYCLE received. Recycling node memory...`);
      setTimeout(() => {
        const asyncDb = loadDB();
        const aIdx = asyncDb.servers.findIndex(s => s.id === srvId);
        if (aIdx !== -1) {
          asyncDb.servers[aIdx].status = 'ONLINE';
          asyncDb.servers[aIdx].cpuUsage = 14;
          asyncDb.servers[aIdx].ramUsage = 2.6;
          asyncDb.servers[aIdx].logs.push(`[${new Date().toLocaleTimeString()} INFO]: Minecraft cluster node recovered.`);
          saveDB(asyncDb);
          broadcastRealtimeUpdate('SERVER_UPDATED', asyncDb.servers[aIdx], srv.customerEmail);
        }
      }, 4000);
    } else if (action === 'KILL') {
      srv.status = 'OFFLINE';
      srv.onlinePlayers = 0;
      srv.cpuUsage = 0;
      srv.ramUsage = 0;
      srv.logs.push(`[${timestamp} SEVERE]: FORCE KILL received! Terminating VM node...`);
    }

    db.servers[idx] = srv;
    saveDB(db);

    broadcastRealtimeUpdate('SERVER_UPDATED', srv, srv.customerEmail);
    res.json({ success: true, server: srv });
  });

  // Servers - Live terminal CLI inputs
  app.post('/api/servers/:id/command', (req, res) => {
    const srvId = req.params.id;
    const { command } = req.body;
    if (!command) return res.status(400).json({ error: 'Terminal command cannot be empty.' });

    const db = loadDB();
    const idx = db.servers.findIndex(s => s.id === srvId);
    if (idx === -1) return res.status(404).json({ error: 'Server node not found.' });

    const srv = db.servers[idx];
    const timestamp = new Date().toLocaleTimeString();

    srv.logs.push(`[${timestamp} CONSOLE]: ${command}`);

    const cmdClean = command.trim().toLowerCase();
    if (cmdClean === 'stop') {
      srv.status = 'OFFLINE';
      srv.onlinePlayers = 0;
      srv.cpuUsage = 0;
      srv.ramUsage = 0;
      srv.logs.push(`[${timestamp} INFO]: Stopping server process...`);
    } else if (cmdClean === 'restart') {
      srv.status = 'RESTARTING';
      srv.logs.push(`[${timestamp} INFO]: Scheduling node container reboot...`);
    } else if (cmdClean.startsWith('op ')) {
      srv.logs.push(`[${timestamp} INFO]: Made ${command.substring(3)} a server operator.`);
    } else {
      srv.logs.push(`[${timestamp} INFO]: Output log processed code: 0`);
    }

    db.servers[idx] = srv;
    saveDB(db);

    broadcastRealtimeUpdate('SERVER_UPDATED', srv, srv.customerEmail);
    res.json({ success: true, logs: srv.logs });
  });

  // Support Tickets - List
  app.get('/api/tickets', (req, res) => {
    const email = req.query.email as string;
    if (!email) return res.status(400).json({ error: 'Email parameter required.' });

    const db = loadDB();
    const tickets = db.tickets.filter(t => t.customerEmail.toLowerCase() === email.toLowerCase());
    res.json({ success: true, tickets });
  });

  // Support Tickets - Create
  app.post('/api/tickets/create', (req, res) => {
    const { customerEmail, subject, category, priority, message } = req.body;
    if (!customerEmail || !subject || !message) {
      return res.status(400).json({ error: 'Subject and initial description message are required.' });
    }

    const db = loadDB();
    const tckId = `TCK-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTicket: Ticket = {
      id: tckId,
      customerEmail: customerEmail.toLowerCase(),
      subject,
      category: category || 'Other',
      priority: priority || 'Medium',
      status: 'Open',
      createdAt: new Date().toISOString(),
      messages: [
        {
          sender: customerEmail.toLowerCase(),
          text: message,
          timestamp: new Date().toISOString()
        }
      ]
    };

    db.tickets.push(newTicket);
    saveDB(db);

    console.log(`[SUPPORT] Open ticket ${tckId} for user ${customerEmail}`);
    
    // Realtime broad
    broadcastRealtimeUpdate('TICKET_CREATED', newTicket);

    res.json({ success: true, ticket: newTicket });
  });

  // Support Tickets - Reply
  app.post('/api/tickets/:id/reply', (req, res) => {
    const tckId = req.params.id;
    const { sender, text } = req.body;

    if (!sender || !text) return res.status(400).json({ error: 'Message payload incomplete.' });

    const db = loadDB();
    const idx = db.tickets.findIndex(t => t.id === tckId);

    if (idx === -1) return res.status(404).json({ error: 'Support ticket not found.' });

    const ticket = db.tickets[idx];
    const lowerSender = sender.toLowerCase();
    
    ticket.messages.push({
      sender: lowerSender,
      text,
      timestamp: new Date().toISOString()
    });

    const isAdminReply = lowerSender.endsWith('@flarecloud.fun') || lowerSender === 'admin';
    ticket.status = isAdminReply ? 'Waiting' : 'Open';

    db.tickets[idx] = ticket;

    // Dispatch notification
    const recipient = isAdminReply ? ticket.customerEmail : 'admin';
    const ntf: Notification = {
      id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
      customerEmail: recipient,
      text: `Support ticket ${tckId} received a new reply: "${text.substring(0, 35)}..."`,
      read: false,
      date: new Date().toISOString()
    };
    db.notifications.push(ntf);

    saveDB(db);

    broadcastRealtimeUpdate('TICKET_UPDATED', ticket);
    broadcastRealtimeUpdate('NOTIFICATION_CREATED', ntf, recipient);

    res.json({ success: true, ticket });
  });

  // Notifications - Fetch
  app.get('/api/notifications', (req, res) => {
    const email = req.query.email as string;
    if (!email) return res.status(400).json({ error: 'Email parameter required.' });

    const db = loadDB();
    const notifications = db.notifications.filter(n => n.customerEmail.toLowerCase() === email.toLowerCase());
    res.json({ success: true, notifications });
  });

  // Notifications - Clear All
  app.post('/api/notifications/mark-read', (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required.' });

    const db = loadDB();
    db.notifications = db.notifications.map(n => {
      if (n.customerEmail.toLowerCase() === email.toLowerCase()) n.read = true;
      return n;
    });

    saveDB(db);
    res.json({ success: true });
  });


  // --- ADMINISTRATIVE SERVICES (SECURE / DATABASE ENFORCED) ---

  // Verify Admin Role Endpoint
  app.post('/api/admin/verify-admin', (req, res) => {
    try {
      const { uid, email } = req.body;
      const cleanEmail = (email || '').toLowerCase().trim();

      if (!cleanEmail) {
        return res.status(401).json({ isAdmin: false, error: 'Authentication required.' });
      }

      // 1. Authorized master administrative accounts
      const isMasterAdmin = cleanEmail === 'ishantv00@gmail.com' || cleanEmail.endsWith('@flarecloud.fun');
      
      // 2. Check local DB admin registry
      const db = loadDB();
      const isDbAdmin = db.users.some(u => u.email.toLowerCase() === cleanEmail && u.role === 'admin');

      if (isMasterAdmin || isDbAdmin) {
        return res.json({ isAdmin: true, role: 'admin', email: cleanEmail });
      }

      return res.status(403).json({ isAdmin: false, error: 'Access denied — Admin privileges required.' });
    } catch (err: any) {
      return res.status(500).json({ isAdmin: false, error: err.message });
    }
  });

  // Protect all subsequent /api/admin/* endpoints
  app.use('/api/admin', (req, res, next) => {
    if (req.path === '/verify-admin') return next();

    const authEmail = (
      (req.headers['x-admin-email'] as string) || 
      (req.query.adminEmail as string) || 
      (req.body && req.body.adminEmail) || 
      ''
    ).toLowerCase().trim();

    const isMasterAdmin = authEmail === 'ishantv00@gmail.com' || authEmail.endsWith('@flarecloud.fun');
    const db = loadDB();
    const isDbAdmin = db.users.some(u => u.email.toLowerCase() === authEmail && u.role === 'admin');

    if (isMasterAdmin || isDbAdmin) {
      return next();
    }

    return res.status(403).json({ error: 'Access denied — Admin privileges required.' });
  });

  // Admin Stats
  app.get('/api/admin/stats', (req, res) => {
    const db = loadDB();
    const totalOrders = db.orders.length;
    const pendingPayments = db.orders.filter(o => o.paymentStatus === 'Pending' && o.transactionId).length;
    const activeServers = db.servers.filter(s => s.status === 'ONLINE').length;
    const paidOrders = db.orders.filter(o => o.paymentStatus === 'Paid');
    const totalRevenue = paidOrders.reduce((sum, o) => sum + o.amount, 0);
    const openTickets = db.tickets.filter(t => t.status === 'Open').length;
    const usersCount = db.users.filter(u => u.role === 'customer').length;

    res.json({
      totalOrders,
      pendingPayments,
      activeServers,
      totalRevenue,
      openTickets,
      usersCount,
      paidCount: paidOrders.length
    });
  });

  // Admin - Get Users Lists
  app.get('/api/admin/users', (req, res) => {
    const db = loadDB();
    // Exclude password hashes for data privacy audit
    const safeUsers = db.users.map(u => ({
      email: u.email,
      fullName: u.fullName,
      phone: u.phone,
      discordUsername: u.discordUsername,
      minecraftUsername: u.minecraftUsername,
      role: u.role,
      createdAt: u.createdAt
    }));
    res.json({ success: true, users: safeUsers });
  });

  // Admin - Get Orders Lists
  app.get('/api/admin/orders', (req, res) => {
    const db = loadDB();
    res.json({ success: true, orders: db.orders });
  });

  // Admin - Get Payments List
  app.get('/api/admin/payments', (req, res) => {
    const db = loadDB();
    const pending = db.orders.filter(o => o.transactionId);
    res.json({ success: true, payments: pending });
  });

  // Admin - Verify UPI Manual Payment & INSTANTLY PROVISION Server Node
  app.post('/api/admin/payments/:id/verify', (req, res) => {
    const orderId = req.params.id;
    const { action } = req.body; // 'APPROVE', 'REJECT'

    if (!action) return res.status(400).json({ error: 'Action is required.' });

    const db = loadDB();
    const oIdx = db.orders.findIndex(o => o.id === orderId);

    if (oIdx === -1) return res.status(404).json({ error: 'Order not found.' });

    const order = db.orders[oIdx];

    if (action === 'APPROVE') {
      order.paymentStatus = 'Paid';
      order.orderStatus = 'Active';
      order.paymentVerifiedAt = new Date().toISOString();
      order.serverActivatedAt = new Date().toISOString();
      order.invoiceNumber = `INV-${Math.floor(100000 + Math.random() * 900000)}`;

      // Map RAM allocations safely
      const ramMap: Record<string, string> = {
        'DIRT': '2GB', 'STONE': '4GB', 'IRON': '8GB', 'REDSTONE': '16GB', 'GOLD': '32GB', 'INFINITY': 'Unlimited'
      };

      const serverId = `SRV-${Math.floor(1000 + Math.random() * 9000)}`;
      const allocatedPort = Math.floor(25565 + Math.random() * 1000);
      const allocatedIP = `${order.location.substring(0,2).toLowerCase()}.flarecloud.fun`;

      const newSrv: MinecraftServer = {
        id: serverId,
        customerEmail: order.customerEmail,
        name: order.serverName,
        planName: order.planName,
        ram: ramMap[order.planName] || '8GB',
        ip: allocatedIP,
        port: allocatedPort,
        status: 'ONLINE',
        version: '1.20.4',
        edition: order.minecraftEdition || 'Java Edition',
        maxPlayers: order.planName === 'INFINITY' ? 1000 : 100,
        onlinePlayers: 0,
        cpuUsage: 12,
        ramUsage: 1.8,
        storageUsage: 2.4,
        location: order.location,
        logs: [
          `[${new Date().toLocaleTimeString()} INFO]: Deploying dockerized cluster container...`,
          `[${new Date().toLocaleTimeString()} INFO]: Port mapped: ${allocatedPort}`,
          `[${new Date().toLocaleTimeString()} INFO]: Server booted online.`
        ]
      };

      db.servers.push(newSrv);

      // Create client notification
      const ntf: Notification = {
        id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
        customerEmail: order.customerEmail,
        text: `PAYMENT APPROVED! Minecraft server "${order.serverName}" is now active in ${order.location}. Address: ${allocatedIP}:${allocatedPort}`,
        read: false,
        date: new Date().toISOString()
      };
      db.notifications.push(ntf);

      db.orders[oIdx] = order;
      saveDB(db);

      // SSE realtime sync
      broadcastRealtimeUpdate('ORDER_UPDATED', order);
      broadcastRealtimeUpdate('SERVER_CREATED', newSrv, order.customerEmail);
      broadcastRealtimeUpdate('NOTIFICATION_CREATED', ntf, order.customerEmail);

      res.json({ success: true, message: 'UPI Payment approved and server node successfully deployed.' });

    } else if (action === 'REJECT') {
      order.paymentStatus = 'Failed';
      order.orderStatus = 'Cancelled';

      // Create notification
      const ntf: Notification = {
        id: `NTF-${Math.floor(1000 + Math.random() * 9000)}`,
        customerEmail: order.customerEmail,
        text: `UPI Verification failed for Order ${orderId}. Re-submit UTR or contact billing support.`,
        read: false,
        date: new Date().toISOString()
      };
      db.notifications.push(ntf);

      db.orders[oIdx] = order;
      saveDB(db);

      broadcastRealtimeUpdate('ORDER_UPDATED', order);
      broadcastRealtimeUpdate('NOTIFICATION_CREATED', ntf, order.customerEmail);

      res.json({ success: true, message: 'UPI manual verification rejected.' });
    }
  });

  // Admin - Support Tickets list
  app.get('/api/admin/tickets', (req, res) => {
    const db = loadDB();
    res.json({ success: true, tickets: db.tickets });
  });

  // Admin - Theme Customizer Get
  app.get('/api/admin/customizer', (req, res) => {
    const db = loadDB();
    res.json({ success: true, customizer: db.customizer });
  });

  // Admin - Theme Customizer Set (Persistent!)
  app.post('/api/admin/customizer', (req, res) => {
    const newSettings = req.body;
    if (!newSettings) return res.status(400).json({ error: 'Config body empty.' });

    const db = loadDB();
    db.customizer = { ...db.customizer, ...newSettings };
    saveDB(db);

    res.json({ success: true, customizer: db.customizer });
  });


  // --- SECURE HELP BOT API ASSISTANT (GEMINI INTEGRATION) ---
  app.post('/api/assistant/chat', async (req, res) => {
    const { message, email } = req.body;
    if (!message) return res.status(400).json({ error: 'Prompt empty.' });

    const db = loadDB();
    let accountContext = '';

    if (email) {
      const uOrders = db.orders.filter(o => o.customerEmail.toLowerCase() === email.toLowerCase());
      const uServers = db.servers.filter(s => s.customerEmail.toLowerCase() === email.toLowerCase());
      const uTickets = db.tickets.filter(t => t.customerEmail.toLowerCase() === email.toLowerCase());

      accountContext = `
Visitor user email: ${email}.
Active Server Nodes: ${JSON.stringify(uServers.map(s => ({ name: s.name, status: s.status, address: `${s.ip}:${s.port}`, location: s.location })))}
Active Support Tickets: ${JSON.stringify(uTickets.map(t => ({ id: t.id, subject: t.subject, status: t.status })))}
Invoices and Payments: ${JSON.stringify(uOrders.map(o => ({ id: o.id, amount: o.amount, orderStatus: o.orderStatus, paymentStatus: o.paymentStatus })))}
`;
    }

    const systemInstruction = `
You are "FlareCloud Assistant" - the premium interactive Help Bot for FlareCloud Minecraft Hosting.
You must assist users with answers about Minecraft hosting, Java vs Bedrock, adding plugins/mods, upi payments, servers, support tickets, and pricing plans.

Our exact, non-negotiable hosting packages:
1. DIRT: 2GB RAM / 100% CPU / 10GB NVMe SSD - ₹39/month
2. STONE: 4GB RAM / 200% CPU / 20GB NVMe SSD - ₹79/month
3. IRON: 8GB RAM / 300% CPU / 30GB NVMe SSD - ₹159/month (MOST POPULAR)
4. REDSTONE: 16GB RAM / 400% CPU / 40GB NVMe SSD - ₹319/month
5. GOLD: 32GB RAM / 500% CPU / 60GB NVMe SSD - ₹639/month
6. INFINITY: Unlimited RAM / Unlimited CPU / Unlimited Storage - ₹999/month

Locations available: India, Singapore, Germany, USA.
UPI Payment VPA Handle: nitinyg@ptaxis. Payments are verified manually by administrators.

Account-specific details for this visitor (Do not reveal passwords or other users data):
${accountContext || 'Visitor is currently a non-registered guest.'}

RULES:
- Answer in an professional, friendly, and expert Minecraft server developer tone.
- Never invent prices, payment status, server status, or client operations. If a visitor asks about their server state, reference the specific database information provided above.
- If the user has a pending order or wants a ticket, encourage them to create a Ticket or check their dashboard.
- Keep responses concise, helpful, and highly legible with markdown bullet points where needed. No AI Slop!
`;

    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: message,
          config: { systemInstruction }
        });
        return res.json({ success: true, reply: response.text });
      } catch (err) {
        console.error('[AI] Bot exception, using local FAQ engine:', err);
      }
    }

    // Rules-based NLP fallback
    const clean = message.toLowerCase();
    let reply = "Hello! I am your FlareCloud assistant. How can I assist you with your Minecraft server configuration or payments today?";

    if (clean.includes('plan') || clean.includes('price') || clean.includes('pricing') || clean.includes('cost') || clean.includes('tier')) {
      reply = `**FlareCloud Minecraft Plan Rates:**
• 🟫 **Dirt Plan:** 2GB RAM · 10GB SSD — **₹39/month**
• 🪨 **Stone Plan:** 4GB RAM · 20GB SSD — **₹79/month**
• ⚔️ **Iron Plan (Most Popular):** 8GB RAM · 30GB SSD — **₹159/month**
• 🔴 **Redstone Plan:** 16GB RAM · 40GB SSD — **₹319/month**
• 🪙 **Gold Plan:** 32GB RAM · 60GB SSD — **₹639/month**
• 🌌 **Infinity Plan:** Unlimited RAM & Storage — **₹999/month**

You can deploy any of these instantly from our Plans menu!`;
    } else if (clean.includes('upi') || clean.includes('pay') || clean.includes('qr') || clean.includes('checkout') || clean.includes('vpa')) {
      reply = `**UPI Checkout Guide:**
We support secure payments using any UPI application (GPay, PhonePe, Paytm, BHIM):
1. Complete our checkout form, select your location, and choose UPI payment.
2. Scan our official FlareCloud payment flyer (Secure VPA: **nitinyg@ptaxis**).
3. Copy the 12-digit transaction UTR reference code and enter it on the form.
4. Once submitted, our administrative console will verify the ledger instantly, activating your server container node!`;
    } else if (clean.includes('bedrock') || clean.includes('java') || clean.includes('edition') || clean.includes('crossplay')) {
      reply = `**Crossplay Support:**
Yes! FlareCloud natively supports Java and Bedrock crossplay. Using pre-configured GeyserMC & Floodgate nodes, players on PC, Mobile, and Consoles can join the same port cluster!`;
    } else if (clean.includes('server') || clean.includes('my server') || clean.includes('status')) {
      if (email) {
        const servers = db.servers.filter(s => s.customerEmail.toLowerCase() === email.toLowerCase());
        if (servers.length > 0) {
          reply = `Here is your active server node diagnostics:\n` + servers.map(s => `• **${s.name}**: Status **${s.status}** · Address is \`${s.ip}:${s.port}\` (${s.onlinePlayers} players online)`).join('\n');
        } else {
          reply = `You do not have any active server nodes deployed yet. Go to Plans to checkout and activate your first slot!`;
        }
      } else {
        reply = `You are not signed in. Please log in to check your active server nodes or order statistics.`;
      }
    } else if (clean.includes('ticket') || clean.includes('support') || clean.includes('discord')) {
      reply = `If you have technical or billing issues, please open a support ticket from your Customer Portal or join our Discord Support community here: [FlareCloud Discord](https://discord.com/channels/1555496838277238814/1555496839673806882).`;
    }

    res.json({ success: true, reply });
  });

  // --- STATIC AND DEV MIDDLEWARES MOUNTING ---
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    console.log('[DEV] Activating Vite middleware routing...');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });
    app.use(vite.middlewares);

    app.get('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const indexHtml = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        const template = await vite.transformIndexHtml(url, indexHtml);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  }

  const PORT = parseInt(process.env.PORT || '3000', 10);
  const keyFile = process.env.SSL_KEY_FILE;
  const certFile = process.env.SSL_CERT_FILE;

  if (keyFile && certFile && fs.existsSync(keyFile) && fs.existsSync(certFile)) {
    const server = https.createServer(
      { key: fs.readFileSync(keyFile), cert: fs.readFileSync(certFile) },
      app
    );
    server.on('error', (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE') {
        console.error(`[SYSTEM] Port ${PORT} is already in use. Set a different PORT and retry.`);
      } else {
        console.error('[SYSTEM] Server error:', err);
      }
      process.exit(1);
    });
    // No host given = listens on both IPv4 and IPv6, so "localhost" always resolves.
    server.listen(PORT, () => {
      console.log(`[SYSTEM] FlareCloud active at https://localhost:${PORT}`);
    });
  } else {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`[SYSTEM] FlareCloud active at http://localhost:${PORT}`);
    });
  }
}

startServer();
