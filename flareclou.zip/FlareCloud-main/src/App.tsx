import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';
import Checkout from './components/Checkout';
import CustomerPortal from './components/CustomerPortal';
import AdminPortal from './components/AdminPortal';
import AdminLogin from './components/AdminLogin';
import Auth from './components/Auth';
import HelpBot from './components/HelpBot';
import { AlertCircle, Bell, Volume2, Wifi, CheckCircle2, ShieldAlert, LifeBuoy, ArrowRight, ExternalLink } from 'lucide-react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase';
import { doc, getDoc, getDocFromServer } from 'firebase/firestore';
import { logoutFromFirebase, subscribeToNotifications } from './services/firebaseService';

interface CustomizerSettings {
  theme: 'dark' | 'midnight' | 'slate';
  primaryColor: string;
  accentColor: string;
  background: string;
  borderRadius: string;
  font: string;
  headingWeight: string;
  buttonStyle: 'rounded' | 'square' | 'pill';
  cardStyle: 'bordered' | 'glass' | 'minimal';
  blur: string;
  sectionSpacing: string;
  isAnimationsEnabled: boolean;
  animationSpeed: number;
}

const DEFAULT_CUSTOMIZER: CustomizerSettings = {
  theme: 'dark',
  primaryColor: '#1677FF',
  accentColor: '#2684FF',
  background: '#05070A',
  borderRadius: '12px',
  font: 'Plus Jakarta Sans',
  headingWeight: '800',
  buttonStyle: 'rounded',
  cardStyle: 'bordered',
  blur: '12px',
  sectionSpacing: '4.5rem',
  isAnimationsEnabled: true,
  animationSpeed: 300
};

const getInitialView = () => {
  if (typeof window !== 'undefined') {
    const p = window.location.pathname.toLowerCase();
    if (p === '/admin/login') return 'admin-login';
    if (p === '/admin' || p.startsWith('/admin/')) return 'admin-portal';
    if (p === '/status') return 'status';
    if (p === '/support') return 'support';
    if (p === '/checkout') return 'checkout';
    if (p === '/login') return 'login';
    if (p === '/dashboard') return 'customer-portal';
  }
  return 'home';
};

export default function App() {
  const [currentView, setCurrentView] = useState<string>(getInitialView);
  const [user, setUser] = useState<any | null>(() => {
    try {
      const saved = localStorage.getItem('flarecloud_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const updateUser = (newUser: any) => {
    setUser(newUser);
    if (newUser) {
      try {
        localStorage.setItem('flarecloud_user', JSON.stringify(newUser));
      } catch {}
    } else {
      try {
        localStorage.removeItem('flarecloud_user');
      } catch {}
    }
  };

  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<any | null>(null);
  const [customizer, setCustomizer] = useState<CustomizerSettings>(DEFAULT_CUSTOMIZER);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState<boolean>(true);

  // Status Page Health Checks
  const [statusHealth, setStatusHealth] = useState<Record<string, { status: string; latency?: string }>>({
    'Website': { status: 'Operational', latency: '4 ms' },
    'Customer Dashboard': { status: 'Operational', latency: '12 ms' },
    'Authentication': { status: 'Operational', latency: '28 ms' },
    'Payments': { status: 'Operational', latency: '15 ms' },
    'Control Panel': { status: 'Operational', latency: '8 ms' },
    'API': { status: 'Operational', latency: '11 ms' },
    'Support': { status: 'Operational', latency: '6 ms' }
  });

  const applyStyles = (settings: CustomizerSettings) => {
    const root = document.documentElement;
    root.style.setProperty('--primary-color', settings.primaryColor);
    root.style.setProperty('--accent-color', settings.accentColor);
    root.style.setProperty('--background-color', settings.background);
    root.style.setProperty('--border-radius', settings.borderRadius);
    root.style.setProperty('--font-family', settings.font);
    root.style.setProperty('--heading-weight', settings.headingWeight);
    root.style.setProperty('--section-spacing', settings.sectionSpacing);
  };

  // Listen to Firebase Auth state
  useEffect(() => {
    applyStyles(DEFAULT_CUSTOMIZER);

    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', fbUser.uid));
          const isAdmin = fbUser.email?.toLowerCase().endsWith('@flarecloud.fun') || fbUser.email?.toLowerCase() === 'ishantv00@gmail.com';
          if (userDoc.exists()) {
            const data = userDoc.data();
            if (isAdmin && data.role !== 'admin') {
              updateUser({ ...data, role: 'admin' });
            } else {
              updateUser(data);
            }
          } else {
            const role = isAdmin ? 'admin' : 'customer';
            updateUser({
              uid: fbUser.uid,
              email: fbUser.email,
              fullName: fbUser.displayName || fbUser.email?.split('@')[0],
              role,
              createdAt: new Date().toISOString()
            });
          }
        } catch {
          const isAdmin = fbUser.email?.toLowerCase().endsWith('@flarecloud.fun') || fbUser.email?.toLowerCase() === 'ishantv00@gmail.com';
          const role = isAdmin ? 'admin' : 'customer';
          updateUser({
            uid: fbUser.uid,
            email: fbUser.email,
            fullName: fbUser.email?.split('@')[0],
            role,
            createdAt: new Date().toISOString()
          });
        }
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Real-time notifications listener for chime
  useEffect(() => {
    if (!user?.email) return;

    const unsub = subscribeToNotifications(user.email, (notifications) => {
      const unread = notifications.filter(n => !n.read);
      if (unread.length > 0) {
        // synthesize chime
        try {
          const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioCtx) {
            const ctx = new AudioCtx();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.setValueAtTime(523.25, ctx.currentTime);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
            osc.start();
            osc.stop(ctx.currentTime + 0.25);
          }
        } catch {}
      }
    });

    return () => unsub();
  }, [user?.email]);

  // Browser back/forward navigation support
  useEffect(() => {
    const handlePopState = () => {
      const p = window.location.pathname.toLowerCase();
      if (p === '/admin/login') setCurrentView('admin-login');
      else if (p === '/admin' || p.startsWith('/admin/')) setCurrentView('admin-portal');
      else if (p === '/status') setCurrentView('status');
      else if (p === '/support') setCurrentView('support');
      else if (p === '/login') setCurrentView('login');
      else if (p === '/dashboard') setCurrentView('customer-portal');
      else setCurrentView('home');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    let path = '/';
    if (view === 'admin-login') path = '/admin/login';
    else if (view === 'admin-portal') path = '/admin';
    else if (view === 'status') path = '/status';
    else if (view === 'support') path = '/support';
    else if (view === 'checkout') path = '/checkout';
    else if (view === 'login') path = '/login';
    else if (view === 'customer-portal') path = '/dashboard';

    if (typeof window !== 'undefined' && window.location.pathname !== path) {
      window.history.pushState({}, '', path);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = async () => {
    try {
      await logoutFromFirebase();
    } catch {}
    updateUser(null);
    handleNavigate('home');
  };

  const handleSelectPlan = (plan: any) => {
    setSelectedPlanForCheckout(plan);
    handleNavigate('checkout');
  };

  const handleCheckoutComplete = () => {
    handleNavigate('customer-portal');
  };

  return (
    <div 
      className="min-h-screen text-white relative flex flex-col justify-between font-sans selection:bg-[var(--primary-color)] selection:text-white"
      style={{ backgroundColor: customizer.background, fontFamily: customizer.font }}
    >
      <Navbar
        currentView={currentView}
        user={user}
        customizer={customizer}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
      />

      {/* Floating Status Banner */}
      {statusMessage && (
        <div className="fixed top-24 left-6 right-6 z-40 max-w-xl mx-auto p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-start gap-2.5 shadow-2xl animate-fade-in font-mono">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <div>
            <span className="font-extrabold uppercase tracking-widest block">System Status</span>
            <p className="mt-1 leading-relaxed">{statusMessage}</p>
          </div>
        </div>
      )}

      {/* Views Router */}
      <main className="flex-1">
        {currentView === 'home' && (
          <LandingPage
            customizer={customizer}
            onNavigate={setCurrentView}
            onSelectPlan={handleSelectPlan}
          />
        )}

        {/* /status PAGE */}
        {currentView === 'status' && (
          <div className="pt-32 pb-24 max-w-3xl mx-auto px-6 space-y-8 text-left animate-fade-in font-mono text-xs">
            <div className="border-b border-white/5 pb-4">
              <span className="text-[10px] text-[var(--primary-color)] font-bold tracking-widest uppercase">
                SYSTEM DIAGNOSTICS
              </span>
              <h2 className="text-3xl font-black text-white mt-1">INFRASTRUCTURE STATUS</h2>
              <p className="text-xs text-gray-400 mt-1">Live service heartbeat verification</p>
            </div>

            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <h4 className="text-sm font-bold text-white uppercase">All Systems Operational</h4>
                <p className="text-[11px] text-emerald-300">Continuous uptime monitoring active across all core systems.</p>
              </div>
            </div>

            <div className="bg-[#080B12] border border-white/5 p-6 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Service Component Status</h4>
              {Object.entries(statusHealth).map(([name, info]) => (
                <div key={name} className="flex justify-between items-center py-3 border-b border-white/5 last:border-b-0">
                  <div>
                    <span className="text-xs font-bold text-white">{name}</span>
                    <span className="text-[10px] text-gray-500 block">Response latency: {info.latency}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-emerald-400 font-bold uppercase">{info.status}</span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setCurrentView('home')}
              className="text-xs font-bold text-gray-400 hover:text-white cursor-pointer"
            >
              ← BACK TO HOME
            </button>
          </div>
        )}

        {/* /support PAGE */}
        {currentView === 'support' && (
          <div className="pt-32 pb-24 max-w-4xl mx-auto px-6 space-y-8 text-left animate-fade-in font-mono text-xs">
            <div className="border-b border-white/5 pb-4">
              <span className="text-[10px] text-[var(--primary-color)] font-bold tracking-widest uppercase">
                24/7 ASSISTANCE
              </span>
              <h2 className="text-3xl font-black text-white mt-1">SUPPORT CENTER</h2>
              <p className="text-xs text-gray-400 mt-1">Direct contact channels for technical and billing assistance</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-6 bg-[#080B12] border border-white/5 rounded-2xl space-y-4">
                <LifeBuoy className="w-8 h-8 text-[var(--primary-color)]" />
                <div>
                  <h4 className="text-sm font-bold text-white uppercase">Customer Ticket Portal</h4>
                  <p className="text-xs text-gray-400 mt-1 font-sans">
                    Submit ticket inquiries, track responses in real time, and get direct assistance from our Minecraft engineers.
                  </p>
                </div>
                <button
                  onClick={() => {
                    if (user) {
                      setCurrentView('customer-portal');
                    } else {
                      setCurrentView('login');
                    }
                  }}
                  className="w-full py-3 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white font-bold rounded-xl transition-all cursor-pointer"
                >
                  OPEN SUPPORT DESK
                </button>
              </div>

              <div className="p-6 bg-[#080B12] border border-white/5 rounded-2xl space-y-4">
                <div className="w-8 h-8 rounded-lg bg-[#5865F2] flex items-center justify-center text-white font-bold">
                  D
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white uppercase">Official Discord Community</h4>
                  <p className="text-xs text-gray-400 mt-1 font-sans">
                    Join hundreds of Minecraft server owners. Fast community support, announcements, and direct team chat.
                  </p>
                </div>
                <a
                  href="https://discord.gg/fwPQPcFST"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold rounded-xl transition-all inline-flex items-center justify-center gap-1.5 shadow-lg"
                >
                  JOIN DISCORD SERVER <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            <button
              onClick={() => setCurrentView('home')}
              className="text-xs font-bold text-gray-400 hover:text-white cursor-pointer"
            >
              ← BACK TO HOME
            </button>
          </div>
        )}

        {/* /login Route (Customer Auth) */}
        {currentView === 'login' && (
          <Auth
            customizer={customizer}
            onLoginSuccess={(u) => {
              updateUser(u);
              handleNavigate(u.role === 'admin' ? 'admin-portal' : 'customer-portal');
            }}
            onNavigate={handleNavigate}
          />
        )}

        {/* /admin/login Route (Restricted Administrator Authentication) */}
        {currentView === 'admin-login' && (
          <AdminLogin
            customizer={customizer}
            onLoginSuccess={(adminProfile) => {
              updateUser(adminProfile);
              handleNavigate('admin-portal');
            }}
            onNavigate={handleNavigate}
          />
        )}

        {/* /checkout Route */}
        {currentView === 'checkout' && (
          <Checkout
            selectedPlan={selectedPlanForCheckout}
            user={user}
            customizer={customizer}
            onNavigate={handleNavigate}
            onCheckoutComplete={handleCheckoutComplete}
          />
        )}

        {/* /dashboard Route (Customer Portal) */}
        {currentView === 'customer-portal' && (
          <CustomerPortal
            user={user}
            customizer={customizer}
            onNavigate={handleNavigate}
            onSelectPlanForCheckout={handleSelectPlan}
          />
        )}

        {/* /admin Route (Strictly Protected Administrator Portal) */}
        {currentView === 'admin-portal' && (
          user?.role === 'admin' ? (
            <AdminPortal
              user={user}
              customizer={customizer}
              onUpdateCustomizer={(newS) => {
                setCustomizer(newS);
                applyStyles(newS);
              }}
              onNavigate={handleNavigate}
            />
          ) : (
            <div className="pt-36 pb-24 max-w-lg mx-auto px-6 text-center animate-fade-in font-mono">
              <div className="w-16 h-16 bg-red-500/10 border-2 border-red-500/40 text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-[0_0_30px_rgba(239,68,68,0.25)]">
                <ShieldAlert className="w-8 h-8" />
              </div>
              <span className="text-[10px] uppercase tracking-widest text-red-400 font-bold block">
                RESTRICTED SYSTEM AREA
              </span>
              <h2 className="text-2xl font-black text-white mt-1">
                Access denied — Admin privileges required.
              </h2>
              <p className="text-xs text-gray-400 mt-2 font-sans leading-relaxed">
                This area is restricted to verified FlareCloud system administrators. Create your admin account in Firebase Authentication and assign the admin role before accessing /admin.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
                <button
                  onClick={() => handleNavigate('admin-login')}
                  className="px-6 py-3 bg-red-600 hover:bg-red-500 text-white text-xs font-black rounded-xl transition-all shadow-[0_0_20px_rgba(239,68,68,0.4)] cursor-pointer"
                >
                  ADMIN LOGIN (/admin/login)
                </button>
                <button
                  onClick={() => handleNavigate('home')}
                  className="px-6 py-3 bg-white/5 hover:bg-white/10 text-white text-xs font-bold rounded-xl border border-white/10 transition-all cursor-pointer"
                >
                  RETURN TO HOME
                </button>
              </div>
            </div>
          )
        )}
      </main>

      <HelpBot
        user={user}
        customizer={customizer}
        onNavigate={handleNavigate}
      />
    </div>
  );
}
