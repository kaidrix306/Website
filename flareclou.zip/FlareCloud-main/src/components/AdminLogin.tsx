import React, { useState } from 'react';
import { Shield, Lock, Mail, AlertCircle, CheckCircle, ArrowLeft, KeyRound, ShieldAlert } from 'lucide-react';
import { signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../firebase';
import { verifyAdminRole, loginWithGoogle, logoutFromFirebase, UserProfile } from '../services/firebaseService';

interface AdminLoginProps {
  customizer: any;
  onLoginSuccess: (adminProfile: UserProfile) => void;
  onNavigate: (view: string) => void;
}

export default function AdminLogin({ customizer, onLoginSuccess, onNavigate }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGoogleSubmitting, setIsGoogleSubmitting] = useState(false);
  
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isResetMode, setIsResetMode] = useState(false);

  // Submit Admin Email/Password Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      if (isResetMode) {
        if (!email.trim()) {
          throw new Error('Please enter your administrator email address.');
        }
        await sendPasswordResetEmail(auth, email.trim());
        setSuccessMsg('Password reset link sent to your administrator email address.');
        setIsSubmitting(false);
        return;
      }

      if (!email.trim() || !password) {
        throw new Error('Please provide both administrator email and password.');
      }

      // 1. Authenticate with real Firebase Authentication (with secure backend fallback)
      let fbUser: any = null;
      try {
        const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
        fbUser = cred.user;
      } catch (authErr: any) {
        if (authErr.code === 'auth/operation-not-allowed') {
          const resp = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email.trim(), password })
          });
          const data = await resp.json();
          if (!resp.ok || !data.success) {
            throw new Error('Invalid administrator credentials.');
          }
          fbUser = {
            uid: `admin_${btoa(email.trim()).replace(/=/g, '')}`,
            email: email.trim(),
            displayName: data.user?.fullName || 'System Administrator'
          };
        } else {
          throw authErr;
        }
      }

      // 2. Strict Admin Role Verification
      const isAdmin = await verifyAdminRole(fbUser.uid, fbUser.email || '');

      if (!isAdmin) {
        // Sign out unauthorized user immediately
        try { await logoutFromFirebase(); } catch {}
        setErrorMsg('Access denied — Admin privileges required.');
        setIsSubmitting(false);
        return;
      }

      // 3. User is verified administrator -> Proceed to /admin
      const adminProfile: UserProfile = {
        uid: fbUser.uid,
        email: (fbUser.email || '').toLowerCase(),
        fullName: fbUser.displayName || 'System Administrator',
        role: 'admin',
        createdAt: new Date().toISOString()
      };

      onLoginSuccess(adminProfile);
    } catch (err: any) {
      console.warn('[ADMIN AUTH]', err?.message || err);
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setErrorMsg('Invalid administrator credentials.');
      } else if (err.code === 'auth/too-many-requests') {
        setErrorMsg('Too many failed attempts. Please try again later.');
      } else {
        setErrorMsg(err.message || 'Administrator authentication failed.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Google Admin Login Option (Authorized Google Accounts)
  const handleGoogleAdminLogin = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setIsGoogleSubmitting(true);

    try {
      const profile = await loginWithGoogle();
      const isAdmin = await verifyAdminRole(profile.uid, profile.email);

      if (!isAdmin) {
        await logoutFromFirebase();
        setErrorMsg('Access denied — Admin privileges required.');
        setIsGoogleSubmitting(false);
        return;
      }

      onLoginSuccess(profile);
    } catch (err: any) {
      console.error('[ADMIN GOOGLE AUTH ERROR]', err);
      if (err.code === 'auth/popup-closed-by-user') {
        return;
      }
      setErrorMsg(err.message || 'Administrator authentication via Google failed.');
    } finally {
      setIsGoogleSubmitting(false);
    }
  };

  return (
    <div className="pt-28 pb-20 min-h-screen flex items-center justify-center px-6 font-sans">
      <div className="max-w-md w-full bg-[#080B12] border-2 border-red-500/20 hover:border-red-500/40 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(239,68,68,0.15)] transition-all">
        
        {/* Top Header Card */}
        <div className="p-8 bg-gradient-to-b from-[#180B0F] via-[#0E0B12] to-[#080B12] border-b border-white/5 text-center relative overflow-hidden">
          <div className="absolute top-0 right-1/2 translate-x-1/2 w-48 h-48 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="w-14 h-14 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center justify-center mx-auto mb-4 text-red-400 shadow-[0_0_20px_rgba(239,68,68,0.2)]">
            <Lock className="w-7 h-7" />
          </div>

          <span className="text-[10px] text-red-400 font-mono font-black uppercase tracking-widest block">
            RESTRICTED ACCESS
          </span>
          <h2 className="text-2xl font-black text-white font-mono tracking-tight mt-1">
            {isResetMode ? 'ADMIN PASSWORD RESET' : 'ADMINISTRATOR LOGIN'}
          </h2>
          <p className="text-xs text-slate-400 mt-2 font-mono">
            {isResetMode 
              ? 'Enter your registered administrator email to receive a secure password recovery link.'
              : 'Authorized personnel only. All access attempts are cryptographically verified and logged.'}
          </p>
        </div>

        {/* Form Body */}
        <div className="p-8 space-y-6">
          {errorMsg && (
            <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs font-mono flex items-start gap-2.5 animate-shake">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="leading-relaxed">{errorMsg}</div>
            </div>
          )}

          {successMsg && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs font-mono flex items-start gap-2.5">
              <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="leading-relaxed">{successMsg}</div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleAdminLogin} className="space-y-4 font-mono text-xs">
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-red-400" />
                <span>Admin Email Address <span className="text-red-400">*</span></span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@domain.com"
                autoComplete="email"
                className="w-full bg-[#101522] border border-white/10 focus:border-red-400 rounded-xl px-4 py-3 text-white focus:outline-none transition-all placeholder:text-gray-600"
              />
            </div>

            {!isResetMode && (
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-red-400" />
                    <span>Password <span className="text-red-400">*</span></span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsResetMode(true);
                      setErrorMsg('');
                      setSuccessMsg('');
                    }}
                    className="text-[10px] text-red-400 hover:text-red-300 hover:underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="w-full bg-[#101522] border border-white/10 focus:border-red-400 rounded-xl px-4 py-3 text-white focus:outline-none transition-all placeholder:text-gray-600"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting || isGoogleSubmitting}
              className="w-full py-3.5 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-600 disabled:opacity-50 text-white font-black font-mono tracking-wider rounded-xl transition-all shadow-[0_0_25px_rgba(239,68,68,0.4)] cursor-pointer mt-2"
            >
              {isSubmitting ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  VERIFYING CREDENTIALS...
                </span>
              ) : isResetMode ? (
                'SEND RESET INSTRUCTIONS'
              ) : (
                'LOGIN TO ADMIN PORTAL'
              )}
            </button>
          </form>

          {isResetMode && (
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsResetMode(false);
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className="text-xs text-gray-400 hover:text-white flex items-center gap-1.5 mx-auto font-mono cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Admin Login
              </button>
            </div>
          )}

          {/* Alternative Google Sign-In for Verified Admin Accounts */}
          {!isResetMode && (
            <div className="pt-2 border-t border-white/5 space-y-3">
              <div className="flex items-center gap-3 my-2">
                <div className="h-px bg-white/10 flex-1" />
                <span className="text-[9px] uppercase font-mono tracking-widest text-gray-500 font-bold">
                  OR VERIFIED GOOGLE ADMIN
                </span>
                <div className="h-px bg-white/10 flex-1" />
              </div>

              <button
                type="button"
                onClick={handleGoogleAdminLogin}
                disabled={isSubmitting || isGoogleSubmitting}
                className="w-full py-3 px-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-red-400/50 text-white text-xs font-mono font-bold rounded-xl transition-all flex items-center justify-center gap-2.5 cursor-pointer shadow-md"
              >
                {isGoogleSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    CHECKING PRIVILEGES...
                  </span>
                ) : (
                  <>
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <span>LOGIN WITH GOOGLE (ADMIN ACCOUNT)</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Back to Customer Site */}
          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="text-xs text-gray-500 hover:text-gray-300 font-mono cursor-pointer transition-colors"
            >
              ← Return to FlareCloud Main Site
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
