import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, CreditCard, LifeBuoy, Sliders, FileText, Check, X, 
  CheckCircle, AlertCircle, RefreshCw, Layers, Users, DollarSign, Activity, 
  Settings, Plus, Tag, HelpCircle, Server, Bell, Volume2, Search, Eye
} from 'lucide-react';
import { 
  subscribeToAllOrders, subscribeToAllServers, subscribeToAllTickets, 
  verifyOrderPaymentInFirestore, updateServerParametersInFirestore, 
  replyToTicketInFirestore, OrderItem, MinecraftServerData, SupportTicketItem 
} from '../services/firebaseService';

interface AdminPortalProps {
  user: any;
  customizer: any;
  onUpdateCustomizer: (newCustomizer: any) => void;
  onNavigate: (view: string) => void;
}

export default function AdminPortal({ user, customizer, onUpdateCustomizer, onNavigate }: AdminPortalProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'orders' | 'payments' | 'servers' | 'tickets' | 'settings'>('dashboard');
  
  // Realtime Firestore Data
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [servers, setServers] = useState<MinecraftServerData[]>([]);
  const [tickets, setTickets] = useState<SupportTicketItem[]>([]);
  
  // Live alerts
  const [newOrderAlert, setNewOrderAlert] = useState<string | null>(null);
  const prevOrdersCountRef = useRef<number | null>(null);

  // Screenshot Preview Modal
  const [viewingScreenshotUrl, setViewingScreenshotUrl] = useState<string | null>(null);

  // Edit Server Form
  const [editingServer, setEditingServer] = useState<MinecraftServerData | null>(null);
  const [editSrvName, setEditSrvName] = useState('');
  const [editSrvIp, setEditSrvIp] = useState('');
  const [editSrvPort, setEditSrvPort] = useState(25565);
  const [editSrvStatus, setEditSrvStatus] = useState<any>('ONLINE');

  // Support Reply State
  const [selectedTicket, setSelectedTicket] = useState<SupportTicketItem | null>(null);
  const [replyText, setReplyText] = useState('');

  // Audio Chime synthesizer for new live orders
  const playLiveChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3); // A5
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      }
    } catch {
      // Audio bypass if restricted
    }
  };

  // --- Realtime Subscriptions ---
  useEffect(() => {
    const unsubOrders = subscribeToAllOrders((allOrders) => {
      // Detect live incoming order
      if (prevOrdersCountRef.current !== null && allOrders.length > prevOrdersCountRef.current) {
        const latest = allOrders[0];
        setNewOrderAlert(`NEW ORDER RECEIVED: #${latest.id} (${latest.planName} Plan - ₹${latest.amount})`);
        playLiveChime();
        setTimeout(() => setNewOrderAlert(null), 8000);
      }
      prevOrdersCountRef.current = allOrders.length;
      setOrders(allOrders);
    });

    const unsubServers = subscribeToAllServers((allServers) => {
      setServers(allServers);
    });

    const unsubTickets = subscribeToAllTickets((allTickets) => {
      setTickets(allTickets);
    });

    return () => {
      unsubOrders();
      unsubServers();
      unsubTickets();
    };
  }, []);

  // Stats calculation from real data
  const totalRevenue = orders.filter(o => o.paymentStatus === 'Paid').reduce((sum, o) => sum + o.amount, 0);
  const pendingPayments = orders.filter(o => o.paymentStatus === 'Pending' && o.transactionId);
  const activeServersCount = servers.filter(s => s.status === 'ONLINE').length;
  const openTicketsCount = tickets.filter(t => t.status === 'Open').length;

  const handleVerify = async (orderId: string, action: 'APPROVE' | 'REJECT') => {
    try {
      await verifyOrderPaymentInFirestore(orderId, action);
      alert(action === 'APPROVE' ? 'Payment Approved & Server Provisioned!' : 'Payment Rejected');
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleSaveServerOverride = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingServer) return;
    try {
      await updateServerParametersInFirestore(editingServer.id, {
        name: editSrvName,
        ip: editSrvIp,
        port: editSrvPort,
        status: editSrvStatus
      });
      alert('Server parameters updated live!');
      setEditingServer(null);
    } catch {
      alert('Failed to update server.');
    }
  };

  const handleAdminReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !selectedTicket) return;
    try {
      await replyToTicketInFirestore(selectedTicket.id, user?.email || 'admin@flarecloud.fun', replyText.trim());
      setReplyText('');
      alert('Reply sent.');
    } catch {
      alert('Failed to send reply.');
    }
  };

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6 font-sans">
      
      {/* Live Order Incoming Alert Banner */}
      {newOrderAlert && (
        <div className="fixed top-20 left-6 right-6 z-50 max-w-xl mx-auto p-4 bg-emerald-500/20 border-2 border-emerald-500 text-emerald-300 text-xs font-mono font-bold rounded-2xl flex items-center justify-between shadow-[0_0_40px_rgba(16,185,129,0.5)] animate-bounce">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span>{newOrderAlert}</span>
          </div>
          <button onClick={() => setNewOrderAlert(null)} className="text-white hover:opacity-80 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Admin Top Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6 mb-8">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="text-[10px] text-emerald-400 font-mono font-black uppercase tracking-widest flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> LIVE DATABASE SYNC
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-wide mt-1 font-mono">
            ADMINISTRATIVE CONSOLE
          </h2>
          <p className="text-xs text-gray-400 font-mono mt-0.5">Real-time management for orders, servers, and payments</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'dashboard', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
            { id: 'payments', label: 'Verify Payments', icon: <CreditCard className="w-4 h-4" />, count: pendingPayments.length },
            { id: 'orders', label: 'All Orders', icon: <FileText className="w-4 h-4" />, count: orders.length },
            { id: 'servers', label: 'Servers', icon: <Server className="w-4 h-4" />, count: servers.length },
            { id: 'tickets', label: 'Support Cases', icon: <LifeBuoy className="w-4 h-4" />, count: openTicketsCount },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[var(--primary-color)] text-white shadow-[0_0_15px_rgba(22,119,255,0.4)]'
                  : 'bg-[#101522] text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {typeof tab.count === 'number' && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/40 text-white font-bold">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* DASHBOARD OVERVIEW */}
      {activeTab === 'dashboard' && (
        <div className="space-y-8 animate-fade-in">
          {/* Key Metric Counters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-[#080B12] border border-white/5 rounded-2xl space-y-1 font-mono">
              <span className="text-[10px] uppercase text-gray-500 font-bold block">Total Revenue</span>
              <p className="text-2xl font-black text-white">₹{totalRevenue}</p>
              <span className="text-[10px] text-emerald-400 block mt-1">Realtime verified ledger</span>
            </div>

            <div className="p-5 bg-[#080B12] border border-white/5 rounded-2xl space-y-1 font-mono">
              <span className="text-[10px] uppercase text-gray-500 font-bold block">Pending UPI Verifications</span>
              <p className="text-2xl font-black text-amber-400">{pendingPayments.length}</p>
              <span className="text-[10px] text-gray-500 block mt-1">Awaiting manual check</span>
            </div>

            <div className="p-5 bg-[#080B12] border border-white/5 rounded-2xl space-y-1 font-mono">
              <span className="text-[10px] uppercase text-gray-500 font-bold block">Active Online Servers</span>
              <p className="text-2xl font-black text-blue-400">{activeServersCount}</p>
              <span className="text-[10px] text-gray-500 block mt-1">{servers.length} total hosted</span>
            </div>

            <div className="p-5 bg-[#080B12] border border-white/5 rounded-2xl space-y-1 font-mono">
              <span className="text-[10px] uppercase text-gray-500 font-bold block">Open Support Tickets</span>
              <p className="text-2xl font-black text-purple-400">{openTicketsCount}</p>
              <span className="text-[10px] text-gray-500 block mt-1">Customer inquiries</span>
            </div>
          </div>

          {/* Quick Pending Payments Section */}
          <div className="bg-[#080B12] border border-white/5 rounded-2xl p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-white/5 pb-4">
              <h3 className="text-base font-bold text-white font-mono uppercase">Immediate Pending Payments</h3>
              <button
                type="button"
                onClick={() => setActiveTab('payments')}
                className="text-xs text-[var(--primary-color)] hover:underline font-mono"
              >
                View all ({pendingPayments.length}) →
              </button>
            </div>

            {pendingPayments.length === 0 ? (
              <p className="text-gray-500 text-xs font-mono py-4 text-center">No pending payments. All orders are processed.</p>
            ) : (
              <div className="space-y-3 font-mono text-xs">
                {pendingPayments.slice(0, 3).map((pay) => (
                  <div key={pay.id} className="p-4 bg-[#101522] border border-white/5 rounded-xl flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                    <div>
                      <span className="text-white font-bold">{pay.id}</span> · <span className="text-gray-400">{pay.customerEmail}</span>
                      <p className="text-[10px] text-gray-500 mt-0.5">{pay.planName} Plan · UTR: <b className="text-emerald-400">{pay.transactionId}</b></p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-bold mr-2">₹{pay.amount}</span>
                      <button
                        type="button"
                        onClick={() => handleVerify(pay.id, 'APPROVE')}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg font-bold cursor-pointer"
                      >
                        ✓ Approve
                      </button>
                      <button
                        type="button"
                        onClick={() => handleVerify(pay.id, 'REJECT')}
                        className="px-3 py-1.5 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg font-bold cursor-pointer"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* VERIFY PAYMENTS TAB */}
      {activeTab === 'payments' && (
        <div className="space-y-6 animate-fade-in font-mono text-xs">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-wide">Manual UPI Payment Approvals</h3>
            <p className="text-xs text-gray-400 mt-0.5">Verify customer UTR reference numbers and screenshot receipts</p>
          </div>

          {pendingPayments.length === 0 ? (
            <div className="p-12 text-center bg-[#080B12] border border-dashed border-white/10 rounded-2xl text-gray-500">
              No pending UPI payments to verify.
            </div>
          ) : (
            <div className="space-y-4">
              {pendingPayments.map((pay) => (
                <div key={pay.id} className="p-6 bg-[#080B12] border border-white/5 rounded-2xl space-y-4 shadow-xl">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                    <div>
                      <span className="text-[10px] text-gray-500 block uppercase font-bold">{pay.id} · Placed {new Date(pay.date).toLocaleString()}</span>
                      <h4 className="text-base font-bold text-white mt-1">{pay.planName} PLAN</h4>
                      <p className="text-gray-300 mt-1">Client: <b className="text-white">{pay.customerEmail}</b> ({pay.fullName})</p>
                      <p className="text-gray-400 mt-0.5">Server MOTD: <b className="text-white">{pay.serverName}</b> · Location: {pay.location}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-xl font-black text-white">₹{pay.amount}</span>
                      <span className="text-[10px] text-gray-500 block uppercase mt-1">12-Digit UTR</span>
                      <p className="text-sm font-black text-emerald-400 select-all">{pay.transactionId}</p>
                    </div>
                  </div>

                  {/* Screenshot Proof Preview */}
                  {pay.screenshotUrl && (
                    <div className="p-3 bg-[#101522] rounded-xl border border-white/5 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={pay.screenshotUrl}
                          alt="Payment Screenshot Proof"
                          onClick={() => setViewingScreenshotUrl(pay.screenshotUrl!)}
                          className="w-16 h-16 object-cover rounded-lg cursor-pointer border border-white/10 hover:opacity-80"
                        />
                        <div>
                          <span className="text-[10px] text-gray-400 block uppercase font-bold">Uploaded Screenshot Proof</span>
                          <button
                            type="button"
                            onClick={() => setViewingScreenshotUrl(pay.screenshotUrl!)}
                            className="text-xs text-[var(--primary-color)] hover:underline mt-0.5 flex items-center gap-1 cursor-pointer font-bold"
                          >
                            <Eye className="w-3.5 h-3.5" /> Inspect Full Size Screenshot
                          </button>
                        </div>
                      </div>
                      <span className="text-[10px] text-gray-500">Click image to enlarge</span>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => handleVerify(pay.id, 'APPROVE')}
                      className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl transition-all cursor-pointer shadow-lg"
                    >
                      ✓ APPROVE & ACTIVATE SERVER
                    </button>
                    <button
                      type="button"
                      onClick={() => handleVerify(pay.id, 'REJECT')}
                      className="py-3 px-6 bg-red-500/20 hover:bg-red-500/30 text-red-400 font-bold rounded-xl border border-red-500/30 cursor-pointer"
                    >
                      REJECT
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ALL ORDERS TAB */}
      {activeTab === 'orders' && (
        <div className="space-y-6 animate-fade-in font-mono text-xs">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-wide">All Customer Orders ({orders.length})</h3>
            <p className="text-xs text-gray-400 mt-0.5">Live synchronizing order book</p>
          </div>

          <div className="bg-[#080B12] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
            <table className="w-full text-left">
              <thead className="bg-black/40 border-b border-white/5 text-[10px] text-gray-500 uppercase">
                <tr>
                  <th className="py-3 px-4">Order ID</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Plan</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-gray-300">
                {orders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-4 font-bold text-white">{ord.id}</td>
                    <td className="py-3 px-4 max-w-[140px] truncate">{ord.customerEmail}</td>
                    <td className="py-3 px-4 text-[var(--primary-color)] font-bold">{ord.planName}</td>
                    <td className="py-3 px-4 font-bold text-white">₹{ord.amount}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ord.paymentStatus === 'Paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        {ord.paymentStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 uppercase text-[10px]">{ord.orderStatus}</td>
                    <td className="py-3 px-4 text-gray-500 text-[10px]">{new Date(ord.date).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SERVERS MANAGEMENT TAB */}
      {activeTab === 'servers' && (
        <div className="space-y-6 animate-fade-in font-mono text-xs">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-wide">Minecraft Server Instances ({servers.length})</h3>
            <p className="text-xs text-gray-400 mt-0.5">Live server containers and allocations</p>
          </div>

          {editingServer ? (
            <form onSubmit={handleSaveServerOverride} className="p-6 bg-[#080B12] border border-white/10 rounded-2xl space-y-4 max-w-xl">
              <h4 className="text-sm font-bold text-white uppercase">Modify Server Parameters: {editingServer.name}</h4>
              <div className="space-y-1">
                <label className="text-gray-400">Server Name</label>
                <input
                  type="text"
                  required
                  value={editSrvName}
                  onChange={(e) => setEditSrvName(e.target.value)}
                  className="w-full bg-[#101522] border border-white/10 rounded-lg px-3 py-2 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-gray-400">IP Host</label>
                  <input
                    type="text"
                    required
                    value={editSrvIp}
                    onChange={(e) => setEditSrvIp(e.target.value)}
                    className="w-full bg-[#101522] border border-white/10 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-gray-400">Port</label>
                  <input
                    type="number"
                    required
                    value={editSrvPort}
                    onChange={(e) => setEditSrvPort(parseInt(e.target.value))}
                    className="w-full bg-[#101522] border border-white/10 rounded-lg px-3 py-2 text-white"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-gray-400">Status</label>
                <select
                  value={editSrvStatus}
                  onChange={(e) => setEditSrvStatus(e.target.value)}
                  className="w-full bg-[#101522] border border-white/10 rounded-lg px-3 py-2 text-white"
                >
                  <option value="ONLINE">ONLINE</option>
                  <option value="OFFLINE">OFFLINE</option>
                  <option value="RESTARTING">RESTARTING</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingServer(null)}
                  className="px-4 py-2 text-gray-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[var(--primary-color)] text-white font-bold rounded-lg cursor-pointer"
                >
                  Save Parameters
                </button>
              </div>
            </form>
          ) : (
            <div className="bg-[#080B12] border border-white/5 rounded-2xl divide-y divide-white/5">
              {servers.map((srv) => (
                <div key={srv.id} className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{srv.name}</span>
                      <span className={`px-2 py-0.2 rounded text-[9px] font-bold ${
                        srv.status === 'ONLINE' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                      }`}>
                        {srv.status}
                      </span>
                    </div>
                    <span className="text-[10px] text-gray-400 block mt-1">
                      {srv.ip}:{srv.port} · {srv.customerEmail} · {srv.planName} Plan ({srv.ram})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingServer(srv);
                      setEditSrvName(srv.name);
                      setEditSrvIp(srv.ip);
                      setEditSrvPort(srv.port);
                      setEditSrvStatus(srv.status);
                    }}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg text-xs cursor-pointer font-bold"
                  >
                    Edit Server
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUPPORT TICKETS TAB */}
      {activeTab === 'tickets' && (
        <div className="space-y-6 animate-fade-in font-mono text-xs">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-wide">Support Desk Cases ({tickets.length})</h3>
            <p className="text-xs text-gray-400 mt-0.5">Real-time resolution of client help requests</p>
          </div>

          {selectedTicket ? (
            <div className="bg-[#080B12] border border-white/5 rounded-2xl p-6 space-y-4">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <span className="text-[10px] text-gray-500">{selectedTicket.id} · {selectedTicket.customerEmail}</span>
                  <h4 className="text-base font-bold text-white mt-0.5">{selectedTicket.subject}</h4>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedTicket(null)}
                  className="text-xs text-gray-400 hover:text-white cursor-pointer"
                >
                  ← BACK TO CASES
                </button>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto p-2">
                {selectedTicket.messages.map((m, idx) => {
                  const isStaff = m.sender.endsWith('@flarecloud.fun') || m.sender === 'admin';
                  return (
                    <div key={idx} className={`flex flex-col ${isStaff ? 'items-end' : 'items-start'}`}>
                      <span className="text-[9px] text-gray-500 mb-1">{isStaff ? 'Staff (You)' : selectedTicket.customerEmail}</span>
                      <div className={`p-3 rounded-xl max-w-md ${
                        isStaff ? 'bg-[var(--primary-color)] text-white' : 'bg-[#101522] text-white border border-white/5'
                      }`}>
                        {m.text}
                      </div>
                      <span className="text-[8px] text-gray-500 mt-1">{new Date(m.timestamp).toLocaleTimeString()}</span>
                    </div>
                  );
                })}
              </div>

              <form onSubmit={handleAdminReply} className="flex gap-2 border-t border-white/5 pt-4">
                <input
                  type="text"
                  required
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Type staff response..."
                  className="flex-1 bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[var(--primary-color)] text-white font-bold rounded-xl cursor-pointer"
                >
                  Reply
                </button>
              </form>
            </div>
          ) : (
            <div className="bg-[#080B12] border border-white/5 rounded-2xl divide-y divide-white/5">
              {tickets.length === 0 ? (
                <div className="p-8 text-center text-gray-500">No support tickets found.</div>
              ) : (
                tickets.map((tck) => (
                  <div
                    key={tck.id}
                    onClick={() => setSelectedTicket(tck)}
                    className="p-4 flex justify-between items-center hover:bg-white/5 cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{tck.subject}</span>
                        <span className={`px-2 py-0.2 rounded text-[9px] ${
                          tck.status === 'Open' ? 'bg-blue-500/10 text-blue-400' : 'bg-emerald-500/10 text-emerald-400'
                        }`}>
                          {tck.status}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-500 block mt-1">
                        {tck.id} · {tck.customerEmail} · {tck.category}
                      </span>
                    </div>
                    <button type="button" className="px-3 py-1 bg-white/5 hover:bg-white/10 rounded text-xs text-white">
                      Inspect
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* FULLSCREEN SCREENSHOT PREVIEW MODAL */}
      {viewingScreenshotUrl && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-fade-in"
          onClick={() => setViewingScreenshotUrl(null)}
        >
          <div 
            className="flex items-center justify-between w-full max-w-2xl mb-3 text-white font-mono text-xs"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="font-bold uppercase tracking-wider text-slate-300">Customer Payment Screenshot Proof</span>
            <button
              type="button"
              onClick={() => setViewingScreenshotUrl(null)}
              className="p-1.5 bg-white/10 hover:bg-red-500/80 rounded-lg text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div 
            className="max-w-2xl max-h-[80vh] overflow-auto p-2 bg-[#0D111A] border border-white/10 rounded-2xl shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={viewingScreenshotUrl} 
              alt="Payment Proof Full" 
              className="max-w-full max-h-[75vh] object-contain rounded-lg mx-auto"
            />
          </div>
        </div>
      )}

    </div>
  );
}
