import React, { useState } from 'react';
import { Shield, Sparkles, Key, Lock, Mail, User, AlertCircle, CheckCircle, ArrowLeft, Phone } from 'lucide-react';
import { loginWithFirebase, registerWithFirebase, sendPasswordReset, loginWithGoogle } from '../services/firebaseService';

interface AuthProps {
  customizer: any;
  onLoginSuccess: (user: any) => void;
  onNavigate: (view: string) => void;
}

export default function Auth({ customizer, onLoginSuccess, onNavigate }: AuthProps) {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [minecraftUsername, setMinecraftUsername] = useState('');
  const [discordUsername, setDiscordUsername] = useState('');
  
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGoogleSubmitting, setIsGoogleSubmitting] = useState(false);

  const handleGoogleSignIn = async () => {
    setErrorMsg('');
    setSuccessMsg('');
    setIsGoogleSubmitting(true);
    try {
      const profile = await loginWithGoogle();
      onLoginSuccess(profile);
    } catch (err: any) {
      console.error('[AUTH GOOGLE ERROR]', err);
      if (err.code === 'auth/popup-closed-by-user') {
        // User closed popup, do not show fatal error
        return;
      }
      if (err.code === 'auth/operation-not-allowed') {
        setErrorMsg('Google Sign-In is not enabled for this project. Please check Firebase Authentication settings.');
      } else {
        setErrorMsg(err.message || 'Google authentication failed.');
      }
    } finally {
      setIsGoogleSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
      if (authMode === 'login') {
        const profile = await loginWithFirebase(email.trim(), password);
        onLoginSuccess(profile);
      } else if (authMode === 'register') {
        if (password.length < 6) {
          throw new Error('Password must be at least 6 characters long.');
        }
        if (password !== confirmPassword) {
          throw new Error('Passwords do not match.');
        }

        const profile = await registerWithFirebase(email.trim(), password, {
          fullName: fullName.trim(),
          phone: phone.trim(),
          minecraftUsername: minecraftUsername.trim(),
          discordUsername: discordUsername.trim()
        });
        onLoginSuccess(profile);
      } else if (authMode === 'forgot') {
        if (!email.trim()) {
          throw new Error('Please enter your account email address.');
        }
        await sendPasswordReset(email.trim());
        setSuccessMsg('Password reset link sent to your email address.');
      }
    } catch (err: any) {
      console.warn('[AUTH]', err?.message || err);
      let msg = err.message || 'Authentication failed.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email address or password.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please login instead.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password is too weak. Please use at least 6 characters.';
      }
      setErrorMsg(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pt-28 pb-20 min-h-screen flex items-center justify-center px-6 font-sans">
      <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 bg-[#080B12] border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
        
        {/* Left Visual Panel */}
        <div className="p-8 md:p-12 bg-gradient-to-br from-[#0D1527] via-[#080E1E] to-[#05070A] flex flex-col justify-between border-b md:border-b-0 md:border-r border-white/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div 
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 cursor-pointer group mb-8"
            >
              <img 
                src="/859e6c870f25da428100d75d2813c557.webp" 
                alt="FlareCloud Logo" 
                className="w-7 h-7 object-contain"
                onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
              />
              <span className="text-lg font-black tracking-wider text-white font-mono">
                FLARE<span className="text-[var(--primary-color)]">CLOUD</span>
              </span>
            </div>

            <div className="space-y-3">
              <span className="text-[10px] text-[var(--primary-color)] font-mono font-black uppercase tracking-widest block">
                CLOUD ACCESS
              </span>
              <h3 className="text-2xl font-black text-white font-mono tracking-tight leading-tight">
                {authMode === 'login' && 'ACCESS YOUR SERVER CONTROL PANEL.'}
                {authMode === 'register' && 'CREATE YOUR FLARECLOUD ACCOUNT.'}
                {authMode === 'forgot' && 'RECOVER YOUR ACCOUNT PASSWORD.'}
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed font-sans">
                Real-time Firebase-backed authentication. Manage your high-performance Minecraft servers with zero friction.
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-white/5 space-y-2 text-xs font-mono text-gray-400">
            <div className="flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Zero-Trust Firebase Encryption</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Realtime Database Synchronized</span>
            </div>
          </div>
        </div>

        {/* Right Form Panel */}
        <div className="p-8 md:p-12 space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-black text-white font-mono uppercase">
              {authMode === 'login' ? 'Sign In' : authMode === 'register' ? 'Register' : 'Reset Password'}
            </h4>
            {authMode !== 'login' && (
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className="text-xs text-gray-400 hover:text-white flex items-center gap-1 font-mono cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Login
              </button>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs font-mono flex items-center gap-2 animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs font-mono flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {authMode !== 'forgot' && (
            <div className="space-y-4">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isGoogleSubmitting || isSubmitting}
                className="w-full py-3 px-4 bg-white/5 hover:bg-white/10 active:bg-white/15 border border-white/15 hover:border-[var(--primary-color)] text-white text-xs font-mono font-bold rounded-xl transition-all flex items-center justify-center gap-3 cursor-pointer shadow-lg hover:shadow-[0_0_20px_rgba(22,119,255,0.25)]"
              >
                {isGoogleSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    CONNECTING TO GOOGLE...
                  </span>
                ) : (
                  <>
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                    <span>CONTINUE WITH GOOGLE</span>
                  </>
                )}
              </button>

              <div className="flex items-center gap-3 my-2">
                <div className="h-px bg-white/10 flex-1" />
                <span className="text-[10px] uppercase font-mono tracking-widest text-gray-500 font-bold">
                  OR WITH EMAIL
                </span>
                <div className="h-px bg-white/10 flex-1" />
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 font-mono text-xs">
            {authMode === 'register' && (
              <>
                <div className="space-y-1">
                  <label className="text-gray-400">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Alex Mercer"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[var(--primary-color)]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-gray-400">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full bg-[#101522] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[var(--primary-color)]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-gray-400">Minecraft Gamertag *</label>
                    <input
                      type="text"
                      required
                      value={minecraftUsername}
                      onChange={(e) => setMinecraftUsername(e.target.value)}
                      placeholder="e.g. Notch"
                      className="w-full bg-[#101522] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[var(--primary-color)]"
                    />
                  </div>
                </div>
              </>
            )}

            <div className="space-y-1">
              <label className="text-gray-400">Email Address *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-[#101522] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[var(--primary-color)]"
              />
            </div>

            {authMode !== 'forgot' && (
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-gray-400">Password *</label>
                  {authMode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('forgot');
                        setErrorMsg('');
                        setSuccessMsg('');
                      }}
                      className="text-[10px] text-[var(--primary-color)] hover:underline cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#101522] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[var(--primary-color)]"
                />
              </div>
            )}

            {authMode === 'register' && (
              <div className="space-y-1">
                <label className="text-gray-400">Confirm Password *</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#101522] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[var(--primary-color)]"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] disabled:opacity-50 text-white font-black font-mono tracking-wider rounded-xl transition-all shadow-[0_0_20px_rgba(22,119,255,0.4)] cursor-pointer mt-2"
            >
              {isSubmitting ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  AUTHENTICATING...
                </span>
              ) : (
                authMode === 'login' ? 'SIGN IN TO PORTAL' : authMode === 'register' ? 'CREATE ACCOUNT' : 'SEND RESET EMAIL'
              )}
            </button>
          </form>

          {/* Toggle Login / Register */}
          <div className="pt-2 text-center text-xs font-mono text-gray-400">
            {authMode === 'login' ? (
              <p>
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('register');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-[var(--primary-color)] font-bold hover:underline cursor-pointer"
                >
                  Create one now
                </button>
              </p>
            ) : authMode === 'register' ? (
              <p>
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('login');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-[var(--primary-color)] font-bold hover:underline cursor-pointer"
                >
                  Sign in
                </button>
              </p>
            ) : null}
          </div>
        </div>

      </div>
    </div>
  );
}
