import React, { useState, useEffect, useRef } from 'react';
import { 
  Check, Shield, Globe, Award, Sparkles, AlertCircle, ShoppingCart, ArrowRight, ArrowLeft, 
  QrCode, Search, Maximize2, ZoomIn, ZoomOut, RotateCcw, X, Copy, ExternalLink, Download, 
  Headphones, Zap, Upload, Image as ImageIcon, CheckCircle, Clock, Server, FileText, ChevronRight
} from 'lucide-react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { createOrderInFirestore, updateOrderPaymentInFirestore, OrderItem } from '../services/firebaseService';

interface Plan {
  name: string;
  ram: string;
  cpu: string;
  ssd: string;
  price: number;
  popular?: boolean;
}

const AVAILABLE_PLANS: Plan[] = [
  { name: 'DIRT', ram: '2GB', cpu: '1 vCPU', ssd: '20GB', price: 99 },
  { name: 'STONE', ram: '4GB', cpu: '2 vCPU', ssd: '40GB', price: 199 },
  { name: 'IRON', ram: '8GB', cpu: '4 vCPU', ssd: '80GB', price: 399, popular: true },
  { name: 'REDSTONE', ram: '16GB', cpu: '6 vCPU', ssd: '160GB', price: 799 },
  { name: 'GOLD', ram: '32GB', cpu: '8 vCPU', ssd: '320GB', price: 1499 },
  { name: 'INFINITY', ram: 'Unlimited', cpu: 'Ryzen 9 7950X', ssd: '1TB NVMe', price: 2999 },
];

const SERVER_TYPES = [
  { name: 'Paper', badge: 'Recommended', desc: 'High performance Spigot fork with modern optimizations' },
  { name: 'Purpur', badge: 'Performance', desc: 'Ultra-optimized Paper fork with extra customization' },
  { name: 'Spigot', badge: 'Popular', desc: 'Standard Minecraft plugin software' },
  { name: 'Fabric', badge: 'Popular', desc: 'Lightweight, modern modding toolchain' },
  { name: 'Forge', badge: 'Mods', desc: 'The classic Minecraft modding ecosystem' },
  { name: 'NeoForge', badge: 'Modern Mods', desc: 'Community-driven modern Forge continuation' },
  { name: 'Vanilla', badge: 'Standard', desc: 'Pure Mojang server software with zero modifications' },
  { name: 'Velocity', badge: 'Proxy', desc: 'Next-generation Minecraft server proxy' },
  { name: 'Bedrock', badge: 'Mobile/Console', desc: 'Official dedicated Bedrock server' },
];

const MINECRAFT_VERSIONS = [
  '1.21.4 (Latest)',
  '1.21.1',
  '1.20.6',
  '1.20.4',
  '1.19.4',
  '1.18.2',
  '1.16.5',
  '1.12.2',
  '1.8.9'
];

interface CheckoutProps {
  selectedPlan: Plan | null;
  user: any;
  customizer: any;
  onNavigate: (view: string) => void;
  onCheckoutComplete: () => void;
}

export default function Checkout({ selectedPlan: initialPlan, user, customizer, onNavigate, onCheckoutComplete }: CheckoutProps) {
  const [currentPlan, setCurrentPlan] = useState<Plan>(initialPlan || AVAILABLE_PLANS[2]);
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'quarterly' | 'annually'>('monthly');
  const [step, setStep] = useState(1);
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  // Step 2: Server Configuration
  const [serverName, setServerName] = useState('FlareCraft Survival');
  const [minecraftEdition, setMinecraftEdition] = useState<'Java' | 'Bedrock' | 'Java + Bedrock'>('Java + Bedrock');
  const [minecraftVersion, setMinecraftVersion] = useState('1.21.4 (Latest)');
  const [serverType, setServerType] = useState('Paper');
  const [serverLocation, setServerLocation] = useState('India');
  const [serverDescription, setServerDescription] = useState('Community SMP realm');
  const [serverErrors, setServerErrors] = useState<{ [key: string]: string }>({});

  // Step 3: Customer Details
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [discordUsername, setDiscordUsername] = useState(user?.discordUsername || '');
  const [minecraftUsername, setMinecraftUsername] = useState(user?.minecraftUsername || '');
  const [customerErrors, setCustomerErrors] = useState<{ [key: string]: string }>({});

  // Step 4: Payment Details
  const [transactionId, setTransactionId] = useState('');
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [copiedVpa, setCopiedVpa] = useState(false);
  const [copiedOrderId, setCopiedOrderId] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // QR Modal & Zoom Controls
  const [isQrZoomed, setIsQrZoomed] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);
  const [touchStartDist, setTouchStartDist] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Step 5: Realtime Firestore Order Tracking
  const [placedOrderId, setPlacedOrderId] = useState<string | null>(null);
  const [liveOrder, setLiveOrder] = useState<OrderItem | null>(null);

  useEffect(() => {
    if (initialPlan) setCurrentPlan(initialPlan);
  }, [initialPlan]);

  // Billing calculation
  const multiplier = billingPeriod === 'quarterly' ? 3 : billingPeriod === 'annually' ? 12 : 1;
  const billingDiscount = billingPeriod === 'quarterly' ? 0.1 : billingPeriod === 'annually' ? 0.25 : 0;
  const rawBase = currentPlan.price * multiplier;
  const periodDiscount = Math.round(rawBase * billingDiscount);
  const baseAfterPeriod = rawBase - periodDiscount;
  const couponDiscount = Math.round((baseAfterPeriod * discountPercent) / 100);
  const finalPrice = Math.max(0, baseAfterPeriod - couponDiscount);

  // Realtime Firestore Subscription for Step 5
  useEffect(() => {
    if (!placedOrderId) return;
    const unsub = onSnapshot(doc(db, 'orders', placedOrderId), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as OrderItem;
        setLiveOrder(data);
      }
    });
    return () => unsub();
  }, [placedOrderId]);

  // Promo coupon validator
  const handleApplyCoupon = async () => {
    setCouponError('');
    setCouponSuccess('');
    const code = couponCode.trim().toUpperCase();
    if (!code) return;

    if (code === 'FLARELAUNCH') {
      setDiscountPercent(20);
      setCouponSuccess('Coupon approved! 20% discount applied.');
    } else if (code === 'MINECRAFT50') {
      setDiscountPercent(50);
      setCouponSuccess('Coupon approved! 50% discount applied.');
    } else {
      setDiscountPercent(0);
      setCouponError('Invalid or expired coupon code.');
    }
  };

  const handleCopyVpa = () => {
    navigator.clipboard.writeText('nitinyg@ptaxis');
    setCopiedVpa(true);
    setTimeout(() => setCopiedVpa(false), 2000);
  };

  const handleCopyOrderId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedOrderId(true);
    setTimeout(() => setCopiedOrderId(false), 2000);
  };

  const validateServerStep = () => {
    const errs: { [key: string]: string } = {};
    if (!serverName.trim()) errs.serverName = 'Server Name is required';
    setServerErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateCustomerStep = () => {
    const errs: { [key: string]: string } = {};
    if (!fullName.trim()) errs.fullName = 'Full Name is required';
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errs.email = 'Valid Email Address is required';
    }
    if (!phone.trim()) errs.phone = 'Phone Number is required for notifications';
    if (!minecraftUsername.trim()) errs.minecraftUsername = 'Minecraft Username is required';
    setCustomerErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNextStep = () => {
    if (step === 2 && !validateServerStep()) return;
    if (step === 3 && !validateCustomerStep()) return;
    setStep(step + 1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePrevStep = () => {
    if (step > 1) {
      setStep(step - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setScreenshotPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Touch gesture handler for mobile pinch zoom
  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      if (touchStartDist === null) {
        setTouchStartDist(dist);
      } else {
        const factor = dist / touchStartDist;
        setZoomScale(prev => Math.min(3, Math.max(0.7, prev * factor)));
        setTouchStartDist(dist);
      }
    }
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transactionId.trim()) {
      setCheckoutError('UPI Transaction ID / UTR is mandatory before submitting payment.');
      return;
    }

    setIsSubmitting(true);
    setCheckoutError('');

    try {
      // 1. Create order record in Firestore
      const newOrderId = await createOrderInFirestore({
        customerEmail: email.trim().toLowerCase(),
        customerId: user?.uid,
        fullName: fullName.trim(),
        phone: phone.trim(),
        discordUsername: discordUsername.trim(),
        minecraftUsername: minecraftUsername.trim(),
        planName: currentPlan.name,
        billingCycle: billingPeriod,
        amount: finalPrice,
        paymentStatus: 'Pending',
        orderStatus: 'Pending',
        date: new Date().toISOString(),
        location: serverLocation,
        serverName: serverName.trim(),
        minecraftEdition,
        minecraftVersion: minecraftVersion.split(' ')[0],
        serverType,
        serverDescription: serverDescription.trim()
      });

      // 2. Submit UPI transaction ID and screenshot proof
      const proofUrl = screenshotPreview || '/Screenshot_20261003-144834.jpg';
      await updateOrderPaymentInFirestore(newOrderId, transactionId.trim(), proofUrl);

      setPlacedOrderId(newOrderId);
      setLiveOrder({
        id: newOrderId,
        customerEmail: email.trim().toLowerCase(),
        fullName: fullName.trim(),
        phone: phone.trim(),
        discordUsername: discordUsername.trim(),
        minecraftUsername: minecraftUsername.trim(),
        planName: currentPlan.name,
        billingCycle: billingPeriod,
        amount: finalPrice,
        paymentStatus: 'Pending',
        orderStatus: 'Processing',
        date: new Date().toISOString(),
        location: serverLocation,
        serverName: serverName.trim(),
        minecraftEdition,
        minecraftVersion: minecraftVersion.split(' ')[0],
        serverType,
        transactionId: transactionId.trim()
      });

      setStep(5);
      window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (err: any) {
      console.error('[CHECKOUT ERROR]', err);
      setCheckoutError(err.message || 'Error processing your order in database.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pt-28 pb-24 max-w-5xl mx-auto px-6 font-sans">
      
      {/* Stepper Header */}
      <div className="flex items-center justify-between mb-10 max-w-2xl mx-auto">
        {[
          { num: 1, label: '01 PLAN' },
          { num: 2, label: '02 CONFIGURE' },
          { num: 3, label: '03 CUSTOMER' },
          { num: 4, label: '04 PAYMENT' },
          { num: 5, label: '05 COMPLETE' },
        ].map((s) => (
          <React.Fragment key={s.num}>
            <div className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2">
              <span
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  step === s.num
                    ? 'bg-[var(--primary-color)] text-white ring-4 ring-blue-500/20 shadow-[0_0_15px_rgba(22,119,255,0.4)]'
                    : step > s.num
                    ? 'bg-emerald-500 text-white'
                    : 'bg-[#101522] text-gray-500 border border-white/5'
                }`}
              >
                {step > s.num ? <Check className="w-3.5 h-3.5" /> : s.num}
              </span>
              <span
                className={`text-[9px] sm:text-xs uppercase font-mono tracking-wider font-bold ${
                  step === s.num ? 'text-white' : 'text-gray-500'
                }`}
              >
                {s.label}
              </span>
            </div>
            {s.num < 5 && (
              <div
                className={`flex-1 h-0.5 mx-1 sm:mx-2 transition-all ${
                  step > s.num ? 'bg-emerald-500' : 'bg-white/5'
                }`}
              />
            )}
          </React.Fragment>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Multi-Step Forms */}
        <div className="lg:col-span-2 bg-[#080B12] border border-white/5 p-6 md:p-8 rounded-2xl shadow-2xl relative overflow-hidden">
          
          {/* STEP 1: PLAN SELECTION & BILLING */}
          {step === 1 && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-[var(--primary-color)] font-bold">Step 1 of 4</span>
                  <h3 className="text-xl font-black text-white tracking-wide mt-0.5">SELECT HOSTING PLAN</h3>
                </div>
                <span className="text-xs text-gray-400 font-mono">Real-time scaling</span>
              </div>

              {/* Plan Switcher Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {AVAILABLE_PLANS.map((plan) => {
                  const isSelected = currentPlan.name === plan.name;
                  return (
                    <button
                      type="button"
                      key={plan.name}
                      onClick={() => setCurrentPlan(plan)}
                      className={`p-3.5 rounded-xl border text-left transition-all relative cursor-pointer ${
                        isSelected
                          ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/10 ring-1 ring-[var(--primary-color)] shadow-[0_0_20px_rgba(22,119,255,0.2)]'
                          : 'border-white/5 bg-[#101522] hover:border-white/20 text-gray-400'
                      }`}
                    >
                      {plan.popular && (
                        <span className="absolute -top-2 right-2 bg-[var(--primary-color)] text-white text-[8px] font-mono font-black uppercase px-1.5 py-0.5 rounded-full">
                          POPULAR
                        </span>
                      )}
                      <h4 className={`text-xs font-black font-mono tracking-wider ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                        {plan.name}
                      </h4>
                      <p className="text-xs font-black text-[var(--primary-color)] font-mono mt-0.5">
                        {plan.ram} RAM
                      </p>
                      <p className="text-[10px] text-gray-500 font-mono mt-0.5">
                        {plan.cpu} · {plan.ssd}
                      </p>
                      <p className="text-xs font-mono font-bold text-white mt-2">
                        ₹{plan.price}<span className="text-[9px] text-gray-500">/mo</span>
                      </p>
                    </button>
                  );
                })}
              </div>

              {/* Billing Cycle */}
              <div className="space-y-2 pt-2">
                <label className="text-[10px] uppercase font-mono tracking-wider text-gray-400 font-bold block">
                  Billing Cycle & Discounts
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'monthly', label: 'Monthly', desc: 'Standard rate' },
                    { id: 'quarterly', label: '6 Months', desc: 'Save 10%' },
                    { id: 'annually', label: 'Yearly', desc: 'Save 25%' },
                  ].map((period) => (
                    <button
                      type="button"
                      key={period.id}
                      onClick={() => setBillingPeriod(period.id as any)}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        billingPeriod === period.id
                          ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/10 text-white ring-1 ring-[var(--primary-color)]'
                          : 'border-white/5 bg-[#101522] text-gray-400 hover:border-white/20'
                      }`}
                    >
                      <span className="text-xs font-bold block font-mono">{period.label}</span>
                      <span className="text-[10px] text-emerald-400 font-mono block mt-0.5">{period.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Coupon Field */}
              <div className="space-y-2 pt-3 border-t border-white/5">
                <label className="text-[10px] uppercase text-gray-400 font-mono tracking-wider font-bold">
                  Discount Coupon
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="e.g. FLARELAUNCH (20% OFF) or MINECRAFT50"
                    className="flex-1 bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="px-5 py-2.5 bg-white/5 border border-white/10 hover:border-white text-xs font-bold text-white rounded-xl transition-all cursor-pointer font-mono"
                  >
                    APPLY
                  </button>
                </div>
                {couponSuccess && (
                  <p className="text-emerald-400 text-xs flex items-center gap-1.5 font-mono">
                    <CheckCircle className="w-3.5 h-3.5" /> {couponSuccess}
                  </p>
                )}
                {couponError && (
                  <p className="text-red-400 text-xs flex items-center gap-1.5 font-mono">
                    <AlertCircle className="w-3.5 h-3.5" /> {couponError}
                  </p>
                )}
              </div>

              {/* CTA */}
              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="flex items-center gap-2 px-8 py-3.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-black font-mono tracking-wider rounded-xl hover:scale-105 transition-all shadow-[0_0_25px_rgba(22,119,255,0.4)] cursor-pointer"
                >
                  NEXT: CONFIGURE SERVER <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: QUICK SERVER SETUP & CONFIGURATION */}
          {step === 2 && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-[var(--primary-color)] font-bold">Step 2 of 4</span>
                  <h3 className="text-xl font-black text-white tracking-wide mt-0.5">QUICK SERVER SETUP</h3>
                </div>
                <span className="text-xs text-gray-400 font-mono">Deploy in minutes</span>
              </div>

              <div className="space-y-5">
                {/* Server Name */}
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold flex justify-between">
                    <span>Server Name <span className="text-red-400">*</span></span>
                    {serverErrors.serverName && <span className="text-red-400 normal-case">{serverErrors.serverName}</span>}
                  </label>
                  <input
                    type="text"
                    required
                    value={serverName}
                    onChange={(e) => {
                      setServerName(e.target.value);
                      if (serverErrors.serverName) setServerErrors({ ...serverErrors, serverName: '' });
                    }}
                    placeholder="e.g. FlareCraft Survival"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)]"
                  />
                </div>

                {/* Platform Edition */}
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold block">
                    Minecraft Edition
                  </label>
                  <div className="grid grid-cols-3 gap-2.5">
                    {(['Java', 'Bedrock', 'Java + Bedrock'] as const).map((edition) => (
                      <button
                        type="button"
                        key={edition}
                        onClick={() => setMinecraftEdition(edition)}
                        className={`py-3 px-2 text-xs font-bold font-mono border rounded-xl transition-all cursor-pointer text-center ${
                          minecraftEdition === edition
                            ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/10 text-white ring-1 ring-[var(--primary-color)]'
                            : 'border-white/5 bg-[#101522] text-gray-400 hover:border-white/20'
                        }`}
                      >
                        {edition}
                        {edition === 'Java + Bedrock' && (
                          <span className="block text-[8px] text-emerald-400 uppercase mt-0.5">GeyserMC Crossplay</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Version & Server Type Selectors */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase text-gray-400 font-mono font-bold block">
                      Minecraft Version
                    </label>
                    <select
                      value={minecraftVersion}
                      onChange={(e) => setMinecraftVersion(e.target.value)}
                      className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                    >
                      {MINECRAFT_VERSIONS.map(v => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase text-gray-400 font-mono font-bold block">
                      Server Type
                    </label>
                    <select
                      value={serverType}
                      onChange={(e) => setServerType(e.target.value)}
                      className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                    >
                      {SERVER_TYPES.map(st => (
                        <option key={st.name} value={st.name}>{st.name} ({st.badge})</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Server Type Cards */}
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold block">
                    Choose Server Software
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {SERVER_TYPES.slice(0, 6).map((st) => (
                      <button
                        type="button"
                        key={st.name}
                        onClick={() => setServerType(st.name)}
                        className={`p-2.5 text-left border rounded-xl transition-all cursor-pointer ${
                          serverType === st.name
                            ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/10 text-white'
                            : 'border-white/5 bg-[#101522] text-gray-400 hover:border-white/20'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-white font-mono">{st.name}</span>
                          <span className="text-[8px] px-1.5 py-0.5 rounded bg-white/5 font-mono text-[var(--primary-color)]">
                            {st.badge}
                          </span>
                        </div>
                        <p className="text-[9px] text-gray-500 mt-1 line-clamp-1">{st.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Deployment Location */}
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold block">
                    Deployment Region
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      { name: 'India', flag: '🇮🇳', desc: 'Mumbai' },
                      { name: 'Singapore', flag: '🇸🇬', desc: 'Changi' },
                      { name: 'Germany', flag: '🇩🇪', desc: 'Frankfurt' },
                      { name: 'USA', flag: '🇺🇸', desc: 'Ashburn' }
                    ].map((loc) => (
                      <button
                        type="button"
                        key={loc.name}
                        onClick={() => setServerLocation(loc.name)}
                        className={`p-3 rounded-xl border text-left transition-all relative cursor-pointer ${
                          serverLocation === loc.name
                            ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/10 text-white ring-1 ring-[var(--primary-color)]'
                            : 'border-white/5 bg-[#101522] text-gray-400 hover:border-white/20'
                        }`}
                      >
                        <span className="text-lg">{loc.flag}</span>
                        <h5 className="text-xs font-bold text-white font-mono mt-1">{loc.name}</h5>
                        <p className="text-[9px] text-gray-500 font-mono">{loc.desc}</p>
                        {serverLocation === loc.name && (
                          <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={handlePrevStep}
                  className="flex items-center gap-1.5 py-2.5 text-xs font-mono font-bold text-gray-400 hover:text-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" /> BACK
                </button>
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="flex items-center gap-2 px-8 py-3.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-black font-mono tracking-wider rounded-xl hover:scale-105 transition-all shadow-[0_0_25px_rgba(22,119,255,0.4)] cursor-pointer"
                >
                  NEXT: CUSTOMER DETAILS <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: CUSTOMER DETAILS */}
          {step === 3 && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-[var(--primary-color)] font-bold">Step 3 of 4</span>
                  <h3 className="text-xl font-black text-white tracking-wide mt-0.5">CUSTOMER DETAILS</h3>
                </div>
                <span className="text-xs text-gray-400 font-mono">Authentication binding</span>
              </div>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold flex justify-between">
                    <span>Full Name <span className="text-red-400">*</span></span>
                    {customerErrors.fullName && <span className="text-red-400 normal-case">{customerErrors.fullName}</span>}
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => {
                      setFullName(e.target.value);
                      if (customerErrors.fullName) setCustomerErrors({ ...customerErrors, fullName: '' });
                    }}
                    placeholder="e.g. Alex Mercer"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold flex justify-between">
                    <span>Email Address <span className="text-red-400">*</span></span>
                    {customerErrors.email && <span className="text-red-400 normal-case">{customerErrors.email}</span>}
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (customerErrors.email) setCustomerErrors({ ...customerErrors, email: '' });
                    }}
                    placeholder="alex@gmail.com"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-bold flex justify-between">
                    <span>Phone Number <span className="text-red-400">*</span></span>
                    {customerErrors.phone && <span className="text-red-400 normal-case">{customerErrors.phone}</span>}
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (customerErrors.phone) setCustomerErrors({ ...customerErrors, phone: '' });
                    }}
                    placeholder="+91 98765 43210"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase text-gray-400 font-mono font-bold">
                      Discord Username
                    </label>
                    <input
                      type="text"
                      value={discordUsername}
                      onChange={(e) => setDiscordUsername(e.target.value)}
                      placeholder="e.g. alex_mc"
                      className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase text-gray-400 font-mono font-bold flex justify-between">
                      <span>Minecraft Gamertag <span className="text-red-400">*</span></span>
                      {customerErrors.minecraftUsername && <span className="text-red-400 normal-case">{customerErrors.minecraftUsername}</span>}
                    </label>
                    <input
                      type="text"
                      required
                      value={minecraftUsername}
                      onChange={(e) => {
                        setMinecraftUsername(e.target.value);
                        if (customerErrors.minecraftUsername) setCustomerErrors({ ...customerErrors, minecraftUsername: '' });
                      }}
                      placeholder="e.g. Notch"
                      className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={handlePrevStep}
                  className="flex items-center gap-1.5 py-2.5 text-xs font-mono font-bold text-gray-400 hover:text-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" /> BACK
                </button>
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="flex items-center gap-2 px-8 py-3.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-black font-mono tracking-wider rounded-xl hover:scale-105 transition-all shadow-[0_0_25px_rgba(22,119,255,0.4)] cursor-pointer"
                >
                  NEXT: UPI PAYMENT <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: UPI PAYMENT WITH EXACT QR */}
          {step === 4 && (
            <form onSubmit={handlePlaceOrder} className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-[var(--primary-color)] font-bold">Step 4 of 4</span>
                  <h3 className="text-xl font-black text-white tracking-wide mt-0.5">MANUAL UPI PAYMENT</h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-mono text-gray-400 block">Total Due</span>
                  <span className="text-lg font-black text-white font-mono">₹{finalPrice}</span>
                </div>
              </div>

              {/* FlareCloud UPI Flyer Presentation */}
              <div className="relative overflow-hidden rounded-2xl border-2 border-[#1677FF]/40 bg-gradient-to-b from-[#080E1E] via-[#050914] to-[#040710] p-6 shadow-[0_0_50px_rgba(22,119,255,0.2)] text-center">
                <div className="flex justify-between items-center text-[9px] uppercase tracking-widest text-slate-400 font-mono font-bold mb-4 pb-2 border-b border-white/5">
                  <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span> FAST · SECURE · RELIABLE</span>
                  <span className="text-blue-400">PLAY · GROW · BELONG</span>
                </div>

                <div className="flex flex-col items-center justify-center gap-1 mb-4">
                  <div className="flex items-center gap-2">
                    <img 
                      src="/859e6c870f25da428100d75d2813c557.webp" 
                      alt="FlareCloud Logo" 
                      className="w-7 h-7 object-contain"
                      onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                    />
                    <h4 className="text-xl font-black tracking-wider text-white font-mono">
                      FLARE<span className="text-[#1677FF]">CLOUD</span>
                    </h4>
                  </div>
                  <div className="flex items-center gap-2 text-[9px] tracking-widest text-slate-400 font-mono uppercase">
                    <span className="w-8 h-px bg-blue-500/50"></span>
                    <span>MINECRAFT SERVER HOSTING</span>
                    <span className="w-8 h-px bg-blue-500/50"></span>
                  </div>
                </div>

                {/* Central QR Code in Frame */}
                <div className="flex flex-col items-center justify-center my-3">
                  <div 
                    onClick={() => {
                      setZoomScale(1);
                      setIsQrZoomed(true);
                    }}
                    className="relative group cursor-pointer p-3.5 bg-white rounded-2xl border-4 border-[#1677FF] shadow-[0_0_35px_rgba(22,119,255,0.6)] transition-all hover:scale-105"
                    title="Click to Enlarge / Fullscreen QR"
                  >
                    <img
                      src="/Screenshot_20261003-144834.jpg"
                      alt="FlareCloud UPI QR Code"
                      className="w-48 h-48 sm:w-56 sm:h-56 object-contain rounded-lg"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        if (!target.src.includes('/api/qr-image')) {
                          target.src = '/api/qr-image';
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-black/50 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="bg-black/90 text-white text-xs px-3.5 py-1.5 rounded-full font-mono flex items-center gap-1.5 shadow-2xl border border-white/20">
                        <Maximize2 className="w-3.5 h-3.5" /> Fullscreen / Zoom
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 mt-3">
                    <span className="text-[10px] text-slate-300 font-mono tracking-widest font-extrabold uppercase">
                      — SCAN TO PAY —
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setZoomScale(1);
                        setIsQrZoomed(true);
                      }}
                      className="text-[10px] font-mono text-blue-400 hover:text-white flex items-center gap-1 underline underline-offset-2 cursor-pointer"
                    >
                      <Maximize2 className="w-3 h-3" /> Enlarge
                    </button>
                    <a
                      href="/Screenshot_20261003-144834.jpg"
                      download="flarecloud-upi-qr.jpg"
                      className="text-[10px] font-mono text-blue-400 hover:text-white flex items-center gap-1 underline underline-offset-2 cursor-pointer"
                    >
                      <Download className="w-3 h-3" /> Save QR
                    </a>
                  </div>
                </div>

                {/* 1-Click Copy UPI ID */}
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#0D1527] border border-[#1677FF]/60 rounded-full shadow-inner my-2">
                  <span className="w-2 h-2 rounded-full bg-[#1677FF] animate-pulse"></span>
                  <span className="text-xs font-mono text-slate-300 font-bold">UPI ID:</span>
                  <span className="text-xs font-mono text-white font-black select-all">nitinyg@ptaxis</span>
                  <button
                    type="button"
                    onClick={handleCopyVpa}
                    className="ml-2 px-2.5 py-1 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 hover:text-white text-[10px] font-mono rounded cursor-pointer transition-colors flex items-center gap-1"
                  >
                    {copiedVpa ? <><Check className="w-3 h-3 text-emerald-400" /> Copied!</> : <><Copy className="w-3 h-3" /> Copy ID</>}
                  </button>
                </div>

                {/* Mobile Pay Launcher */}
                <div className="my-2.5">
                  <a
                    href={`upi://pay?pa=nitinyg@ptaxis&pn=FlareCloud&cu=INR&am=${finalPrice}`}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1677FF] hover:bg-[#2684FF] text-white text-xs font-bold font-mono rounded-xl shadow-lg transition-transform hover:scale-105"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> Pay with UPI App (GPay / PhonePe / Paytm)
                  </a>
                </div>
              </div>

              {/* Payment Verification Form */}
              <div className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-black flex justify-between">
                    <span>12-Digit Transaction Reference / UTR <span className="text-red-400">*</span></span>
                    <span className="text-gray-500 font-normal">Required for verification</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    placeholder="e.g. 427819381029 or Bank Reference number"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono font-bold tracking-wider"
                  />
                </div>

                {/* Screenshot Proof */}
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase text-gray-400 font-mono font-black flex justify-between">
                    <span>Payment Screenshot Proof</span>
                    <span className="text-gray-500 font-normal">Speeds up verification</span>
                  </label>

                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleScreenshotChange}
                    className="hidden"
                  />

                  {screenshotPreview ? (
                    <div className="p-3 bg-[#101522] border border-white/10 rounded-xl flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <img
                          src={screenshotPreview}
                          alt="Screenshot Proof"
                          className="w-14 h-14 object-cover rounded-lg border border-white/10 shrink-0"
                        />
                        <div className="overflow-hidden">
                          <p className="text-xs font-mono font-bold text-white truncate">Payment Receipt Screenshot</p>
                          <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-0.5">
                            <CheckCircle className="w-3 h-3" /> Proof attached
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setScreenshotPreview(null)}
                        className="px-3 py-1.5 text-xs text-red-400 hover:text-white hover:bg-red-500/20 rounded-lg font-mono transition-colors cursor-pointer"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="p-5 border-2 border-dashed border-white/10 hover:border-[var(--primary-color)]/50 rounded-xl bg-[#101522]/50 hover:bg-[#101522] transition-all text-center cursor-pointer group"
                    >
                      <Upload className="w-6 h-6 text-gray-400 group-hover:text-[var(--primary-color)] mx-auto mb-2 transition-colors" />
                      <span className="text-xs font-mono font-bold text-white block">
                        Upload Payment Screenshot
                      </span>
                      <span className="text-[10px] text-gray-500 font-mono mt-0.5 block">
                        Click to browse or drag & drop (JPG, PNG, WEBP)
                      </span>
                    </div>
                  )}
                </div>

                {checkoutError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs font-mono flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{checkoutError}</span>
                  </div>
                )}
              </div>

              {/* Navigation CTAs */}
              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={handlePrevStep}
                  className="flex items-center gap-1.5 py-2.5 text-xs font-mono font-bold text-gray-400 hover:text-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" /> BACK
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-8 py-4 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-black font-mono tracking-wider rounded-xl hover:scale-105 transition-all shadow-[0_0_30px_rgba(16,185,129,0.4)] cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                      SUBMITTING PAYMENT...
                    </>
                  ) : (
                    <>
                      SUBMIT PAYMENT VERIFICATION <Check className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* STEP 5: CONFIRMATION / ORDER PLACED (REALTIME SYNCED) */}
          {step === 5 && (
            <div className="space-y-6 animate-fade-in text-center py-4">
              <div className="w-16 h-16 bg-emerald-500/10 border-2 border-emerald-500 text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(16,185,129,0.3)]">
                <Check className="w-8 h-8" />
              </div>

              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-400 font-black">
                  SUCCESSFULLY LOGGED IN DATABASE
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-white tracking-wide mt-1">
                  ORDER PLACED
                </h2>
                <p className="text-xs text-gray-400 mt-2 max-w-md mx-auto font-mono">
                  Payment submitted successfully. Your payment is awaiting verification.
                </p>
              </div>

              {/* Order Status Card */}
              <div className="p-6 bg-[#101522] border border-white/5 rounded-2xl max-w-lg mx-auto text-left space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <span className="text-xs text-gray-400 font-mono uppercase">Order ID</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-white font-mono">{placedOrderId}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyOrderId(placedOrderId!)}
                      className="text-gray-400 hover:text-white cursor-pointer"
                    >
                      {copiedOrderId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <span className="text-xs text-gray-400 font-mono uppercase">Selected Plan</span>
                  <span className="text-xs font-extrabold text-[var(--primary-color)] font-mono uppercase">
                    {currentPlan.name} ({currentPlan.ram} RAM)
                  </span>
                </div>

                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <span className="text-xs text-gray-400 font-mono uppercase">Amount</span>
                  <span className="text-sm font-black text-white font-mono">₹{finalPrice}</span>
                </div>

                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <span className="text-xs text-gray-400 font-mono uppercase">Payment Status</span>
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-black uppercase flex items-center gap-1 ${
                    liveOrder?.paymentStatus === 'Paid'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse'
                  }`}>
                    {liveOrder?.paymentStatus === 'Paid' ? (
                      <><CheckCircle className="w-3 h-3" /> VERIFIED & PAID</>
                    ) : (
                      <><Clock className="w-3 h-3" /> AWAITING VERIFICATION</>
                    )}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400 font-mono uppercase">Order Status</span>
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-black uppercase flex items-center gap-1 ${
                    liveOrder?.orderStatus === 'Active'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  }`}>
                    {liveOrder?.orderStatus === 'Active' ? (
                      <><Server className="w-3 h-3" /> ACTIVE SERVER</>
                    ) : (
                      <><Zap className="w-3 h-3" /> PROCESSING PROVISION</>
                    )}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2 max-w-lg mx-auto">
                <button
                  type="button"
                  onClick={() => onNavigate('customer-portal')}
                  className="flex-1 py-3 px-5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-black font-mono tracking-wider rounded-xl transition-all shadow-[0_0_20px_rgba(22,119,255,0.4)] cursor-pointer"
                >
                  GO TO DASHBOARD
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('customer-portal')}
                  className="py-3 px-5 bg-white/5 hover:bg-white/10 text-white text-xs font-bold font-mono tracking-wider rounded-xl border border-white/10 transition-all cursor-pointer"
                >
                  VIEW ORDER INVOICE
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('support')}
                  className="py-3 px-5 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold font-mono tracking-wider rounded-xl border border-white/10 transition-all cursor-pointer"
                >
                  CONTACT SUPPORT
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Order Summary (Visible across all steps) */}
        <div className="space-y-6">
          <div className="bg-[#080B12] border border-white/5 p-6 rounded-2xl shadow-xl space-y-5">
            <h4 className="text-sm font-black text-white uppercase tracking-wider font-mono border-b border-white/5 pb-3">
              ORDER SUMMARY
            </h4>

            {/* Plan Info */}
            <div className="space-y-1">
              <div className="flex justify-between items-baseline">
                <span className="text-base font-black text-white font-mono">{currentPlan.name} PLAN</span>
                <span className="text-xs font-mono font-bold text-[var(--primary-color)] uppercase">
                  {billingPeriod}
                </span>
              </div>
              <p className="text-xs text-gray-400 font-mono">
                {currentPlan.ram} RAM · {currentPlan.cpu} · {currentPlan.ssd}
              </p>
            </div>

            {/* Configuration Details */}
            <div className="space-y-2 text-xs font-mono pt-3 border-t border-white/5">
              <div className="flex justify-between text-gray-400">
                <span>Location</span>
                <span className="text-white font-bold">{serverLocation}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Edition</span>
                <span className="text-white font-bold">{minecraftEdition}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Version</span>
                <span className="text-white font-bold">{minecraftVersion.split(' ')[0]}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Server Type</span>
                <span className="text-white font-bold">{serverType}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>DDoS Shield</span>
                <span className="text-emerald-400 font-bold">12 Tbps Mitigation</span>
              </div>
            </div>

            {/* Pricing Breakdown */}
            <div className="space-y-2 text-xs font-mono pt-3 border-t border-white/5">
              <div className="flex justify-between text-gray-400">
                <span>Base Rate ({multiplier} mo)</span>
                <span>₹{rawBase}</span>
              </div>
              {periodDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Period Savings</span>
                  <span>-₹{periodDiscount}</span>
                </div>
              )}
              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Promo Coupon ({discountPercent}%)</span>
                  <span>-₹{couponDiscount}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-black text-white pt-2 border-t border-white/5">
                <span>Total Due</span>
                <span className="text-white font-mono">₹{finalPrice}</span>
              </div>
            </div>

            {/* SLA Badges */}
            <div className="space-y-2 pt-3 border-t border-white/5 text-[11px] text-gray-400 font-mono">
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Instant automated provisioning</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>99.9% Uptime SLA guaranteed</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>24/7 Expert Minecraft Support</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FULLSCREEN ZOOMABLE QR MODAL */}
      {isQrZoomed && (
        <div 
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-fade-in"
          onClick={() => setIsQrZoomed(false)}
        >
          <div 
            className="flex items-center justify-between w-full max-w-lg mb-4 text-white font-mono text-xs z-10"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="font-bold flex items-center gap-2">
              <QrCode className="w-4 h-4 text-blue-400" /> FlareCloud UPI QR
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setZoomScale(prev => Math.min(3, prev + 0.25))}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setZoomScale(prev => Math.max(0.5, prev - 0.25))}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setZoomScale(1)}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg cursor-pointer"
                title="Reset Zoom"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <a
                href="/Screenshot_20261003-144834.jpg"
                download="flarecloud-upi-qr.jpg"
                className="p-2 bg-white/10 hover:bg-white/20 rounded-lg cursor-pointer text-white"
                title="Download QR"
              >
                <Download className="w-4 h-4" />
              </a>
              <button
                type="button"
                onClick={() => setIsQrZoomed(false)}
                className="p-2 bg-white/10 hover:bg-red-500/80 rounded-lg cursor-pointer"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div 
            className="relative overflow-auto max-w-full max-h-[80vh] flex items-center justify-center p-4"
            onClick={(e) => e.stopPropagation()}
            onTouchMove={handleTouchMove}
            onTouchEnd={() => setTouchStartDist(null)}
          >
            <div 
              style={{ transform: `scale(${zoomScale})`, transition: 'transform 0.15s ease-out' }}
              className="bg-white p-5 rounded-2xl border-4 border-[#1677FF] shadow-[0_0_50px_rgba(22,119,255,0.8)]"
            >
              <img
                src="/Screenshot_20261003-144834.jpg"
                alt="FlareCloud UPI QR Code Fullscreen"
                className="max-w-[85vw] max-h-[65vh] object-contain select-none"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  if (!target.src.includes('/api/qr-image')) {
                    target.src = '/api/qr-image';
                  }
                }}
              />
            </div>
          </div>

          <div 
            className="mt-4 text-center text-slate-400 font-mono text-[11px] space-y-1 z-10"
            onClick={(e) => e.stopPropagation()}
          >
            <p>Pinch or use zoom buttons to resize · UPI ID: <b className="text-white">nitinyg@ptaxis</b></p>
            <p className="text-[10px] text-slate-500">Click anywhere outside to close</p>
          </div>
        </div>
      )}
    </div>
  );
}
