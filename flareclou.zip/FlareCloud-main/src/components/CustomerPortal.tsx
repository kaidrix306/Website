import React, { useState, useEffect, useRef } from 'react';
import { 
  Server, LayoutDashboard, CreditCard, LifeBuoy, Bell, User, Cpu, HardDrive, 
  RefreshCw, Play, Square, Send, ChevronRight, AlertCircle, CheckCircle, Clock, 
  MessageSquare, Plus, FileText, Globe, Terminal, Activity, ArrowRight, Shield, 
  Trash2, Edit3, Download, Search, Copy, Check, ExternalLink, Folder, File, 
  Users, UserCheck, UserX, Sliders, Settings, Calendar, CloudLightning, X, Eye, Layers
} from 'lucide-react';
import { 
  subscribeToCustomerServers, subscribeToCustomerOrders, subscribeToCustomerTickets, 
  subscribeToNotifications, createTicketInFirestore, replyToTicketInFirestore, 
  markNotificationAsRead, updateServerParametersInFirestore, 
  MinecraftServerData, OrderItem, SupportTicketItem, NotificationItem 
} from '../services/firebaseService';

interface CustomerPortalProps {
  user: any;
  customizer: any;
  onNavigate: (view: string) => void;
  onSelectPlanForCheckout: (plan: any) => void;
}

export default function CustomerPortal({ user, customizer, onNavigate, onSelectPlanForCheckout }: CustomerPortalProps) {
  // Main Portal Navigation
  const [activeNav, setActiveNav] = useState<'servers' | 'orders' | 'support' | 'notifications' | 'profile'>('servers');
  
  // Realtime Data from Firebase
  const [servers, setServers] = useState<MinecraftServerData[]>([]);
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [tickets, setTickets] = useState<SupportTicketItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Server Detail View & Sub-Tabs (SkilloraClouds Style)
  const [selectedServerId, setSelectedServerId] = useState<string | null>(null);
  const [serverSubTab, setServerSubTab] = useState<
    'overview' | 'console' | 'files' | 'players' | 'backups' | 'schedules' | 'plugins' | 'mods' | 'startup' | 'settings'
  >('overview');

  // Console State
  const [commandInput, setCommandInput] = useState('');
  const [consoleSearch, setConsoleSearch] = useState('');
  const [consoleLogs, setConsoleLogs] = useState<string[]>([]);
  const consoleBottomRef = useRef<HTMLDivElement>(null);

  // File Manager State
  const [fileList, setFileList] = useState<Array<{ name: string; isFolder: boolean; size: string; modified: string; content?: string }>>([]);
  const [editingFile, setEditingFile] = useState<{ name: string; content: string } | null>(null);
  const [fileSearch, setFileSearch] = useState('');
  const [newFileName, setNewFileName] = useState('');
  const [isCreatingFile, setIsCreatingFile] = useState(false);

  // Player Management State
  const [newPlayerName, setNewPlayerName] = useState('');
  const [playersList, setPlayersList] = useState<Array<{ name: string; uuid: string; online: boolean; op: boolean; whitelisted: boolean; banned: boolean }>>([]);

  // Backups & Schedules
  const [backupsList, setBackupsList] = useState<Array<{ id: string; name: string; size: string; date: string }>>([]);
  const [schedulesList, setSchedulesList] = useState<Array<{ id: string; name: string; action: string; schedule: string; enabled: boolean }>>([]);
  const [newScheduleName, setNewScheduleName] = useState('');
  const [newScheduleAction, setNewScheduleAction] = useState('Restart Server');
  const [newScheduleTime, setNewScheduleTime] = useState('Daily at 04:00 AM');

  // Plugins & Mods State
  const [pluginSearch, setPluginSearch] = useState('');
  const [installedPlugins, setInstalledPlugins] = useState<Array<{ name: string; version: string; category: string; installed: boolean }>>([]);

  // Support Ticket Form State
  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState<'Billing' | 'Payment' | 'Server' | 'Technical' | 'Account' | 'Other'>('Technical');
  const [ticketPriority, setTicketPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [ticketMessage, setTicketMessage] = useState('');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState('');

  // Invoice Modal State
  const [viewingInvoice, setViewingInvoice] = useState<OrderItem | null>(null);

  // Copy Feedback
  const [copiedIp, setCopiedIp] = useState(false);

  // --- Realtime Subscriptions to Firebase ---
  useEffect(() => {
    if (!user?.email) {
      setLoading(false);
      return;
    }

    const unsubServers = subscribeToCustomerServers(user.email, (srvs) => {
      setServers(srvs);
      if (srvs.length > 0 && !selectedServerId) {
        setSelectedServerId(srvs[0].id);
      }
      setLoading(false);
    });

    const unsubOrders = subscribeToCustomerOrders(user.email, (ords) => {
      setOrders(ords);
    });

    const unsubTickets = subscribeToCustomerTickets(user.email, (tcks) => {
      setTickets(tcks);
    });

    const unsubNotifications = subscribeToNotifications(user.email, (ntfs) => {
      setNotifications(ntfs);
    });

    return () => {
      unsubServers();
      unsubOrders();
      unsubTickets();
      unsubNotifications();
    };
  }, [user?.email]);

  // Sync active server details to local state when selectedServerId changes
  const activeServer = servers.find(s => s.id === selectedServerId) || servers[0];

  useEffect(() => {
    if (activeServer) {
      setConsoleLogs(activeServer.logs || [
        `[${new Date().toLocaleTimeString()} INFO]: Initializing Minecraft container for ${activeServer.name}...`,
        `[${new Date().toLocaleTimeString()} INFO]: Listening on ${activeServer.ip}:${activeServer.port}`
      ]);
      setFileList(activeServer.files || [
        { name: 'server.properties', isFolder: false, size: '1.2 KB', modified: 'Recent', content: 'motd=FlareCloud Minecraft Server\nserver-port=25565\npvp=true\ndifficulty=normal\nmax-players=80' },
        { name: 'bukkit.yml', isFolder: false, size: '2.4 KB', modified: 'Recent', content: 'settings:\n  allow-end: true\n  warn-on-overload: false' },
        { name: 'spigot.yml', isFolder: false, size: '3.1 KB', modified: 'Recent', content: 'config-version: 12\nworld-settings:\n  default:\n    entity-tracking-range:\n      players: 48' },
        { name: 'ops.json', isFolder: false, size: '64 B', modified: 'Recent', content: '[]' },
        { name: 'whitelist.json', isFolder: false, size: '64 B', modified: 'Recent', content: '[]' },
        { name: 'plugins', isFolder: true, size: '4 KB', modified: 'Recent' },
        { name: 'world', isFolder: true, size: '14.2 MB', modified: 'Recent' }
      ]);
      setPlayersList(activeServer.players || [
        { name: user?.minecraftUsername || 'Owner', uuid: '00000000-0000-0000-0000-000000000000', online: false, op: true, whitelisted: true, banned: false }
      ]);
      setBackupsList(activeServer.backups || []);
      setSchedulesList(activeServer.schedules || [
        { id: 'sch-1', name: 'Daily World Backup', action: 'Create Backup', schedule: 'Daily at 04:00 AM', enabled: true },
        { id: 'sch-2', name: 'Auto RAM Garbage Recycle', action: 'Restart Server', schedule: 'Weekly on Sunday', enabled: true }
      ]);
      setInstalledPlugins(activeServer.plugins || [
        { name: 'Geyser-Spigot', version: '2.2.0', category: 'Crossplay', installed: true },
        { name: 'Floodgate', version: '2.2.0', category: 'Authentication', installed: true },
        { name: 'ViaVersion', version: '4.9.0', category: 'Compatibility', installed: true },
        { name: 'EssentialsX', version: '2.20.1', category: 'Administration', installed: true },
        { name: 'CoreProtect', version: '22.2', category: 'Anti-Grief', installed: true },
        { name: 'LuckPerms', version: '5.4.102', category: 'Permissions', installed: false },
        { name: 'WorldEdit', version: '7.3.0', category: 'World', installed: false },
        { name: 'Vault', version: '1.7.3', category: 'Economy', installed: false }
      ]);
    }
  }, [selectedServerId, servers]);

  const handleCopyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopiedIp(true);
    setTimeout(() => setCopiedIp(false), 2000);
  };

  // Power actions
  const handlePowerAction = async (action: 'START' | 'STOP' | 'RESTART') => {
    if (!activeServer) return;
    const time = new Date().toLocaleTimeString();
    let newStatus = activeServer.status;
    let newLogs = [...consoleLogs];

    if (action === 'START') {
      newStatus = 'ONLINE';
      newLogs.push(`[${time} INFO]: Start signal sent. Server container online.`);
    } else if (action === 'STOP') {
      newStatus = 'OFFLINE';
      newLogs.push(`[${time} INFO]: Shutdown signal processed. Server process terminated.`);
    } else if (action === 'RESTART') {
      newStatus = 'RESTARTING';
      newLogs.push(`[${time} INFO]: Recycling server process and memory allocation...`);
      setTimeout(() => {
        updateServerParametersInFirestore(activeServer.id, {
          status: 'ONLINE',
          logs: [...newLogs, `[${new Date().toLocaleTimeString()} INFO]: Server restarted successfully.`]
        });
      }, 3000);
    }

    setConsoleLogs(newLogs);
    await updateServerParametersInFirestore(activeServer.id, {
      status: newStatus,
      logs: newLogs
    });
  };

  // Console Command Execution
  const handleSendCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim() || !activeServer) return;

    const cmd = commandInput.trim();
    const time = new Date().toLocaleTimeString();
    const updated = [...consoleLogs, `> ${cmd}`];

    if (activeServer.status !== 'ONLINE') {
      updated.push(`[${time} WARN]: Cannot execute command. Server container is currently ${activeServer.status}.`);
    } else {
      if (cmd.startsWith('/op ')) {
        const target = cmd.replace('/op ', '');
        updated.push(`[${time} INFO]: Made ${target} a server operator`);
      } else if (cmd.startsWith('/whitelist add ')) {
        const target = cmd.replace('/whitelist add ', '');
        updated.push(`[${time} INFO]: Added ${target} to the whitelist`);
      } else if (cmd.startsWith('/say ')) {
        updated.push(`[${time} INFO]: [Server] ${cmd.replace('/say ', '')}`);
      } else if (cmd === '/tps') {
        updated.push(`[${time} INFO]: TPS from last 1m, 5m, 15m: 20.0, 20.0, 19.98`);
      } else {
        updated.push(`[${time} INFO]: Command processed: ${cmd}`);
      }
    }

    setConsoleLogs(updated);
    setCommandInput('');
    await updateServerParametersInFirestore(activeServer.id, { logs: updated });
    
    setTimeout(() => {
      consoleBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // Create Support Ticket
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketMessage.trim() || !user?.email) return;

    try {
      await createTicketInFirestore(user.email, ticketSubject.trim(), ticketCategory, ticketPriority, ticketMessage.trim());
      setTicketSubject('');
      setTicketMessage('');
      setIsCreatingTicket(false);
      alert('Support ticket created successfully!');
    } catch {
      alert('Failed to submit ticket.');
    }
  };

  // Reply to Ticket
  const handleReplyTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketReplyText.trim() || !selectedTicketId || !user?.email) return;

    try {
      await replyToTicketInFirestore(selectedTicketId, user.email, ticketReplyText.trim());
      setTicketReplyText('');
    } catch {
      alert('Failed to send reply.');
    }
  };

  // Selected Ticket Object
  const currentTicket = tickets.find(t => t.id === selectedTicketId);
  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6 font-sans">
      
      {/* Customer Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6 mb-8">
        <div>
          <span className="text-[10px] text-[var(--primary-color)] font-mono font-black uppercase tracking-widest">
            CUSTOMER CLOUD PORTAL
          </span>
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-wide mt-1 font-mono">
            WELCOME, {user?.fullName?.toUpperCase() || 'COMMANDER'}
          </h2>
          <p className="text-xs text-gray-400 font-mono mt-0.5">
            {user?.email} · Gamertag: <span className="text-white font-bold">{user?.minecraftUsername || 'Not set'}</span>
          </p>
        </div>

        {/* Portal Top Bar Tabs */}
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'servers', label: 'My Servers', icon: <Server className="w-4 h-4" />, count: servers.length },
            { id: 'orders', label: 'Billing & Invoices', icon: <CreditCard className="w-4 h-4" />, count: orders.length },
            { id: 'support', label: 'Support Desk', icon: <LifeBuoy className="w-4 h-4" />, count: tickets.length },
            { id: 'notifications', label: 'Alerts', icon: <Bell className="w-4 h-4" />, badge: unreadNotificationsCount },
            { id: 'profile', label: 'Profile', icon: <User className="w-4 h-4" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveNav(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                activeNav === tab.id
                  ? 'bg-[var(--primary-color)] text-white shadow-[0_0_15px_rgba(22,119,255,0.4)]'
                  : 'bg-[#101522] text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {typeof tab.count === 'number' && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/30 text-slate-300">
                  {tab.count}
                </span>
              )}
              {Boolean(tab.badge) && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-red-500 text-white font-black animate-pulse">
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. MY SERVERS & ADVANCED CONTROL PANEL (SKILLORACLOUDS STYLE) */}
      {/* ========================================================================= */}
      {activeNav === 'servers' && (
        <div className="space-y-6">
          {servers.length === 0 ? (
            <div className="p-12 text-center bg-[#080B12] border border-dashed border-white/10 rounded-2xl max-w-xl mx-auto space-y-4">
              <Server className="w-12 h-12 text-gray-500 mx-auto" />
              <div>
                <h3 className="text-lg font-black text-white font-mono">No Active Servers Yet</h3>
                <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
                  Deploy your high-performance Minecraft server in minutes. Complete checkout to launch your world.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('home')}
                className="px-6 py-3 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-mono font-black tracking-wider rounded-xl transition-all shadow-lg cursor-pointer"
              >
                VIEW HOSTING PLANS <ArrowRight className="w-3.5 h-3.5 inline-block ml-1" />
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Server Selector Sidebar (When multiple servers exist) */}
              {servers.length > 1 && (
                <div className="lg:col-span-3 space-y-2">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-gray-400 font-bold block mb-2">
                    Select Server
                  </span>
                  {servers.map((srv) => (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() => setSelectedServerId(srv.id)}
                      className={`w-full p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        selectedServerId === srv.id
                          ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/10 text-white'
                          : 'border-white/5 bg-[#080B12] text-gray-400 hover:border-white/20'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-white font-mono truncate">{srv.name}</span>
                        <span className={`w-2 h-2 rounded-full ${srv.status === 'ONLINE' ? 'bg-emerald-400' : 'bg-red-400'}`} />
                      </div>
                      <span className="text-[10px] text-gray-500 font-mono block mt-1">{srv.ip}:{srv.port}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Main Advanced Server Control Panel */}
              <div className={`${servers.length > 1 ? 'lg:col-span-9' : 'lg:col-span-12'} bg-[#080B12] border border-white/5 rounded-2xl p-6 md:p-8 shadow-2xl space-y-6`}>
                
                {/* Server Quick Info Bar */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-6">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-black text-white font-mono">{activeServer.name}</h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black uppercase flex items-center gap-1 ${
                        activeServer.status === 'ONLINE'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : activeServer.status === 'RESTARTING'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse'
                          : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          activeServer.status === 'ONLINE' ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'
                        }`} />
                        {activeServer.status}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 mt-2 text-xs font-mono text-gray-400">
                      <span className="flex items-center gap-1">
                        IP: <b className="text-white select-all">{activeServer.ip}:{activeServer.port}</b>
                        <button
                          type="button"
                          onClick={() => handleCopyAddress(`${activeServer.ip}:${activeServer.port}`)}
                          className="ml-1 text-gray-400 hover:text-white cursor-pointer"
                          title="Copy Server Address"
                        >
                          {copiedIp ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </span>
                      <span>·</span>
                      <span>Plan: <b className="text-[var(--primary-color)]">{activeServer.planName}</b></span>
                      <span>·</span>
                      <span>Type: <b className="text-white">{activeServer.serverType} {activeServer.version}</b></span>
                    </div>
                  </div>

                  {/* Power Action Buttons */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handlePowerAction('START')}
                      disabled={activeServer.status === 'ONLINE'}
                      className="px-4 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all disabled:opacity-40 cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" /> START
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePowerAction('RESTART')}
                      className="px-4 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/30 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> RESTART
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePowerAction('STOP')}
                      disabled={activeServer.status === 'OFFLINE'}
                      className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all disabled:opacity-40 cursor-pointer"
                    >
                      <Square className="w-3.5 h-3.5 fill-current" /> STOP
                    </button>
                  </div>
                </div>

                {/* Advanced Control Panel Sub-Tabs Navigation */}
                <div className="flex flex-wrap gap-1.5 border-b border-white/5 pb-3">
                  {[
                    { id: 'overview', label: 'Overview' },
                    { id: 'console', label: 'Console' },
                    { id: 'files', label: 'Files' },
                    { id: 'players', label: 'Players' },
                    { id: 'backups', label: 'Backups' },
                    { id: 'schedules', label: 'Schedules' },
                    { id: 'plugins', label: 'Plugins' },
                    { id: 'startup', label: 'Startup & Version' },
                    { id: 'settings', label: 'Settings' }
                  ].map((sub) => (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => setServerSubTab(sub.id as any)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                        serverSubTab === sub.id
                          ? 'bg-[var(--primary-color)] text-white shadow-md'
                          : 'bg-[#101522] text-gray-400 hover:text-white'
                      }`}
                    >
                      {sub.label}
                    </button>
                  ))}
                </div>

                {/* SUBTAB 1: OVERVIEW & REAL-TIME RESOURCE MONITORING */}
                {serverSubTab === 'overview' && (
                  <div className="space-y-6 animate-fade-in">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      {/* CPU Card */}
                      <div className="p-4 bg-[#101522] border border-white/5 rounded-xl space-y-2">
                        <div className="flex justify-between items-center text-xs font-mono text-gray-400">
                          <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5 text-blue-400" /> CPU USAGE</span>
                          <span className="text-white font-bold">{activeServer.status === 'ONLINE' ? '12%' : '0%'}</span>
                        </div>
                        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500" style={{ width: activeServer.status === 'ONLINE' ? '12%' : '0%' }} />
                        </div>
                        <span className="text-[10px] text-gray-500 font-mono block">1 vCPU Dedicated</span>
                      </div>

                      {/* RAM Card */}
                      <div className="p-4 bg-[#101522] border border-white/5 rounded-xl space-y-2">
                        <div className="flex justify-between items-center text-xs font-mono text-gray-400">
                          <span className="flex items-center gap-1.5"><HardDrive className="w-3.5 h-3.5 text-purple-400" /> MEMORY</span>
                          <span className="text-white font-bold">{activeServer.status === 'ONLINE' ? '2.4 GB' : '0.0 GB'}</span>
                        </div>
                        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-purple-500" style={{ width: activeServer.status === 'ONLINE' ? '30%' : '0%' }} />
                        </div>
                        <span className="text-[10px] text-gray-500 font-mono block">Allocated: {activeServer.ram}</span>
                      </div>

                      {/* Storage Card */}
                      <div className="p-4 bg-[#101522] border border-white/5 rounded-xl space-y-2">
                        <div className="flex justify-between items-center text-xs font-mono text-gray-400">
                          <span className="flex items-center gap-1.5"><Layers className="w-3.5 h-3.5 text-emerald-400" /> DISK</span>
                          <span className="text-white font-bold">14.2 GB</span>
                        </div>
                        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500" style={{ width: '25%' }} />
                        </div>
                        <span className="text-[10px] text-gray-500 font-mono block">NVMe Gen4 SSD</span>
                      </div>

                      {/* Players Card */}
                      <div className="p-4 bg-[#101522] border border-white/5 rounded-xl space-y-2">
                        <div className="flex justify-between items-center text-xs font-mono text-gray-400">
                          <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5 text-amber-400" /> PLAYERS</span>
                          <span className="text-white font-bold">{activeServer.onlinePlayers} / {activeServer.maxPlayers}</span>
                        </div>
                        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-amber-500" style={{ width: `${(activeServer.onlinePlayers / activeServer.maxPlayers) * 100}%` }} />
                        </div>
                        <span className="text-[10px] text-gray-500 font-mono block">Java & Bedrock Crossplay</span>
                      </div>
                    </div>

                    {/* Server Quick Info Specifications */}
                    <div className="p-5 bg-[#101522] border border-white/5 rounded-xl space-y-3 font-mono text-xs">
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-2">Cluster Specifications</h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-gray-400">
                        <div>
                          <span className="text-[10px] text-gray-500 block uppercase">Edition</span>
                          <span className="text-white font-bold">{activeServer.edition}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-gray-500 block uppercase">Minecraft Version</span>
                          <span className="text-white font-bold">{activeServer.version}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-gray-500 block uppercase">Server Software</span>
                          <span className="text-white font-bold">{activeServer.serverType}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-gray-500 block uppercase">Datacenter</span>
                          <span className="text-white font-bold">{activeServer.location}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* SUBTAB 2: ADVANCED CONSOLE */}
                {serverSubTab === 'console' && (
                  <div className="space-y-4 animate-fade-in font-mono">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                      <span className="font-bold flex items-center gap-1.5">
                        <Terminal className="w-4 h-4 text-blue-400" /> Live Interactive Console
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setConsoleLogs([])}
                          className="px-2.5 py-1 bg-white/5 hover:bg-white/10 rounded text-[10px] text-gray-300 cursor-pointer"
                        >
                          Clear
                        </button>
                        <button
                          type="button"
                          onClick={() => navigator.clipboard.writeText(consoleLogs.join('\n'))}
                          className="px-2.5 py-1 bg-white/5 hover:bg-white/10 rounded text-[10px] text-gray-300 cursor-pointer"
                        >
                          Copy Output
                        </button>
                      </div>
                    </div>

                    {/* Console Screen */}
                    <div className="bg-[#05070A] border border-white/10 rounded-xl p-4 h-80 overflow-y-auto space-y-1 text-xs text-gray-300 select-text">
                      {consoleLogs.map((log, idx) => (
                        <div key={idx} className="leading-relaxed">
                          {log.includes('WARN') ? (
                            <span className="text-amber-400">{log}</span>
                          ) : log.includes('INFO') ? (
                            <span className="text-slate-300">{log}</span>
                          ) : log.startsWith('>') ? (
                            <span className="text-blue-400 font-bold">{log}</span>
                          ) : (
                            <span>{log}</span>
                          )}
                        </div>
                      ))}
                      <div ref={consoleBottomRef} />
                    </div>

                    {/* Command Input Bar */}
                    <form onSubmit={handleSendCommand} className="flex gap-2">
                      <input
                        type="text"
                        value={commandInput}
                        onChange={(e) => setCommandInput(e.target.value)}
                        placeholder="Type console command (e.g. /op Notch, /say Hello, /tps)..."
                        className="flex-1 bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[var(--primary-color)]"
                      />
                      <button
                        type="submit"
                        className="px-5 py-2.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" /> EXECUTE
                      </button>
                    </form>
                  </div>
                )}

                {/* SUBTAB 3: FILE MANAGER */}
                {serverSubTab === 'files' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white flex items-center gap-1.5">
                        <Folder className="w-4 h-4 text-amber-400" /> Root Directory (/home/container)
                      </span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setIsCreatingFile(!isCreatingFile)}
                          className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white rounded-lg text-xs cursor-pointer flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" /> New File
                        </button>
                      </div>
                    </div>

                    {isCreatingFile && (
                      <div className="p-3 bg-[#101522] border border-white/10 rounded-xl flex gap-2">
                        <input
                          type="text"
                          value={newFileName}
                          onChange={(e) => setNewFileName(e.target.value)}
                          placeholder="filename.txt"
                          className="flex-1 bg-black/40 border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (!newFileName.trim()) return;
                            setFileList([...fileList, { name: newFileName.trim(), isFolder: false, size: '0 B', modified: 'Just now', content: '' }]);
                            setNewFileName('');
                            setIsCreatingFile(false);
                          }}
                          className="px-4 py-1.5 bg-[var(--primary-color)] text-white text-xs font-bold rounded cursor-pointer"
                        >
                          Create
                        </button>
                      </div>
                    )}

                    {/* Inline Text File Editor Modal */}
                    {editingFile && (
                      <div className="p-4 bg-[#101522] border border-[var(--primary-color)]/40 rounded-xl space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-white">Editing: {editingFile.name}</span>
                          <button
                            type="button"
                            onClick={() => setEditingFile(null)}
                            className="text-gray-400 hover:text-white cursor-pointer"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <textarea
                          rows={12}
                          value={editingFile.content}
                          onChange={(e) => setEditingFile({ ...editingFile, content: e.target.value })}
                          className="w-full bg-[#05070A] border border-white/10 rounded-lg p-3 text-xs text-white font-mono focus:outline-none"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingFile(null)}
                            className="px-4 py-1.5 text-xs text-gray-400 hover:text-white cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const updated = fileList.map(f => f.name === editingFile.name ? { ...f, content: editingFile.content } : f);
                              setFileList(updated);
                              updateServerParametersInFirestore(activeServer.id, { files: updated });
                              setEditingFile(null);
                              alert('File saved successfully!');
                            }}
                            className="px-5 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-lg cursor-pointer"
                          >
                            Save File
                          </button>
                        </div>
                      </div>
                    )}

                    {/* File Table */}
                    <div className="bg-[#101522] border border-white/5 rounded-xl overflow-hidden">
                      <table className="w-full text-left">
                        <thead className="bg-black/30 border-b border-white/5 text-[10px] text-gray-500 uppercase">
                          <tr>
                            <th className="py-2.5 px-4">Name</th>
                            <th className="py-2.5 px-4">Size</th>
                            <th className="py-2.5 px-4">Modified</th>
                            <th className="py-2.5 px-4 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-gray-300">
                          {fileList.map((file, idx) => (
                            <tr key={idx} className="hover:bg-white/5 transition-colors">
                              <td className="py-2.5 px-4 flex items-center gap-2">
                                {file.isFolder ? <Folder className="w-4 h-4 text-amber-400" /> : <File className="w-4 h-4 text-blue-400" />}
                                <span className={file.isFolder ? 'text-amber-200 font-bold' : 'text-white'}>{file.name}</span>
                              </td>
                              <td className="py-2.5 px-4 text-gray-400">{file.size}</td>
                              <td className="py-2.5 px-4 text-gray-500">{file.modified}</td>
                              <td className="py-2.5 px-4 text-right space-x-2">
                                {!file.isFolder && (
                                  <button
                                    type="button"
                                    onClick={() => setEditingFile({ name: file.name, content: file.content || '' })}
                                    className="p-1 hover:text-[var(--primary-color)] cursor-pointer"
                                    title="Edit file"
                                  >
                                    <Edit3 className="w-3.5 h-3.5 inline" />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const filtered = fileList.filter(f => f.name !== file.name);
                                    setFileList(filtered);
                                    updateServerParametersInFirestore(activeServer.id, { files: filtered });
                                  }}
                                  className="p-1 hover:text-red-400 cursor-pointer"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5 inline" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* SUBTAB 4: PLAYERS */}
                {serverSubTab === 'players' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">Player Controls & Whitelist</span>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={newPlayerName}
                          onChange={(e) => setNewPlayerName(e.target.value)}
                          placeholder="Add player name..."
                          className="bg-[#101522] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (!newPlayerName.trim()) return;
                            setPlayersList([...playersList, { name: newPlayerName.trim(), uuid: 'custom', online: false, op: false, whitelisted: true, banned: false }]);
                            setNewPlayerName('');
                          }}
                          className="px-4 py-1.5 bg-[var(--primary-color)] text-white font-bold rounded-lg cursor-pointer"
                        >
                          Whitelist Player
                        </button>
                      </div>
                    </div>

                    <div className="bg-[#101522] border border-white/5 rounded-xl divide-y divide-white/5">
                      {playersList.map((p, idx) => (
                        <div key={idx} className="p-3.5 flex justify-between items-center">
                          <div>
                            <span className="font-bold text-white">{p.name}</span>
                            <div className="flex gap-2 text-[10px] text-gray-500 mt-0.5">
                              {p.op && <span className="text-amber-400 font-bold">[OP]</span>}
                              {p.whitelisted && <span className="text-emerald-400">[Whitelisted]</span>}
                              {p.banned && <span className="text-red-400">[Banned]</span>}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                const updated = playersList.map(pl => pl.name === p.name ? { ...pl, op: !pl.op } : pl);
                                setPlayersList(updated);
                              }}
                              className="px-2.5 py-1 bg-white/5 hover:bg-white/10 rounded text-[10px] cursor-pointer"
                            >
                              {p.op ? 'De-OP' : 'OP'}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const updated = playersList.map(pl => pl.name === p.name ? { ...pl, banned: !pl.banned } : pl);
                                setPlayersList(updated);
                              }}
                              className={`px-2.5 py-1 rounded text-[10px] cursor-pointer ${p.banned ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}
                            >
                              {p.banned ? 'Unban' : 'Ban'}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* SUBTAB 5: BACKUPS */}
                {serverSubTab === 'backups' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-bold text-white">Automated & Manual Snapshots</h4>
                        <p className="text-[10px] text-gray-500">Backups are stored off-site with zero server downtime.</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const newBkp = {
                            id: `bkp-${Date.now()}`,
                            name: `Manual-Backup-${new Date().toLocaleDateString().replace(/\//g, '-')}`,
                            size: '184.2 MB',
                            date: 'Just now'
                          };
                          setBackupsList([newBkp, ...backupsList]);
                          alert('New world snapshot created successfully!');
                        }}
                        className="px-4 py-2 bg-[var(--primary-color)] text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> CREATE BACKUP NOW
                      </button>
                    </div>

                    <div className="bg-[#101522] border border-white/5 rounded-xl divide-y divide-white/5">
                      {backupsList.length === 0 ? (
                        <div className="p-8 text-center text-gray-500 text-xs">
                          No manual backups generated yet. Automated daily snapshots run at 04:00 AM.
                        </div>
                      ) : (
                        backupsList.map((bkp) => (
                          <div key={bkp.id} className="p-3.5 flex justify-between items-center">
                            <div>
                              <span className="font-bold text-white">{bkp.name}</span>
                              <span className="text-[10px] text-gray-500 block">{bkp.size} · Created {bkp.date}</span>
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => alert(`World state restored from ${bkp.name}`)}
                                className="px-3 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded-lg text-xs cursor-pointer font-bold"
                              >
                                Restore
                              </button>
                              <button
                                type="button"
                                onClick={() => setBackupsList(backupsList.filter(b => b.id !== bkp.id))}
                                className="p-1 text-gray-500 hover:text-red-400 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {/* SUBTAB 6: SCHEDULES */}
                {serverSubTab === 'schedules' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-white">Scheduled Maintenance Tasks</h4>
                    </div>

                    <div className="p-4 bg-[#101522] border border-white/5 rounded-xl space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <input
                          type="text"
                          value={newScheduleName}
                          onChange={(e) => setNewScheduleName(e.target.value)}
                          placeholder="Task Name (e.g. Nightly Restart)"
                          className="bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
                        />
                        <select
                          value={newScheduleAction}
                          onChange={(e) => setNewScheduleAction(e.target.value)}
                          className="bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
                        >
                          <option value="Restart Server">Restart Server</option>
                          <option value="Create Backup">Create Backup</option>
                          <option value="Broadcast Message">Broadcast Message</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => {
                            if (!newScheduleName.trim()) return;
                            setSchedulesList([...schedulesList, { id: `sch-${Date.now()}`, name: newScheduleName.trim(), action: newScheduleAction, schedule: newScheduleTime, enabled: true }]);
                            setNewScheduleName('');
                          }}
                          className="px-4 py-2 bg-[var(--primary-color)] text-white font-bold rounded-lg cursor-pointer"
                        >
                          Add Scheduled Task
                        </button>
                      </div>
                    </div>

                    <div className="bg-[#101522] border border-white/5 rounded-xl divide-y divide-white/5">
                      {schedulesList.map((sch) => (
                        <div key={sch.id} className="p-3.5 flex justify-between items-center">
                          <div>
                            <span className="font-bold text-white">{sch.name}</span>
                            <span className="text-[10px] text-gray-400 block">{sch.action} · {sch.schedule}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setSchedulesList(schedulesList.map(s => s.id === sch.id ? { ...s, enabled: !s.enabled } : s));
                            }}
                            className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                              sch.enabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-gray-800 text-gray-500'
                            }`}
                          >
                            {sch.enabled ? 'Enabled' : 'Disabled'}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* SUBTAB 7: PLUGINS */}
                {serverSubTab === 'plugins' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white">Plugin Catalog & Installer</span>
                      <input
                        type="text"
                        value={pluginSearch}
                        onChange={(e) => setPluginSearch(e.target.value)}
                        placeholder="Search plugins..."
                        className="bg-[#101522] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {installedPlugins
                        .filter(p => !pluginSearch || p.name.toLowerCase().includes(pluginSearch.toLowerCase()))
                        .map((plug, idx) => (
                          <div key={idx} className="p-3.5 bg-[#101522] border border-white/5 rounded-xl flex justify-between items-center">
                            <div>
                              <span className="font-bold text-white block">{plug.name}</span>
                              <span className="text-[10px] text-gray-500">v{plug.version} · {plug.category}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                const updated = installedPlugins.map(p => p.name === plug.name ? { ...p, installed: !p.installed } : p);
                                setInstalledPlugins(updated);
                                updateServerParametersInFirestore(activeServer.id, { plugins: updated });
                              }}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                                plug.installed
                                  ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20'
                                  : 'bg-[var(--primary-color)] text-white'
                              }`}
                            >
                              {plug.installed ? 'Uninstall' : 'Install'}
                            </button>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {/* SUBTAB 8: STARTUP & VERSION CHANGER */}
                {serverSubTab === 'startup' && (
                  <div className="space-y-6 animate-fade-in font-mono text-xs">
                    <div className="p-5 bg-[#101522] border border-white/5 rounded-xl space-y-4">
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider">Minecraft Version Changer</h4>
                      <p className="text-[10px] text-gray-400">
                        Changing server versions preserves your worlds and player data. A server restart will be initiated automatically.
                      </p>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {['1.21.4', '1.21.1', '1.20.6', '1.20.4', '1.19.4', '1.18.2', '1.16.5', '1.8.9'].map((ver) => (
                          <button
                            key={ver}
                            type="button"
                            onClick={async () => {
                              await updateServerParametersInFirestore(activeServer.id, { version: ver });
                              alert(`Minecraft version switched to ${ver}. Restart server to apply.`);
                            }}
                            className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                              activeServer.version === ver
                                ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/20 text-white font-bold'
                                : 'border-white/5 bg-black/30 text-gray-400 hover:border-white/20'
                            }`}
                          >
                            <span>{ver}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-5 bg-[#101522] border border-white/5 rounded-xl space-y-3">
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider">Server Software</h4>
                      <div className="grid grid-cols-3 gap-2">
                        {['Paper', 'Purpur', 'Spigot', 'Fabric', 'Forge', 'Vanilla'].map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={async () => {
                              await updateServerParametersInFirestore(activeServer.id, { serverType: type });
                              alert(`Software set to ${type}`);
                            }}
                            className={`p-2.5 rounded-lg border text-center font-bold transition-all cursor-pointer ${
                              activeServer.serverType === type
                                ? 'border-[var(--primary-color)] bg-[var(--primary-color)]/20 text-white'
                                : 'border-white/5 bg-black/30 text-gray-400'
                            }`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* SUBTAB 9: SETTINGS */}
                {serverSubTab === 'settings' && (
                  <div className="space-y-4 animate-fade-in font-mono text-xs">
                    <div className="p-5 bg-[#101522] border border-white/5 rounded-xl space-y-4">
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider">Server Metadata Settings</h4>
                      <div className="space-y-2">
                        <label className="text-gray-400">Server Display Name</label>
                        <input
                          type="text"
                          defaultValue={activeServer.name}
                          onBlur={(e) => {
                            if (e.target.value.trim()) {
                              updateServerParametersInFirestore(activeServer.id, { name: e.target.value.trim() });
                            }
                          }}
                          className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-white"
                        />
                      </div>
                    </div>
                  </div>
                )}

              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BILLING & INVOICES (WITH PRINTABLE/DOWNLOADABLE PDF INVOICE) */}
      {/* ========================================================================= */}
      {activeNav === 'orders' && (
        <div className="space-y-6 animate-fade-in">
          <div>
            <h3 className="text-xl font-black text-white font-mono uppercase tracking-wide">Invoices & Billing History</h3>
            <p className="text-xs text-gray-400 font-mono mt-0.5">Official payment receipts and subscription records</p>
          </div>

          {orders.length === 0 ? (
            <div className="p-12 text-center bg-[#080B12] border border-dashed border-white/10 rounded-2xl text-gray-500 font-mono text-xs">
              No orders found for your account. Select a plan to get started.
            </div>
          ) : (
            <div className="bg-[#080B12] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
              <table className="w-full text-left font-mono text-xs">
                <thead className="bg-black/40 border-b border-white/5 text-[10px] text-gray-500 uppercase">
                  <tr>
                    <th className="py-3 px-4">Order ID</th>
                    <th className="py-3 px-4">Plan</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Payment</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4 text-right">Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-gray-300">
                  {orders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4 font-bold text-white">{ord.id}</td>
                      <td className="py-3 px-4 text-[var(--primary-color)] font-bold">{ord.planName}</td>
                      <td className="py-3 px-4 font-bold text-white">₹{ord.amount}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          ord.paymentStatus === 'Paid'
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-amber-500/10 text-amber-400'
                        }`}>
                          {ord.paymentStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 uppercase text-[10px]">{ord.orderStatus}</td>
                      <td className="py-3 px-4 text-gray-500 text-[10px]">{new Date(ord.date).toLocaleDateString()}</td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => setViewingInvoice(ord)}
                          className="px-3 py-1 bg-white/5 hover:bg-white/10 text-white rounded text-xs cursor-pointer inline-flex items-center gap-1 font-bold"
                        >
                          <FileText className="w-3.5 h-3.5" /> Invoice
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* INVOICE MODAL VIEW (PRINTABLE PDF) */}
          {viewingInvoice && (
            <div 
              className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in"
              onClick={() => setViewingInvoice(null)}
            >
              <div 
                className="bg-[#080B12] border border-white/10 rounded-2xl max-w-xl w-full p-8 shadow-2xl space-y-6 text-left"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-between items-start border-b border-white/10 pb-4">
                  <div>
                    <h4 className="text-2xl font-black text-white font-mono">FLARE<span className="text-[#1677FF]">CLOUD</span></h4>
                    <p className="text-[10px] text-gray-500 font-mono mt-0.5">OFFICIAL TAX INVOICE</p>
                  </div>
                  <div className="text-right font-mono text-xs">
                    <span className="text-gray-400 block">Invoice #{viewingInvoice.invoiceNumber || `INV-${viewingInvoice.id}`}</span>
                    <span className="text-gray-500 text-[10px]">{new Date(viewingInvoice.date).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs font-mono text-gray-300">
                  <div>
                    <span className="text-[10px] text-gray-500 block uppercase font-bold">Billed To</span>
                    <p className="text-white font-bold mt-0.5">{viewingInvoice.fullName || user?.fullName || 'Customer'}</p>
                    <p className="text-gray-400">{viewingInvoice.customerEmail}</p>
                    {viewingInvoice.phone && <p className="text-gray-500">{viewingInvoice.phone}</p>}
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-gray-500 block uppercase font-bold">Payment Details</span>
                    <p className="text-white font-bold mt-0.5">UPI Manual Transfer</p>
                    <p className="text-emerald-400 font-mono">UTR: {viewingInvoice.transactionId || 'Awaiting'}</p>
                    <p className="text-gray-500 text-[10px]">Status: {viewingInvoice.paymentStatus}</p>
                  </div>
                </div>

                <div className="border border-white/5 rounded-xl overflow-hidden font-mono text-xs">
                  <div className="bg-black/40 p-2.5 px-4 flex justify-between font-bold text-gray-400 text-[10px] uppercase">
                    <span>Description</span>
                    <span>Amount</span>
                  </div>
                  <div className="p-4 space-y-2">
                    <div className="flex justify-between text-white font-bold">
                      <span>{viewingInvoice.planName} Plan ({viewingInvoice.billingCycle || 'monthly'})</span>
                      <span>₹{viewingInvoice.amount}</span>
                    </div>
                    <div className="text-[10px] text-gray-500">
                      Server: {viewingInvoice.serverName} · Location: {viewingInvoice.location}
                    </div>
                  </div>
                  <div className="bg-black/40 p-3 px-4 flex justify-between font-bold text-sm text-white border-t border-white/5">
                    <span>Total Paid</span>
                    <span className="text-[var(--primary-color)]">₹{viewingInvoice.amount}</span>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2">
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-5 py-2.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-mono font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" /> Print / Save as PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewingInvoice(null)}
                    className="px-4 py-2.5 text-xs font-mono text-gray-400 hover:text-white cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. SUPPORT TICKETS */}
      {/* ========================================================================= */}
      {activeNav === 'support' && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-xl font-black text-white font-mono uppercase tracking-wide">Support Desk</h3>
              <p className="text-xs text-gray-400 font-mono mt-0.5">Real-time customer help desk</p>
            </div>
            <button
              type="button"
              onClick={() => setIsCreatingTicket(!isCreatingTicket)}
              className="px-4 py-2 bg-[var(--primary-color)] text-white text-xs font-mono font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" /> NEW TICKET
            </button>
          </div>

          {/* New Ticket Form */}
          {isCreatingTicket && (
            <form onSubmit={handleCreateTicket} className="p-6 bg-[#080B12] border border-white/10 rounded-2xl space-y-4 font-mono text-xs">
              <h4 className="text-sm font-bold text-white uppercase">Submit New Inquiry</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-gray-400">Subject</label>
                  <input
                    type="text"
                    required
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    placeholder="e.g. Help with GeyserMC port"
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-gray-400">Category</label>
                  <select
                    value={ticketCategory}
                    onChange={(e) => setTicketCategory(e.target.value as any)}
                    className="w-full bg-[#101522] border border-white/10 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Technical">Technical</option>
                    <option value="Billing">Billing</option>
                    <option value="Payment">Payment</option>
                    <option value="Server">Server</option>
                    <option value="Account">Account</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-gray-400">Message</label>
                <textarea
                  rows={4}
                  required
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  placeholder="Describe your issue in detail..."
                  className="w-full bg-[#101522] border border-white/10 rounded-xl p-3 text-white"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingTicket(false)}
                  className="px-4 py-2 text-gray-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[var(--primary-color)] text-white font-bold rounded-xl cursor-pointer"
                >
                  Submit Ticket
                </button>
              </div>
            </form>
          )}

          {/* Active Ticket Thread View */}
          {selectedTicketId && currentTicket ? (
            <div className="bg-[#080B12] border border-white/5 rounded-2xl p-6 space-y-4 font-mono text-xs">
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div>
                  <span className="text-[10px] text-gray-500">{currentTicket.id} · {currentTicket.category}</span>
                  <h4 className="text-base font-bold text-white mt-0.5">{currentTicket.subject}</h4>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedTicketId(null)}
                  className="text-xs text-gray-400 hover:text-white cursor-pointer"
                >
                  ← BACK TO TICKETS
                </button>
              </div>

              {/* Chat Thread */}
              <div className="space-y-3 max-h-96 overflow-y-auto p-2">
                {currentTicket.messages.map((m, idx) => {
                  const isStaff = m.sender.endsWith('@flarecloud.fun') || m.sender === 'admin';
                  return (
                    <div key={idx} className={`flex flex-col ${isStaff ? 'items-start' : 'items-end'}`}>
                      <span className="text-[9px] text-gray-500 mb-1">{isStaff ? 'Support Staff' : 'You'}</span>
                      <div className={`p-3 rounded-xl max-w-md ${
                        isStaff ? 'bg-[#101522] text-white border border-white/5' : 'bg-[var(--primary-color)] text-white'
                      }`}>
                        {m.text}
                      </div>
                      <span className="text-[8px] text-gray-500 mt-1">{new Date(m.timestamp).toLocaleTimeString()}</span>
                    </div>
                  );
                })}
              </div>

              {/* Reply Form */}
              <form onSubmit={handleReplyTicket} className="flex gap-2 border-t border-white/5 pt-4">
                <input
                  type="text"
                  required
                  value={ticketReplyText}
                  onChange={(e) => setTicketReplyText(e.target.value)}
                  placeholder="Type your message reply..."
                  className="flex-1 bg-[#101522] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[var(--primary-color)] text-white font-bold rounded-xl cursor-pointer"
                >
                  Send
                </button>
              </form>
            </div>
          ) : (
            <div className="bg-[#080B12] border border-white/5 rounded-2xl divide-y divide-white/5 font-mono text-xs">
              {tickets.length === 0 ? (
                <div className="p-8 text-center text-gray-500">No support tickets found.</div>
              ) : (
                tickets.map((tck) => (
                  <div 
                    key={tck.id}
                    onClick={() => setSelectedTicketId(tck.id)}
                    className="p-4 flex justify-between items-center hover:bg-white/5 cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{tck.subject}</span>
                        <span className={`px-2 py-0.2 rounded text-[9px] ${
                          tck.status === 'Open' ? 'bg-blue-500/10 text-blue-400' : 'bg-emerald-500/10 text-emerald-400'
                        }`}>
                          {tck.status}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-500 block mt-1">
                        {tck.id} · {tck.category} · {tck.messages.length} messages
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-500" />
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. REALTIME NOTIFICATIONS */}
      {/* ========================================================================= */}
      {activeNav === 'notifications' && (
        <div className="space-y-4 animate-fade-in font-mono text-xs">
          <div>
            <h3 className="text-xl font-black text-white uppercase tracking-wide">Notifications & Alerts</h3>
            <p className="text-xs text-gray-400 mt-0.5">Real-time updates regarding your servers and payments</p>
          </div>

          <div className="bg-[#080B12] border border-white/5 rounded-2xl divide-y divide-white/5">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-gray-500">No notifications yet.</div>
            ) : (
              notifications.map((ntf) => (
                <div key={ntf.id} className="p-4 flex justify-between items-start gap-4">
                  <div className="flex items-start gap-3">
                    <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${ntf.read ? 'bg-gray-600' : 'bg-[var(--primary-color)] animate-pulse'}`} />
                    <div>
                      <p className="text-white leading-relaxed">{ntf.text}</p>
                      <span className="text-[10px] text-gray-500 block mt-1">{new Date(ntf.date).toLocaleString()}</span>
                    </div>
                  </div>
                  {!ntf.read && (
                    <button
                      type="button"
                      onClick={() => markNotificationAsRead(ntf.id)}
                      className="px-2.5 py-1 text-[10px] bg-white/5 hover:bg-white/10 text-gray-300 rounded cursor-pointer"
                    >
                      Mark read
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. PROFILE */}
      {/* ========================================================================= */}
      {activeNav === 'profile' && (
        <div className="max-w-xl mx-auto bg-[#080B12] border border-white/5 rounded-2xl p-6 md:p-8 space-y-6 font-mono text-xs animate-fade-in">
          <h3 className="text-xl font-black text-white uppercase tracking-wide">Customer Account</h3>
          
          <div className="space-y-4 text-gray-300">
            <div>
              <span className="text-[10px] text-gray-500 uppercase block font-bold">Email Address</span>
              <p className="text-white font-bold text-sm mt-0.5">{user?.email}</p>
            </div>
            <div>
              <span className="text-[10px] text-gray-500 uppercase block font-bold">Full Name</span>
              <p className="text-white mt-0.5">{user?.fullName}</p>
            </div>
            <div>
              <span className="text-[10px] text-gray-500 uppercase block font-bold">Minecraft Gamertag</span>
              <p className="text-white mt-0.5">{user?.minecraftUsername || 'Not linked'}</p>
            </div>
            <div>
              <span className="text-[10px] text-gray-500 uppercase block font-bold">Discord</span>
              <p className="text-white mt-0.5">{user?.discordUsername || 'Not linked'}</p>
            </div>
            <div>
              <span className="text-[10px] text-gray-500 uppercase block font-bold">Official Discord Support Community</span>
              <a
                href="https://discord.gg/fwPQPcFST"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#5865F2] hover:underline flex items-center gap-1.5 mt-1 font-bold"
              >
                Join FlareCloud Discord ↗
              </a>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
