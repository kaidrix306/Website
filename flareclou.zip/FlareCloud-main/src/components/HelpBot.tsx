import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send, Sparkles, AlertCircle, PlusCircle, LifeBuoy } from 'lucide-react';

interface HelpBotProps {
  user: any;
  customizer: any;
  onNavigate: (view: string) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  time: string;
}

export default function HelpBot({ user, customizer, onNavigate }: HelpBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'bot',
      text: "Welcome to FlareCloud Support! I am your interactive hosting bot. Ask me about plans, setup, Java/Bedrock crossplay, UPI payments, or open a technical ticket directly!",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showTicketForm, setShowTicketForm] = useState(false);
  const [hasNewMessage, setHasNewMessage] = useState(false);

  // Ticket Form States
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState('Technical');
  const [ticketPriority, setTicketPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [ticketMsg, setTicketMsg] = useState('');
  const [ticketSuccess, setTicketSuccess] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, showTicketForm]);

  const triggerSuggestedPrompt = (prompt: string) => {
    handleSendMessage(prompt);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    if (!textToSend) setInputText('');

    // Append user message
    const userMsg: Message = {
      id: Math.random().toString(),
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          email: user?.email || null,
          context: `Current page view context is: ${window.location.pathname}`
        }),
      });

      const data = await response.json();
      if (data.success) {
        setMessages((prev) => [
          ...prev,
          {
            id: Math.random().toString(),
            sender: 'bot',
            text: data.reply,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        if (!isOpen) setHasNewMessage(true);
      } else {
        throw new Error();
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: 'bot',
          text: "My apologies! I am having trouble reaching our AI service. Please try again or create a Support Ticket in our portal.",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const submitSupportTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: 'bot',
          text: "You must be signed in to open a support ticket. Please click 'Login' on the top bar!",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setShowTicketForm(false);
      return;
    }

    if (!ticketSubject || !ticketMsg) return;

    setIsLoading(true);
    try {
      const res = await fetch('/api/tickets/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerEmail: user.email,
          subject: ticketSubject,
          category: ticketCategory,
          priority: ticketPriority,
          message: ticketMsg
        }),
      });

      const data = await res.json();
      if (data.success) {
        setTicketSuccess(true);
        setTicketSubject('');
        setTicketMsg('');
        setTimeout(() => {
          setTicketSuccess(false);
          setShowTicketForm(false);
          setMessages((prev) => [
            ...prev,
            {
              id: Math.random().toString(),
              sender: 'bot',
              text: `Excellent! I have created Support Ticket **${data.ticket.id}** [${ticketCategory}] under your account. Our staff has been notified and will reply in under 15 minutes!`,
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ]);
        }, 1500);
      }
    } catch (err) {
      alert("Error submitting ticket.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating Toggle Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          setHasNewMessage(false);
        }}
        className="w-14 h-14 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white rounded-full flex items-center justify-center shadow-[0_4px_25px_rgba(22,119,255,0.4)] cursor-pointer hover:scale-105 transition-all relative group"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
        {hasNewMessage && !isOpen && (
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-[9px] text-white font-bold items-center justify-center">1</span>
          </span>
        )}
        <span className="absolute right-16 scale-0 bg-gray-900 border border-white/5 text-xs text-gray-300 py-1.5 px-3 rounded-md group-hover:scale-100 transition-all shadow-lg whitespace-nowrap">
          FlareCloud Assistant
        </span>
      </button>

      {/* Interactive Chat Window */}
      {isOpen && (
        <div
          className="absolute bottom-18 right-0 w-[360px] md:w-[400px] h-[550px] bg-[#080B12] border border-white/10 flex flex-col shadow-2xl transition-all duration-300"
          style={{ borderRadius: customizer.borderRadius }}
        >
          {/* Header */}
          <div className="p-4 border-b border-white/10 bg-[#0D111A] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <div>
                <h4 className="text-sm font-bold text-white tracking-wide flex items-center gap-1">
                  FLARECLOUD ASSISTANT <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                </h4>
                <p className="text-[10px] text-gray-400 uppercase tracking-wider font-mono">Real-time Hosting Assistant</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 font-sans text-sm">
            {!showTicketForm ? (
              <>
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[85%] px-3.5 py-2.5 rounded-xl ${
                        msg.sender === 'user'
                          ? 'bg-[var(--primary-color)] text-white rounded-tr-none'
                          : 'bg-[#161B26] text-gray-100 rounded-tl-none border border-white/5'
                      }`}
                    >
                      <p className="leading-relaxed whitespace-pre-line text-xs">{msg.text}</p>
                    </div>
                    <span className="text-[9px] text-gray-500 mt-1 uppercase font-mono tracking-wider">{msg.time}</span>
                  </div>
                ))}

                {isLoading && (
                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    <span className="animate-spin border-2 border-[var(--primary-color)] border-t-transparent w-3 h-3 rounded-full" />
                    <span>Checking hosting status...</span>
                  </div>
                )}
                <div ref={chatEndRef} />
              </>
            ) : (
              /* Support Ticket Fast Form */
              <form onSubmit={submitSupportTicket} className="space-y-4 animate-fade-in p-1">
                <div className="flex items-center gap-2 text-[var(--primary-color)] pb-2 border-b border-white/5">
                  <PlusCircle className="w-4 h-4" />
                  <span className="text-xs font-extrabold uppercase tracking-widest font-mono">Create Support Ticket</span>
                </div>

                {ticketSuccess ? (
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-center text-emerald-400 text-xs">
                    Ticket created successfully! Syncing...
                  </div>
                ) : (
                  <>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400 font-mono font-bold">Subject</label>
                      <input
                        type="text"
                        required
                        value={ticketSubject}
                        onChange={(e) => setTicketSubject(e.target.value)}
                        placeholder="e.g. Server lagging or backup help"
                        className="w-full bg-[#161B26] border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[var(--primary-color)]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] uppercase text-gray-400 font-mono font-bold">Category</label>
                        <select
                          value={ticketCategory}
                          onChange={(e) => setTicketCategory(e.target.value)}
                          className="w-full bg-[#161B26] border border-white/10 rounded px-2.5 py-2 text-xs text-white focus:outline-none"
                        >
                          <option value="Technical">Technical</option>
                          <option value="Billing">Billing</option>
                          <option value="Plugin Setup">Plugin Setup</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] uppercase text-gray-400 font-mono font-bold">Priority</label>
                        <select
                          value={ticketPriority}
                          onChange={(e) => setTicketPriority(e.target.value as any)}
                          className="w-full bg-[#161B26] border border-white/10 rounded px-2.5 py-2 text-xs text-white focus:outline-none"
                        >
                          <option value="Low">Low</option>
                          <option value="Medium">Medium</option>
                          <option value="High">High</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400 font-mono font-bold">Describe Issue</label>
                      <textarea
                        required
                        rows={4}
                        value={ticketMsg}
                        onChange={(e) => setTicketMsg(e.target.value)}
                        placeholder="Please provide details about your server or issue..."
                        className="w-full bg-[#161B26] border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] resize-none"
                      />
                    </div>

                    <div className="pt-2 flex gap-2">
                      <button
                        type="button"
                        onClick={() => setShowTicketForm(false)}
                        className="flex-1 py-2 text-xs font-bold text-gray-400 bg-white/5 border border-white/5 rounded hover:text-white transition-all cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 text-xs font-bold bg-[var(--primary-color)] text-white rounded hover:bg-[var(--accent-color)] transition-all cursor-pointer"
                      >
                        Submit Case
                      </button>
                    </div>
                  </>
                )}
              </form>
            )}
          </div>

          {/* Quick suggestions & Action bar */}
          {!showTicketForm && (
            <div className="px-4 pb-2 pt-1 flex flex-wrap gap-1.5 border-t border-white/5 bg-[#080B12]">
              <button
                onClick={() => triggerSuggestedPrompt("What plans do you have and prices?")}
                className="text-[10px] bg-[#161B26] border border-white/5 hover:border-[var(--primary-color)] text-gray-300 py-1 px-2 rounded transition-all cursor-pointer"
              >
                Plans & Pricing
              </button>
              <button
                onClick={() => triggerSuggestedPrompt("How does UPI payment QR verification work?")}
                className="text-[10px] bg-[#161B26] border border-white/5 hover:border-[var(--primary-color)] text-gray-300 py-1 px-2 rounded transition-all cursor-pointer"
              >
                UPI QR Pay
              </button>
              <button
                onClick={() => triggerSuggestedPrompt("Do you support Java & Bedrock crossplay?")}
                className="text-[10px] bg-[#161B26] border border-white/5 hover:border-[var(--primary-color)] text-gray-300 py-1 px-2 rounded transition-all cursor-pointer"
              >
                Java + Bedrock
              </button>
              <a
                href="https://discord.gg/fwPQPcFST"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] bg-[#5865F2]/20 border border-[#5865F2]/40 text-[#5865F2] hover:text-white py-1 px-2 rounded hover:bg-[#5865F2] transition-all flex items-center gap-1 cursor-pointer"
              >
                Join Discord ↗
              </a>
              <button
                onClick={() => {
                  if (!user) {
                    alert("Please login first to create a ticket.");
                  } else {
                    setShowTicketForm(true);
                  }
                }}
                className="text-[10px] bg-blue-500/10 border border-blue-500/30 text-blue-400 py-1 px-2 rounded hover:bg-blue-500/20 transition-all flex items-center gap-1 cursor-pointer"
              >
                <LifeBuoy className="w-3 h-3" /> Create Ticket
              </button>
            </div>
          )}

          {/* Footer Input Bar */}
          {!showTicketForm && (
            <div className="p-3 border-t border-white/10 bg-[#0D111A] flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask FlareCloud bot..."
                className="flex-1 bg-[#161B26] border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[var(--primary-color)]"
                style={{ borderRadius: customizer.borderRadius }}
              />
              <button
                onClick={() => handleSendMessage()}
                className="p-2 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white rounded-lg transition-colors cursor-pointer"
                style={{ borderRadius: customizer.borderRadius }}
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
