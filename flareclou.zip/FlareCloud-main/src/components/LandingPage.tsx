import React, { useState, useEffect } from 'react';
import { 
  Shield, Clock, Cpu, HardDrive, RefreshCw, Terminal, Check, Globe, HelpCircle, 
  ChevronDown, Award, Zap, Users, Sliders, Play, Square, AlertCircle, Search, 
  ArrowRight, Sparkles, Activity, Layers, Download, ExternalLink, Headphones
} from 'lucide-react';
import { measureRealPing } from '../services/firebaseService';

interface LandingPageProps {
  customizer: any;
  onNavigate: (view: string) => void;
  onSelectPlan: (plan: any) => void;
}

const PLANS = [
  { name: 'DIRT', price: 99, ram: '2GB RAM', cpu: '1 vCPU', ssd: '20GB NVMe SSD' },
  { name: 'STONE', price: 199, ram: '4GB RAM', cpu: '2 vCPU', ssd: '40GB NVMe SSD' },
  { name: 'IRON', price: 399, ram: '8GB RAM', cpu: '4 vCPU', ssd: '80GB NVMe SSD', popular: true },
  { name: 'REDSTONE', price: 799, ram: '16GB RAM', cpu: '6 vCPU', ssd: '160GB NVMe SSD' },
  { name: 'GOLD', price: 1499, ram: '32GB RAM', cpu: '8 vCPU', ssd: '320GB NVMe SSD' },
  { name: 'INFINITY', price: 2999, ram: 'Unlimited RAM', cpu: 'Ryzen 9 Dedicated', ssd: '1TB NVMe SSD' }
];

export default function LandingPage({ customizer, onNavigate, onSelectPlan }: LandingPageProps) {
  // Real Latency Ping States (No Fake Values)
  const [latencies, setLatencies] = useState<Record<string, { ms: number; status: string }>>({});
  const [testingLoc, setTestingLoc] = useState<string | null>(null);

  // FAQ Search & Category State
  const [faqSearch, setFaqSearch] = useState('');
  const [selectedFaqCategory, setSelectedFaqCategory] = useState('All');
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);

  // Control panel mockup console state
  const [panelStatus, setPanelStatus] = useState<'ONLINE' | 'OFFLINE'>('ONLINE');
  const [playersCount, setPlayersCount] = useState(24);

  // Real Network Ping Measurement
  const handleTestPing = async (locName: string) => {
    setTestingLoc(locName);
    try {
      const res = await measureRealPing(locName);
      setLatencies(prev => ({
        ...prev,
        [locName]: { ms: res.latencyMs, status: res.status }
      }));
    } catch {
      setLatencies(prev => ({
        ...prev,
        [locName]: { ms: 0, status: 'DEGRADED' }
      }));
    } finally {
      setTestingLoc(null);
    }
  };

  const allFaqs = [
    {
      category: 'Hosting',
      q: "What is Minecraft hosting?",
      a: "Minecraft hosting provides dedicated cloud-based server resources specifically tuned to execute Minecraft server software with high TPS, ultra-low ping, and 24/7 continuous uptime."
    },
    {
      category: 'Minecraft',
      q: "Which Minecraft versions are supported?",
      a: "We support every official version of Minecraft! From early classic releases to the latest release candidates, including full one-click support for Paper, Purpur, Spigot, Forge, Fabric, and NeoForge."
    },
    {
      category: 'Minecraft',
      q: "Do you support Java and Bedrock crossplay?",
      a: "Yes! All FlareCloud deployments come pre-configured with GeyserMC and Floodgate, allowing PC Java players and mobile/console Bedrock players to play together on the exact same server IP and port."
    },
    {
      category: 'Payments',
      q: "What payment methods are supported?",
      a: "We support instant manual UPI payments (Google Pay, PhonePe, Paytm, BHIM, Navi, etc.) via our payment QR code during checkout. Our staff verifies transactions rapidly."
    },
    {
      category: 'Orders',
      q: "How fast is server activation after payment?",
      a: "Once your UPI UTR number and payment screenshot are verified by our team, your Minecraft server container deploys immediately. You can track real-time provisioning status directly from the order confirmation screen."
    },
    {
      category: 'Backups',
      q: "Are automatic backups included?",
      a: "Yes! Automatic off-site backups are included. You can also generate manual world snapshots and restore anytime with a single click from the Backups panel."
    },
    {
      category: 'Plugins',
      q: "Can I install custom plugins and mods?",
      a: "Yes! Our control panel features an integrated Plugin & Mod Installer with one-click installs, plus a full browser File Manager and SFTP access to upload custom .jar and mod files."
    },
    {
      category: 'Support',
      q: "How can I contact technical support?",
      a: "You can submit an interactive support ticket in your portal, chat with our automated Assistant, or join our community Discord server at https://discord.gg/fwPQPcFST for instant staff help."
    }
  ];

  const faqCategories = ['All', 'Hosting', 'Minecraft', 'Payments', 'Orders', 'Backups', 'Plugins', 'Support'];

  const filteredFaqs = allFaqs.filter(faq => {
    const matchesCat = selectedFaqCategory === 'All' || faq.category === selectedFaqCategory;
    const matchesSearch = !faqSearch.trim() || 
      faq.q.toLowerCase().includes(faqSearch.toLowerCase()) || 
      faq.a.toLowerCase().includes(faqSearch.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="text-white space-y-24 pb-12 font-sans overflow-hidden">
      
      {/* 1. HERO SECTION */}
      <section className="relative pt-36 md:pt-44 pb-20 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Glow backdrop */}
        <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-500/10 rounded-full blur-[140px] pointer-events-none" />

        {/* Hero Left Content */}
        <div className="lg:col-span-7 space-y-6 text-left relative z-10 animate-fade-in">
          {/* Status micro label */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>HOSTING INFRASTRUCTURE OPERATIONAL</span>
          </div>

          <h1 
            className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight"
            style={{ fontWeight: customizer.headingWeight }}
          >
            POWER YOUR <br />
            <span className="text-[var(--primary-color)] drop-shadow-[0_0_35px_rgba(22,119,255,0.4)]">
              MINECRAFT SERVER
            </span>.
          </h1>

          <p className="text-sm md:text-base text-gray-400 max-w-xl leading-relaxed">
            High-performance Minecraft hosting built for smooth gameplay, powerful control, and effortless management. Instant deployment, enterprise NVMe speed, and 24/7 protection.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap gap-4 pt-2">
            <button
              onClick={() => {
                const el = document.getElementById('pricing-plans');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-7 py-4 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-black font-mono tracking-wider rounded-xl transition-all cursor-pointer hover:scale-105 shadow-[0_0_30px_rgba(22,119,255,0.4)] whitespace-nowrap"
            >
              DEPLOY SERVER <ArrowRight className="w-4 h-4 inline-block ml-1" />
            </button>
            <button
              onClick={() => {
                const el = document.getElementById('hosting-features');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-7 py-4 bg-white/5 border border-white/10 hover:border-white/30 text-white text-xs font-bold font-mono tracking-wider rounded-xl transition-all cursor-pointer whitespace-nowrap hover:bg-white/10"
            >
              EXPLORE FEATURES
            </button>
          </div>

          {/* Value Badges */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-gray-400 pt-4 border-t border-white/5 font-mono">
            <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> Enterprise NVMe</span>
            <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> DDoS Protected</span>
            <span className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-emerald-400" /> Java + Bedrock</span>
          </div>
        </div>

        {/* Hero Right: Live Server Control Dashboard Mockup */}
        <div className="lg:col-span-5 relative z-10 animate-fade-in">
          <div className="bg-[#080B12] border border-white/10 p-5 rounded-2xl shadow-2xl relative transition-transform hover:scale-[1.01]">
            {/* Window Top Bar */}
            <div className="flex items-center justify-between border-b border-white/5 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              </div>
              <span className="text-[10px] text-gray-400 font-mono font-bold">in.flarecloud.fun:25565</span>
            </div>

            <div className="space-y-4">
              {/* Server Name Banner */}
              <div className="p-3.5 bg-[#101522] border border-white/5 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-gray-400 font-mono block">Community SMP Realm</span>
                  <p className="text-xs font-bold text-white mt-0.5 font-mono">FLARECLOUD SURVIVAL</p>
                </div>
                <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-mono px-2.5 py-1 rounded-full font-bold uppercase flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> ONLINE
                </span>
              </div>

              {/* Resource Visualizers */}
              <div className="space-y-3">
                <div className="space-y-1">
                  <div className="flex justify-between font-mono text-[10px] text-gray-400">
                    <span>CPU Core Allocation</span>
                    <span className="text-white font-bold">14.2%</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-[var(--primary-color)] shadow-[0_0_10px_var(--primary-color)]" style={{ width: '14.2%' }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between font-mono text-[10px] text-gray-400">
                    <span>RAM Utilization</span>
                    <span className="text-white font-bold">3.8 GB / 8.0 GB</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 shadow-[0_0_10px_#a855f7]" style={{ width: '47.5%' }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between font-mono text-[10px] text-gray-400">
                    <span>NVMe Storage</span>
                    <span className="text-white font-bold">18.4 GB / 80.0 GB</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 shadow-[0_0_10px_#10b981]" style={{ width: '23%' }} />
                  </div>
                </div>
              </div>

              {/* Terminal Logs Preview */}
              <div className="bg-[#05070A] p-3 rounded-xl font-mono text-[10px] text-gray-400 space-y-1 border border-white/5">
                <div className="text-blue-400">[14:02:25 INFO]: Paper 1.21.4 server listening on port 25565.</div>
                <div className="text-emerald-400">[14:05:32 INFO]: SteveTheBuilder joined the game.</div>
                <div className="text-gray-500">[14:05:40 INFO]: &lt;Steve&gt; Ping is only 14ms! Flawless TPS.</div>
                <div className="text-purple-400">[14:12:45 INFO]: Automated backup completed successfully.</div>
              </div>
            </div>

            {/* Floating badges */}
            <div className="absolute -bottom-3 -left-3 bg-[#101522] border border-white/10 px-3 py-1.5 rounded-lg shadow-xl flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[10px] font-mono text-gray-200 font-bold uppercase">20 TPS STABLE</span>
            </div>
            <div className="absolute -top-3 -right-3 bg-[#101522] border border-white/10 px-3 py-1.5 rounded-lg shadow-xl flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[10px] font-mono text-gray-200 font-bold uppercase">12 Tbps SHIELD</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. TRUST STRIP */}
      <section className="bg-[#080B12]/80 border-y border-white/5 py-8 max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <span className="text-2xl md:text-3xl font-black text-white font-mono tracking-tight">&lt; 15 ms</span>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono mt-1">Average India Latency</p>
          </div>
          <div>
            <span className="text-2xl md:text-3xl font-black text-white font-mono tracking-tight">Instant</span>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono mt-1">Automated Setup</p>
          </div>
          <div>
            <span className="text-2xl md:text-3xl font-black text-white font-mono tracking-tight">12 Tbps</span>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono mt-1">DDoS Mitigation</p>
          </div>
          <div>
            <span className="text-2xl md:text-3xl font-black text-white font-mono tracking-tight">Automated</span>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono mt-1">Daily Off-Site Backups</p>
          </div>
        </div>
      </section>

      {/* 3. HOSTING FEATURES */}
      <section id="hosting-features" className="max-w-7xl mx-auto px-6 relative z-10 space-y-12 scroll-mt-24">
        <div className="text-center space-y-2">
          <span className="text-[10px] text-[var(--primary-color)] font-mono font-extrabold tracking-widest uppercase">ENGINEERED FOR MINECRAFT</span>
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-wide">EVERYTHING YOUR SERVER NEEDS</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: <HardDrive className="text-blue-400" />, title: 'NVMe Gen4 Storage', text: 'Ultra-fast NVMe storage provides flawless chunk loading and prevents block lag.' },
            { icon: <Shield className="text-emerald-400" />, title: 'DDoS Guard', text: 'Enterprise mitigation shields your server from L4/L7 volumetric floods.' },
            { icon: <Clock className="text-purple-400" />, title: 'Instant Provisioning', text: 'Servers activate rapidly after payment verification without complex configurations.' },
            { icon: <RefreshCw className="text-amber-400" />, title: 'Automated Backups', text: 'Daily snapshots protect your builds with single-click restore capabilities.' },
            { icon: <Globe className="text-blue-400" />, title: 'Java & Bedrock Crossplay', text: 'GeyserMC and Floodgate bridge PC and mobile players on the exact same port.' },
            { icon: <Terminal className="text-gray-300" />, title: 'Browser File Explorer', text: 'Edit configuration files, manage folders, and upload modpacks directly in your browser.' },
            { icon: <Cpu className="text-rose-400" />, title: 'Live Server Console', text: 'Interactive command prompt with real-time server output, auto-scroll, and search.' },
            { icon: <Users className="text-indigo-400" />, title: 'Player Management', text: 'Whitelist, OP, kick, and ban players with quick visual controls.' },
            { icon: <Clock className="text-yellow-400" />, title: 'Scheduled Tasks', text: 'Configure automated restarts, backup schedules, and broadcast commands.' },
            { icon: <Award className="text-amber-400" />, title: 'Plugin Installer', text: 'One-click installation for EssentialsX, CoreProtect, LuckPerms, and hundreds more.' },
            { icon: <Sliders className="text-sky-400" />, title: 'Modpack Support', text: 'Deploy extensive Forge, Fabric, and NeoForge modpacks seamlessly.' },
            { icon: <Globe className="text-teal-400" />, title: 'Global Deployment', text: 'Choose deployment datacenters in India, Singapore, Germany, or the USA.' }
          ].map((feat, index) => (
            <div 
              key={index} 
              className="p-5 bg-[#080B12] border border-white/5 rounded-2xl hover:border-[var(--primary-color)]/60 hover:-translate-y-1 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                {feat.icon}
              </div>
              <h4 className="text-sm font-bold text-white tracking-wide">{feat.title}</h4>
              <p className="text-xs text-gray-400 mt-2 leading-relaxed">{feat.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. PRICING PLANS */}
      <section id="pricing-plans" className="max-w-7xl mx-auto px-6 relative z-10 space-y-12 scroll-mt-24">
        <div className="text-center space-y-2">
          <span className="text-[10px] text-[var(--primary-color)] font-mono font-extrabold tracking-widest uppercase">TRANSPARENT PRICING</span>
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-wide">CHOOSE YOUR MINECRAFT TIER</h2>
          <p className="text-xs text-gray-400 max-w-sm mx-auto font-mono">Simple pricing. High-performance enterprise hardware. Upgrade or cancel anytime.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`p-6 bg-[#080B12] rounded-2xl flex flex-col justify-between relative transition-all ${
                plan.popular
                  ? 'border-2 border-[var(--primary-color)] ring-4 ring-blue-500/10 shadow-[0_0_35px_rgba(22,119,255,0.25)] hover:-translate-y-1'
                  : 'border border-white/5 hover:border-[var(--primary-color)] hover:-translate-y-1'
              }`}
            >
              {plan.popular && (
                <span className="absolute -top-3 right-6 bg-[var(--primary-color)] text-white text-[9px] font-black uppercase font-mono px-3 py-1 rounded-full tracking-widest shadow-lg">
                  MOST POPULAR
                </span>
              )}

              <div className="space-y-5">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-base font-black text-white uppercase tracking-wider font-mono">{plan.name} PLAN</h4>
                    <span className="text-[10px] text-gray-400 font-mono mt-0.5 block">Dedicated RAM allocation</span>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-black text-white font-mono">₹{plan.price}</span>
                    <span className="text-[10px] text-gray-500 block font-mono">/ month</span>
                  </div>
                </div>

                <div className="h-px bg-white/5" />

                <div className="space-y-2.5 text-xs text-slate-300 font-mono">
                  <div className="flex justify-between">
                    <span className="text-gray-400">RAM Memory</span>
                    <span className="text-white font-bold">{plan.ram}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Processor Thread</span>
                    <span className="text-white font-bold">{plan.cpu}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">NVMe Storage</span>
                    <span className="text-white font-bold">{plan.ssd}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DDoS Protection</span>
                    <span className="text-emerald-400 font-bold">12 Tbps Shield</span>
                  </div>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-white/5">
                <button
                  onClick={() => onSelectPlan(plan)}
                  className={`w-full py-3.5 text-xs font-black font-mono tracking-wider rounded-xl transition-all cursor-pointer ${
                    plan.popular
                      ? 'bg-[var(--primary-color)] text-white hover:bg-[var(--accent-color)] shadow-[0_0_20px_rgba(22,119,255,0.4)] hover:scale-105'
                      : 'bg-white/5 border border-white/10 text-white hover:bg-[var(--primary-color)] hover:border-[var(--primary-color)]'
                  }`}
                >
                  DEPLOY NOW
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. LOCATION EXPERIENCE & REAL NETWORK PING TEST */}
      <section id="server-locations" className="max-w-7xl mx-auto px-6 relative z-10 space-y-12 scroll-mt-24">
        <div className="text-center space-y-2">
          <span className="text-[10px] text-[var(--primary-color)] font-mono font-extrabold tracking-widest uppercase">GLOBAL DEPLOYMENT</span>
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-wide">CHECK YOUR PING</h2>
          <p className="text-xs text-gray-400 max-w-md mx-auto font-mono">
            Test actual live round-trip latency from your current device to our deployment regions. Real measurements, zero fake metrics.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { name: 'India', flag: '🇮🇳', region: 'Mumbai Datacenter', provider: 'Yotta NM1' },
            { name: 'Singapore', flag: '🇸🇬', region: 'Changi Edge', provider: 'Equinix SG1' },
            { name: 'Germany', flag: '🇩🇪', region: 'Frankfurt Central', provider: 'Interxion FRA' },
            { name: 'USA', flag: '🇺🇸', region: 'Ashburn Hub', provider: 'Equinix DC2' }
          ].map((loc) => {
            const result = latencies[loc.name];
            return (
              <div 
                key={loc.name} 
                className="p-5 bg-[#080B12] border border-white/5 rounded-2xl flex flex-col justify-between hover:border-white/20 transition-all"
              >
                <div>
                  <div className="flex justify-between items-start">
                    <span className="text-3xl">{loc.flag}</span>
                    {result ? (
                      <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-full border ${
                        result.status === 'ONLINE'
                          ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
                          : 'text-amber-400 bg-amber-500/10 border-amber-500/20'
                      }`}>
                        {result.ms} ms
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">NOT TESTED</span>
                    )}
                  </div>
                  <h4 className="text-base font-bold text-white tracking-wide mt-3">{loc.name}</h4>
                  <p className="text-xs text-gray-400 font-mono mt-0.5">{loc.region}</p>
                  <p className="text-[10px] text-gray-500 font-mono mt-0.5">{loc.provider}</p>
                </div>

                <div className="pt-4 mt-4 border-t border-white/5 flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleTestPing(loc.name)}
                    disabled={testingLoc === loc.name}
                    className="flex-1 py-2 bg-white/5 hover:bg-white/10 text-[10px] font-mono tracking-wider text-gray-200 font-bold rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    {testingLoc === loc.name ? 'MEASURING...' : 'TEST PING'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const el = document.getElementById('pricing-plans');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-3 py-2 bg-[var(--primary-color)]/20 hover:bg-[var(--primary-color)] text-[var(--primary-color)] hover:text-white text-[10px] font-mono font-bold rounded-xl transition-all cursor-pointer"
                  >
                    DEPLOY
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. SEARCHABLE FAQ */}
      <section className="max-w-4xl mx-auto px-6 relative z-10 space-y-8">
        <div className="text-center space-y-2">
          <span className="text-[10px] text-[var(--primary-color)] font-mono font-extrabold tracking-widest uppercase">ANSWERS & GUIDES</span>
          <h2 className="text-2xl md:text-3xl font-black text-white tracking-wide">FREQUENTLY ASKED QUESTIONS</h2>
          <p className="text-xs text-gray-400 max-w-sm mx-auto font-mono">Search our knowledgebase or filter by category.</p>
        </div>

        {/* Search Input Bar */}
        <div className="relative max-w-xl mx-auto">
          <Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={faqSearch}
            onChange={(e) => setFaqSearch(e.target.value)}
            placeholder="Search questions (e.g. Bedrock, UPI, Backups, Plugins)..."
            className="w-full bg-[#080B12] border border-white/10 rounded-xl pl-11 pr-4 py-3 text-xs text-white focus:outline-none focus:border-[var(--primary-color)] font-mono"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 justify-center">
          {faqCategories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedFaqCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                selectedFaqCategory === cat
                  ? 'bg-[var(--primary-color)] text-white shadow-md'
                  : 'bg-[#080B12] text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3">
          {filteredFaqs.length === 0 ? (
            <div className="p-8 text-center text-gray-500 font-mono text-xs bg-[#080B12] rounded-xl border border-white/5">
              No matching questions found for "{faqSearch}". Try searching with different keywords.
            </div>
          ) : (
            filteredFaqs.map((faq, idx) => (
              <div
                key={idx}
                className="bg-[#080B12] border border-white/5 rounded-xl overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setActiveFaqIndex(activeFaqIndex === idx ? null : idx)}
                  className="w-full p-5 text-left flex justify-between items-center font-sans font-semibold text-white cursor-pointer focus:outline-none"
                >
                  <span className="text-sm tracking-wide text-slate-200">{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${
                      activeFaqIndex === idx ? 'transform rotate-180 text-white' : ''
                    }`}
                  />
                </button>
                
                {activeFaqIndex === idx && (
                  <div className="px-5 pb-5 pt-1 text-xs text-gray-400 leading-relaxed border-t border-white/5 animate-fade-in font-sans">
                    {faq.a}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </section>

      {/* 7. FINAL CTA */}
      <section className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="p-8 md:p-14 bg-gradient-to-r from-[#080E1E] via-[#050914] to-[#080B12] border border-white/10 text-center relative overflow-hidden rounded-3xl shadow-2xl">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent opacity-60" />

          <div className="max-w-xl mx-auto space-y-6 relative z-10">
            <h2 className="text-3xl md:text-4xl font-black tracking-tight text-white leading-tight font-mono">
              READY TO POWER YOUR SERVER?
            </h2>
            <p className="text-xs md:text-sm text-gray-400 leading-relaxed font-sans">
              Launch your high-performance Minecraft server with FlareCloud today and unleash smooth multiplayer worlds instantly.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-2">
              <button
                onClick={() => {
                  const el = document.getElementById('pricing-plans');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-7 py-3.5 bg-[var(--primary-color)] hover:bg-[var(--accent-color)] text-white text-xs font-black font-mono tracking-wider rounded-xl transition-all cursor-pointer shadow-lg hover:scale-105"
              >
                GET STARTED NOW
              </button>
              <a
                href="https://discord.gg/fwPQPcFST"
                target="_blank"
                rel="noopener noreferrer"
                className="px-7 py-3.5 bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-bold font-mono tracking-wider rounded-xl transition-all cursor-pointer inline-flex items-center justify-center gap-2 shadow-lg hover:scale-105"
              >
                JOIN OFFICIAL DISCORD <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="max-w-7xl mx-auto px-6 pt-12 border-t border-white/5 text-center space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-400 font-mono">
          <span>© 2026 FLARECLOUD. ALL RIGHTS RESERVED.</span>
          <div className="flex flex-wrap gap-6 text-[10px] uppercase tracking-widest font-bold">
            <span className="hover:text-white cursor-pointer" onClick={() => onNavigate('home')}>Home</span>
            <span className="hover:text-white cursor-pointer" onClick={() => onNavigate('status')}>Status</span>
            <span className="hover:text-white cursor-pointer" onClick={() => onNavigate('support')}>Support</span>
            <span className="hover:text-white cursor-pointer" onClick={() => onNavigate('login')}>Portal</span>
            <span className="hover:text-red-400 cursor-pointer" onClick={() => onNavigate('admin-login')}>Staff</span>
            <a href="https://discord.gg/fwPQPcFST" target="_blank" rel="noopener noreferrer" className="hover:text-[#5865F2]">Official Discord ↗</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
