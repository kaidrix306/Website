import React, { useState, useEffect } from 'react';
import { Menu, X, Server, Shield, LogIn, LayoutDashboard, Globe, LifeBuoy } from 'lucide-react';

interface NavbarProps {
  currentView: string;
  user: any;
  customizer: any;
  onNavigate: (view: string) => void;
  onLogout: () => void;
}

export default function Navbar({ currentView, user, customizer, onNavigate, onLogout }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', view: 'home' },
    { label: 'Plans', view: 'home', elementId: 'pricing-plans' },
    { label: 'Features', view: 'home', elementId: 'hosting-features' },
    { label: 'Locations', view: 'home', elementId: 'server-locations' },
    { label: 'Status', view: 'status' },
    { label: 'Support', view: 'support' }
  ];

  const handleLinkClick = (link: typeof navLinks[0]) => {
    setIsMobileMenuOpen(false);
    if (link.view === 'home' && link.elementId) {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById(link.elementId!);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      onNavigate(link.view);
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#05070A]/90 backdrop-blur-md border-b border-white/5 py-3.5 shadow-2xl'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Brand Wordmark */}
        <div 
          onClick={() => onNavigate('home')} 
          className="flex items-center gap-2.5 cursor-pointer group select-none"
        >
          <img 
            src="/859e6c870f25da428100d75d2813c557.webp" 
            alt="FlareCloud Logo" 
            className="w-8 h-8 object-contain transition-transform duration-300 group-hover:scale-110"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <span 
            className="text-xl font-extrabold tracking-wider text-white font-mono"
            style={{ fontWeight: customizer.headingWeight }}
          >
            FLARE<span className="text-[var(--primary-color)]">CLOUD</span>
          </span>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => handleLinkClick(link)}
              className={`text-gray-400 hover:text-white transition-colors relative py-1 cursor-pointer font-sans ${
                currentView === link.view && !link.elementId
                  ? 'text-white font-semibold'
                  : ''
              }`}
            >
              {link.label}
              {currentView === link.view && !link.elementId && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[var(--primary-color)] rounded-full shadow-[0_0_8px_var(--primary-color)]" />
              )}
            </button>
          ))}
          <a
            href="https://discord.gg/fwPQPcFST"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-[#5865F2] transition-colors py-1 flex items-center gap-1.5"
          >
            Discord
          </a>
        </nav>

        {/* Primary Action Zone */}
        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate(user.role === 'admin' ? 'admin-portal' : 'customer-portal')}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-mono font-bold bg-[#0D111A] border border-white/10 rounded-xl hover:border-[var(--primary-color)] hover:text-white text-gray-200 transition-all cursor-pointer shadow-sm hover:scale-[1.02]"
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-[var(--primary-color)]" />
                {user.role === 'admin' ? 'ADMIN CONSOLE' : 'DASHBOARD'}
              </button>
              <button
                onClick={onLogout}
                className="px-3 py-2 text-xs font-mono font-bold text-gray-400 hover:text-red-400 transition-colors cursor-pointer"
              >
                LOGOUT
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('login')}
                className="px-4 py-2 text-xs font-mono font-bold text-gray-300 hover:text-white transition-colors cursor-pointer"
              >
                LOGIN
              </button>
              <button
                onClick={() => onNavigate('login')}
                className="px-5 py-2.5 text-xs font-mono font-black bg-[var(--primary-color)] text-white hover:bg-[var(--accent-color)] rounded-xl transition-all shadow-[0_0_20px_rgba(22,119,255,0.3)] hover:scale-105 cursor-pointer"
              >
                GET STARTED
              </button>
            </div>
          )}
        </div>

        {/* Mobile Hamburger Menu Toggle */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden text-gray-300 hover:text-white focus:outline-none p-1.5 cursor-pointer"
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#080B12] border-b border-white/10 py-5 px-6 space-y-4 animate-fade-in shadow-2xl">
          <div className="flex flex-col space-y-2">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => handleLinkClick(link)}
                className="text-left py-2 text-gray-300 hover:text-white text-sm font-semibold transition-colors cursor-pointer"
              >
                {link.label}
              </button>
            ))}
            <a
              href="https://discord.gg/fwPQPcFST"
              target="_blank"
              rel="noopener noreferrer"
              className="text-left py-2 text-[#5865F2] hover:underline text-sm font-semibold flex items-center gap-1.5"
            >
              Join Official Discord ↗
            </a>
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2.5">
            {user ? (
              <>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigate(user.role === 'admin' ? 'admin-portal' : 'customer-portal');
                  }}
                  className="w-full py-2.5 bg-[var(--primary-color)] text-white text-xs font-mono font-bold rounded-xl text-center cursor-pointer"
                >
                  OPEN {user.role === 'admin' ? 'ADMIN CONSOLE' : 'DASHBOARD'}
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onLogout();
                  }}
                  className="w-full py-2 text-xs font-mono text-gray-400 hover:text-red-400 text-center cursor-pointer"
                >
                  LOGOUT
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigate('login');
                  }}
                  className="w-full py-2.5 bg-white/5 border border-white/10 text-white text-xs font-mono font-bold rounded-xl cursor-pointer"
                >
                  LOGIN
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigate('login');
                  }}
                  className="w-full py-2.5 bg-[var(--primary-color)] text-white text-xs font-mono font-black rounded-xl cursor-pointer"
                >
                  GET STARTED
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
