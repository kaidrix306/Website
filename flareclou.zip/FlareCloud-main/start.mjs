// One-command launcher: installs deps, builds, makes a local HTTPS cert, serves on https://localhost:8082
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);

const PORT = process.env.PORT || '8082';
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const log = (m) => console.log(`\n[start] ${m}`);
const die = (m) => { console.error(`\n[start] ERROR: ${m}`); process.exit(1); };

function run(cmd, args) {
  const r = spawnSync(cmd, args, { stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) die(`"${cmd} ${args.join(' ')}" failed.`);
}

const major = parseInt(process.versions.node.split('.')[0], 10);
if (major < 18) die(`Node 18+ required (you have ${process.versions.node}).`);

// 1. Port check
await new Promise((resolve) => {
  const t = net.createServer();
  t.once('error', (e) => die(e.code === 'EADDRINUSE'
    ? `Port ${PORT} is already in use. Run with another port, e.g. PORT=8083 node start.mjs`
    : String(e)));
  t.once('listening', () => t.close(resolve));
  t.listen(Number(PORT));
});

// 2. Dependencies
const needInstall = !fs.existsSync('node_modules') ||
  !fs.existsSync('node_modules/selfsigned') || !fs.existsSync('node_modules/tsx');
if (needInstall) { log('Installing dependencies (first run only)...'); run(npm, ['install', '--no-audit', '--no-fund']); }

// 3. Self-signed certificate for localhost
fs.mkdirSync('.certs', { recursive: true });
const keyFile = path.resolve('.certs', 'localhost-key.pem');
const certFile = path.resolve('.certs', 'localhost-cert.pem');
if (!fs.existsSync(keyFile) || !fs.existsSync(certFile)) {
  log('Generating self-signed HTTPS certificate for localhost...');
  const mod = await import(pathToFileURL(path.resolve('node_modules/selfsigned/index.js')).href)
    .catch(() => import('selfsigned'));
  const selfsigned = mod.default ?? mod;
  const pems = await selfsigned.generate(
    [{ name: 'commonName', value: 'localhost' }],
    {
      keySize: 2048, days: 825, algorithm: 'sha256',
      extensions: [
        { name: 'basicConstraints', cA: false },
        { name: 'subjectAltName', altNames: [
          { type: 2, value: 'localhost' },
          { type: 7, ip: '127.0.0.1' },
          { type: 7, ip: '::1' },
        ] },
      ],
    }
  );
  fs.writeFileSync(keyFile, pems.private);
  fs.writeFileSync(certFile, pems.cert);
}

// 4. Production build of the frontend (skipped if dist is current)
const newest = (dir) => fs.readdirSync(dir, { withFileTypes: true }).reduce((m, e) => {
  const p = path.join(dir, e.name);
  return Math.max(m, e.isDirectory() ? newest(p) : fs.statSync(p).mtimeMs);
}, 0);
const distIndex = path.join('dist', 'index.html');
const srcTime = Math.max(newest('src'), fs.statSync('index.html').mtimeMs, fs.statSync('package.json').mtimeMs);
if (process.argv.includes('--rebuild') || !fs.existsSync(distIndex) || fs.statSync(distIndex).mtimeMs < srcTime) {
  log('Building website...');
  run(process.execPath, [path.resolve('node_modules/vite/bin/vite.js'), 'build']);
}

// 5. Run server
log(`Starting FlareCloud on https://localhost:${PORT}`);
console.log('[start] Your browser will warn about the self-signed cert the first time: Advanced -> Proceed to localhost.\n');
const child = spawn(process.execPath, [path.resolve('node_modules/tsx/dist/cli.mjs'), 'server.ts'], {
  stdio: 'inherit',
  env: { ...process.env, NODE_ENV: 'production', PORT, SSL_KEY_FILE: keyFile, SSL_CERT_FILE: certFile },
});
child.on('exit', (c) => process.exit(c ?? 0));
for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => child.kill(s));
